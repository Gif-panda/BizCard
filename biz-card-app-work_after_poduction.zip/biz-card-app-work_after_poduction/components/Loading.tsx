import { ActivityIndicator, ActivityIndicatorProps, StyleSheet, View } from "react-native";
import React from "react";

interface LoadingProps extends ActivityIndicatorProps {
  bgColor?: string;
}

const Loading: React.FC<LoadingProps> = ({ size = "large", bgColor }) => {
  return (
    <View
      style={[
        styles.container,
        { backgroundColor: bgColor }
      ]}
    >
      <ActivityIndicator size={size} color="#00FFAA" />
    </View>
  );
};

export default Loading;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
  },
});
