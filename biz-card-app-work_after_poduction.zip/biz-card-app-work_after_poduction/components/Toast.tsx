import { useToast } from 'react-native-toast-notifications';

// We’ll store the toast instance here
let toast: ReturnType<typeof useToast> | null = null;

// Called from a component once to assign the instance
export const setToast = (toastInstance: ReturnType<typeof useToast>) => {
    toast = toastInstance;
};

// Global toast methods
export const showSuccess = (message: string) => {
    toast?.show(message, { type: 'success' });
};

export const showError = (message: string) => {
    toast?.show(message, { type: 'danger' });
};

export const showWarning = (message: string) => {
    toast?.show(message, { type: 'warning' });
};

export const showInfo = (message: string) => {
    toast?.show(message, { type: 'normal' });
};
