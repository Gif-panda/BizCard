import { StyleSheet, Text, TouchableOpacity, View } from 'react-native'
import React from 'react'
import { CustomButtonProps } from '@/types'
import { colors, radius } from '@/constants/theme'
import { verticalScale } from '@/utils/styling'
import Loading from './Loading'

const Button = ({
    children,
    onPress,
    style,
    loading = false,
    disabled = false,
}: CustomButtonProps) => {
    // if (loading) {
    //     return (
    //         <View style={[styles.button, style, { backgroundColor: 'transparent' }]}>
    //             <Loading />
    //         </View>
    //     )
    // }
    const isDisabled = disabled || loading;

    return (
        <TouchableOpacity
            onPress={onPress}
            style={[
                styles.button,
                style,
                { backgroundColor: isDisabled ? '#BDBDBD' : '#1FFA9E' },
            ]}
            disabled={isDisabled}
        >
            {loading ? <Loading /> : children}
        </TouchableOpacity>
    )
}

export default Button

const styles = StyleSheet.create({
    button: {
        backgroundColor: '#1FFA9E',
        borderRadius: radius._17,
        borderCurve: 'continuous',
        height: verticalScale(52),
        alignItems: 'center',
        justifyContent: 'center',
    },
})