// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries
import {initializeAuth, getReactNativePersistence} from 'firebase/auth'
import AsyncStorage from '@react-native-async-storage/async-storage'
import { getFirestore } from "firebase/firestore";
// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyCujNE-B-gP7f2Q4Lt5Ar7KrWFyFcpRuvE",
  authDomain: "track-my-spend-6b18f.firebaseapp.com",
  projectId: "track-my-spend-6b18f",
  storageBucket: "track-my-spend-6b18f.firebasestorage.app",
  messagingSenderId: "693903256075",
  appId: "1:693903256075:web:d929331b15c7b7fa68b50e"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// auth
export const auth = initializeAuth(app, {
    persistence: getReactNativePersistence(AsyncStorage)
})


// db
export const firestore = getFirestore(app)