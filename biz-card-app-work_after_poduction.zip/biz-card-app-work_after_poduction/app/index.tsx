// index.jsx
import React, { useEffect, useState } from "react";
import { View, StyleSheet, Dimensions } from "react-native";
import Animated, {
  useSharedValue,
  useAnimatedStyle,
  withTiming,
  withRepeat,
  Easing,
  runOnJS,
} from "react-native-reanimated";
import { useRouter } from "expo-router";
import { useSelector } from "react-redux";

const { width, height } = Dimensions.get("window");

const AnimatedLogoScreen = () => {
  const [logoSwapStage, setLogoSwapStage] = useState(0);
  const [animationComplete, setAnimationComplete] = useState(false);
  const onboardingComplete = useSelector(
    (state) => state.card.onBoardingComplete
  );

  const scale = useSharedValue(1);
  const rotation = useSharedValue(0);
  const opacity = useSharedValue(1);

  const router = useRouter();
  const jwt = useSelector((state) => state.card.jwt);

  const handleLogoChange = (stage: number) => {
    opacity.value = withTiming(0, { duration: 300 }, () => {
      runOnJS(setLogoSwapStage)(stage);
      opacity.value = withTiming(1, { duration: 300 });
    });
  };

  const goToNextScreen = () => {
    if (animationComplete) {
      if (onboardingComplete) {
        if (jwt) {
          router.replace("/(main)/home");
        } else {
          router.replace("/(auth)/login");
        }
      } else {
        router.replace("/(auth)/welcome");
      }
    }
  };

  useEffect(() => {
    rotation.value = withRepeat(
      withTiming(360, { duration: 1500, easing: Easing.linear }),
      1,
      false,
      () => {
        runOnJS(handleLogoChange)(1);
        scale.value = withTiming(5, { duration: 1500 }, (midFinished) => {
          if (midFinished) {
            runOnJS(handleLogoChange)(2);
            scale.value = withTiming(
              50,
              { duration: 2000 },
              (finalFinished) => {
                if (finalFinished) {
                  runOnJS(setAnimationComplete)(true);
                }
              }
            );
          }
        });
      }
    );
  }, []);

  useEffect(() => {
    goToNextScreen();
  }, [animationComplete]);

  const animatedSquareStyle = useAnimatedStyle(() => ({
    transform: [{ rotate: `${rotation.value}deg` }, { scale: scale.value }],
  }));

  const animatedLogoStyle = useAnimatedStyle(() => ({
    opacity: opacity.value,
  }));

  const getLogoSource = () => {
    switch (logoSwapStage) {
      case 1:
        return require("../assets/images/new/biz-logo-white.png");
      case 2:
        return require("../assets/images/new/biz-logo-white-2.png");
      default:
        return require("../assets/images/new/biz-logo-black.png");
    }
  };

  return (
    <View style={styles.container}>
      <Animated.Image
        style={[styles.logo, animatedLogoStyle]}
        resizeMode="contain"
        source={getLogoSource()}
      />
      <Animated.View style={[styles.square, animatedSquareStyle]} />
    </View>
  );
};

export default AnimatedLogoScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "white",
    justifyContent: "center",
    alignItems: "center",
  },
  logo: {
    height: "20%",
    aspectRatio: 1,
    zIndex: 1,
  },
  square: {
    position: "absolute",
    width: 15,
    height: 15,
    backgroundColor: "black",
    top: height / 2 - 60,
    left: width / 2 - 20,
    zIndex: 0,
  },
});
