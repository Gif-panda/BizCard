import React, { useCallback, useEffect } from "react";
import { Slot } from "expo-router";
import { Provider, useDispatch, useSelector } from "react-redux";
import { persistStore } from "redux-persist";
import store, { RootState } from "@/store";
import { PersistGate } from "redux-persist/integration/react";
import Toast from "react-native-toast-message";
import { GestureHandlerRootView } from "react-native-gesture-handler";
import { PortalProvider } from "@gorhom/portal";
import { DefaultTheme, PaperProvider } from "react-native-paper";
import "@/utils/polyfills";
import { AppState, BackHandler, Platform } from "react-native";
import { GoogleSignin } from "@react-native-google-signin/google-signin";
import Purchases, {LOG_LEVEL} from 'react-native-purchases';
import { setCustomerInfo } from "@/store/slices/subscription/subscriptionSlice";
import NetworkGuard from "@/src/components/globals/network/NetworkGuard";

// Ensure RevenueCat always has a log handler before any native events arrive.
Purchases.setLogHandler(() => {});

const SlotLayout = () => {
  const dispatch = useDispatch();
  const jwt = useSelector((state: RootState) => state.card.jwt);
  const userData = useSelector((state: RootState) => state.card.userData as any);
  const revenueCatAppUserId =
    userData?._id ||
    userData?.id ||
    userData?.email?.trim()?.toLowerCase() ||
    null;

  const syncCustomerInfo = useCallback(async () => {
    try {
      const customerInfo = await Purchases.getCustomerInfo();
      dispatch(setCustomerInfo(customerInfo));
    } catch (error) {
      console.log("Failed to fetch customer info", error);
    }
  }, [dispatch]);

  useEffect(() => {
    Purchases.setLogLevel(LOG_LEVEL.DEBUG);
    if (Platform.OS === 'android') {
       Purchases.configure({apiKey: "goog_MimiMAobZndDMxqMiLzCiLiTndj"});
    }
    syncCustomerInfo();
  }, [syncCustomerInfo]);

  useEffect(() => {
    let isMounted = true;

    const syncRevenueCatIdentity = async () => {
      try {
        if (jwt && revenueCatAppUserId) {
          const { customerInfo } = await Purchases.logIn(revenueCatAppUserId);
          if (isMounted) {
            dispatch(setCustomerInfo(customerInfo));
          }
          return;
        }

        const customerInfo = await Purchases.logOut();
        if (isMounted) {
          dispatch(setCustomerInfo(customerInfo));
        }
      } catch (error) {
        console.log("RevenueCat identity sync failed", error);
        if (isMounted) {
          syncCustomerInfo();
        }
      }
    };

    syncRevenueCatIdentity();

    return () => {
      isMounted = false;
    };
  }, [dispatch, jwt, revenueCatAppUserId, syncCustomerInfo]);

  useEffect(() => {
    const subscription = AppState.addEventListener("change", nextState => {
      if (nextState === "active") {
        syncCustomerInfo();
      }
    });

    return () => subscription.remove();
  }, [syncCustomerInfo]);

  useEffect(() => {
    const handler = () => true;
    const subscription = BackHandler.addEventListener(
      "hardwareBackPress",
      handler
    );
    return () => subscription.remove();
  }, []);



  useEffect(() => {
    // Google Sign-In Configuration
    GoogleSignin.configure({
      webClientId: "867659994430-p9sdfjfrrem8m65noid8d838ji81b3kr.apps.googleusercontent.com", // Replace with Web OAuth 2.0 Client ID from Google Cloud Console
      profileImageSize: 150,
      offlineAccess: true
    });
  }, []);

  return (
    <Slot
      screenOptions={{
        headerShown: false,
      }}
    />
  );
};

const RootLayout = () => {
  const persistor = persistStore(store);

  return (
    <GestureHandlerRootView className="flex-1">
      <PaperProvider
        theme={{
          ...DefaultTheme,
          colors: {
            ...DefaultTheme.colors,
            secondaryContainer: "transparent",
          },
        }}
      >
        <PortalProvider>
          <Provider store={store}>
            <PersistGate loading={null} persistor={persistor}>
              <NetworkGuard>
                <SlotLayout />
                <Toast />
              </NetworkGuard>
            </PersistGate>
          </Provider>
        </PortalProvider>
      </PaperProvider>
    </GestureHandlerRootView>
  );
};
export default RootLayout;


