import { StyleSheet, View } from 'react-native'
import React, { useLayoutEffect } from 'react'
import { useNavigation } from 'expo-router'
import { colors, spacingY } from '@/constants/theme'
import CardScan from '@/src/components/scan'

const Scan = () => {
  const navigation = useNavigation();

  useLayoutEffect(() => {
    // Hide the TabBar on mount
    navigation.setOptions({
      tabBarStyle: { display: 'none' },
    });

    // Restore it when unmounted
    return () => {
      navigation.setOptions({
        tabBarStyle: { display: 'flex' },
      });
    };
  }, [navigation]);

  return (
    <View style={styles.container}>
      <CardScan />
    </View>
  )
}

export default Scan

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.neutral900,
    flex: 1,
    justifyContent: 'space-between',
    paddingTop: spacingY._7,
  },
})
