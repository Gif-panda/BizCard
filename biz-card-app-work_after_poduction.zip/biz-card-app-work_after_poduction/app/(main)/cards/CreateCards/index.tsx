import {
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  ScrollView,
  Dimensions,
  Image,
  Switch,
} from "react-native";
import React, { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { colors, spacingX, spacingY } from "@/constants/theme";
import CircleButton from "@/src/components/globals/CircleButton";
import TabButtons from "@/src/components/globals/TabButton";
import { tabButtons } from "@/constants/categorySwitcher";
import { Portal, TextInput } from "react-native-paper";
import Typo from "@/components/Typo";
import Input from "@/components/Input";
import * as ImagePicker from 'expo-image-picker';
import * as Contacts from 'expo-contacts';
import {
  BASIC_COLORS,
  cardTemplates,
  CATEGORIES,
  COLORS,
  GRADIENT_COLORS,
  INDUSTRIES,
} from "@/src/constants/createCard";
import { LinearGradient } from "expo-linear-gradient";
import { Picker } from "@react-native-picker/picker";
import { useCreateCardMutation } from "@/store/api/card/mainApis";
import { showToast } from "@/src/components/globals/Toast";
import SingleButton from "@/src/components/globals/single-card/SingleButton";
import { FormField } from "@/src/components/common/main/createCard/formField";
import { useSelector } from "react-redux";
import { useSubscriptionDetails } from "@/store/selectors/subscription/subscription";
import { useRouter } from "expo-router";
import SingleBizCard from "@/src/components/globals/single-card/SingleBizCard";
import { useLocalSearchParams } from "expo-router";
import { renderToastError, renderToastSuccess } from "@/src/components/globals/ToastNotification";
import BottomSheet, { BottomSheetView } from '@gorhom/bottom-sheet';
import Feather from '@expo/vector-icons/Feather';
import ProBadge from "@/src/components/globals/proBadge";
import { FontAwesome6 } from "@expo/vector-icons";
import RemoveWatermark from "@/src/components/common/main/removeWatermark";

import { Dropdown } from 'react-native-element-dropdown';

import { useFocusEffect } from 'expo-router';
import { RootState } from "@/store";

const screenWidth = Dimensions.get("window").width;
interface SocialLink {
  platform: string;
  url: string;
}
interface ScannedCardData {
  firstName: string;
  lastName: string;
  email: string;
  phoneNumber: string;
  organization: string;
  position: string;
  subCategory: string;
  website: string;
  completeAddress: string;
}
interface CardData {
  ContactDetails: {
    myContact: boolean;
    firstName: string;
    lastName: string;
    email: string;
    phoneNumber: string;
    organization: string;
    position: string;
    category: string;
    subCategory: string;
    website: string;
    address: string;
    photo: string;
    logo: string;
    note: string;
    industry: string;
    socialLinks: SocialLink[];
  };
  cardDetails: {
    cardName: string;
    waterMark: boolean;
    template: {
      useGradient: boolean;
      textColor: string;
      templateColor: string;
      templateType: string;
    };
  };
}

const SOCIAL_PLATFORMS = [
  { label: "LinkedIn", value: "LinkedIn", icon: "linkedin", color: "#0A66C2" },
  { label: "Twitter / X", value: "Twitter", icon: "x-twitter", color: "#000000" },
  { label: "Facebook", value: "Facebook", icon: "facebook", color: "#1877F2" },
  { label: "Instagram", value: "Instagram", icon: "instagram", color: "#E1306C" },
  { label: "YouTube", value: "YouTube", icon: "youtube", color: "#FF0000" },
  { label: "TikTok", value: "TikTok", icon: "tiktok", color: "#69C9D0" },
  { label: "GitHub", value: "GitHub", icon: "github", color: "#ffffff" },
  { label: "WhatsApp", value: "WhatsApp", icon: "whatsapp", color: "#25D366" },
  { label: "Telegram", value: "Telegram", icon: "telegram", color: "#2AABEE" },
  { label: "Snapchat", value: "Snapchat", icon: "snapchat", color: "#FFFC00" },
  { label: "Pinterest", value: "Pinterest", icon: "pinterest", color: "#E60023" },
  { label: "Reddit", value: "Reddit", icon: "reddit", color: "#FF4500" },
  { label: "Discord", value: "Discord", icon: "discord", color: "#5865F2" },
];

const getPlatformInfo = (platform: string) => {
  return SOCIAL_PLATFORMS.find((p) => p.value === platform) || { icon: "link", color: "#888" };
};

const CreateCards = () => {
  const [selectedTab, setSelectedTab] = useState<any>("personal");
  const [createCard, { isLoading }] = useCreateCardMutation();
  const router = useRouter();
  const subscriptionState = useSelector(useSubscriptionDetails);
  const isCouponVerified = useSelector(
    (state: RootState) => Boolean(state.card.userData?.couponVerfied)
  );
  const isProUser = subscriptionState.isBought || isCouponVerified;
  const params = useLocalSearchParams();
  const [originalCard, setOriginalCard] = useState<any>("");
  const [otherIndustry, setOtherIndustry] = useState("");

  const requestPermission = async () => {
    const { status } = await Contacts.requestPermissionsAsync();
    return status === 'granted';
  };



 useEffect(() => {
  if (params.scannedData) {
    try {
      const scannedData: ScannedCardData = JSON.parse(params.scannedData as string);

      // Check if scanned subCategory exists in CATEGORIES
      const validSubCategory = CATEGORIES.find(
        (cat) => cat.value === scannedData.subCategory
      )
        ? scannedData.subCategory
        : "favorites";

      // Check if scanned industry exists in INDUSTRIES
      const validIndustry = INDUSTRIES.find(
        (ind) => ind.value === scannedData.completeAddress // <- or scannedData.industry if available
      )
        ? scannedData.completeAddress
        : INDUSTRIES[0].value;

      setOriginalCard(params.manyImage || "");

      setCardData({
        ContactDetails: {
          myContact: false,
          firstName: scannedData.firstName || "",
          lastName: scannedData.lastName || "",
          email: scannedData.email || "",
          phoneNumber: scannedData.phoneNumber || "",
          organization: scannedData.organization || "",
          position: scannedData.position || "",
          category: selectedTab,
          subCategory: validSubCategory,
          website: scannedData.website || "",
          address: scannedData.completeAddress || "",
          photo: "",
          logo: "",
          note: scannedData.organization ? "Imported from business card scan" : "",
          industry: validIndustry,
          socialLinks: [] as SocialLink[],
        },
        cardDetails: {
          cardName: scannedData.organization || `${scannedData.firstName} ${scannedData.lastName}`.trim() || "Scanned Business Card",
          waterMark: true,
          template: {
            useGradient: false,
            textColor: "#808080",
            templateColor: "",
            templateType: "classic",
          },
        },
      });
    } catch (error) {
      showToast("Error importing scanned data");
    }
  } else {
    // No scanned data => reset form to empty
    setOriginalCard("");
    setOtherIndustry("");
    setCardData({
      ContactDetails: {
        myContact: false,
        firstName: "",
        lastName: "",
        email: "",
        phoneNumber: "",
        organization: "",
        position: "",
        category: selectedTab,
        subCategory: "favorites",
        website: "",
        address: "",
        photo: "",
        logo: "",
        note: "",
        industry: INDUSTRIES[0].value,
        socialLinks: [] as SocialLink[],
      },
      cardDetails: {
        cardName: "",
        waterMark: true,
        template: {
          useGradient: false,
          textColor: "#808080",
          templateColor: "",
          templateType: "classic",
        },
      },
    });
  }
}, [params.scannedData]);



  const [cardData, setCardData] = useState<CardData>({
    ContactDetails: {
      myContact: false,
      firstName: "",
      lastName: "",
      email: "",
      phoneNumber: "",
      organization: "",
      position: "",
      category: selectedTab,
      subCategory: "favorites",
      website: "",
      address: "",
      photo: "",
      logo: "",
      note: "",
      industry: INDUSTRIES[0].value,
      socialLinks: [] as SocialLink[],
    },
    cardDetails: {
      cardName: "",
      waterMark: true,
      template: {
        useGradient: false,
        textColor: "#808080",
        templateColor: "",
        templateType: "classic",

      },
    },
  });
  const handleSaveContact = async () => {
    const permissionGranted = await requestPermission();
    if (!permissionGranted) {
      renderToastError("Cannot access contacts");
      return;
    }
    const contact: any = {
      [Contacts.Fields.FirstName]: cardData?.ContactDetails?.firstName,
      [Contacts.Fields.LastName]: cardData?.ContactDetails?.lastName,
      [Contacts.Fields.PhoneNumbers]: [
        {
          label: 'mobile',
          number: cardData?.ContactDetails?.phoneNumber,
        },
      ],
    };

    try {
      const contactId = await Contacts.addContactAsync(contact);
      setCardData({
        ContactDetails: {
          myContact: false,
          firstName: "",
          lastName: "",
          phoneNumber: "",
          email: "",
          organization: "",
          position: "",
          category: selectedTab,
          industry: INDUSTRIES[0].value,
          subCategory: "favorites",
          website: "",
          address: "",
          photo: "",
          logo: "",
          note: "",
          socialLinks: [] as SocialLink[],
        },
        cardDetails: {
          cardName: "",
          waterMark: true,
          template: {
            useGradient: false,
            textColor: "#808080",
            templateColor: "",
            templateType: "classic",

          },
        },
      });
      if (contactId) {
        renderToastSuccess("Contact saved in your phone successfully!");
      }
    } catch (error) {
      renderToastError("Failed to save contact in your phone");
    }
  };

  const bottomSheetRef: any = useRef(null);
  const snapPoints = useMemo(() => ['25%', '40%'], []);
  const handleOpen = () => {
    bottomSheetRef.current?.expand();
  };


  const createFieldSetter =
    <
      Section extends "ContactDetails" | "cardDetails",
      Field extends keyof CardData[Section]
    >(
      section: Section,
      field: Field
    ) =>
      (value: string | boolean) => {
        setCardData((prev) => ({
          ...prev,
          [section]: {
            ...prev[section],
            [field]: value,
          },
        }));
      };

const renderColor = (color: any, index: number, isGradient = false) => {
  const isSelected =
    cardData.cardDetails.template.templateColor ===
    `${isGradient ? "gradient-" : "basic-"}${index}`;

  return (
    <TouchableOpacity
      key={index}
      style={styles.colorWrapper}
      onPress={() => {
        if (!color.premium || isProUser) {
          setCardData((prev) => ({
            ...prev,
            cardDetails: {
              ...prev.cardDetails,
              template: {
                ...prev.cardDetails.template,
                useGradient: isGradient,
                templateColor: `${isGradient ? "gradient-" : "basic-"}${index}`,
              },
            },
          }));
        } else {
          showToast("Upgrade to Pro to access this gradient!");
        }
      }}
      disabled={color.premium && !isProUser}
    >
      {isGradient ? (
        <View style={[styles.gradientContainer, color.premium && !isProUser && styles.disabledGradient]}>
          <LinearGradient
            colors={color.colors}
            style={[styles.colorCircle, isSelected && styles.selectedCircle]}
          />
          {color.premium && !isProUser && (
            <View style={styles.gradientBadgeContainer}>
              <Text > <FontAwesome6 name="crown" size={12} color="gold" style={{ marginLeft: 3 }} /></Text>
            </View>
          )}
        </View>
      ) : (
        <View
          style={[
            styles.colorCircle,
            { backgroundColor: color },
            isSelected && styles.selectedCircle,
          ]}
        />
      )}
    </TouchableOpacity>
  );
};


  const handleCreateCard = async () => {
    try {
      const myContactValue = Boolean(
        cardData.ContactDetails.myContact
      );
      const dataToSend = {
        ...cardData,
        ContactDetails: {
          ...cardData.ContactDetails,
          myContact: myContactValue,
          originalCard: originalCard || "",
          ...(cardData.ContactDetails.industry === "Other" && { otherIndustry: otherIndustry }),
        },
      };
      console.log("dataToSend", dataToSend.ContactDetails.myContact);

      const res = await createCard(dataToSend).unwrap();
      handleSaveContact();
      renderToastSuccess(res?.data?.message || "card created successfully");
      router.push("/(main)/home");
    } catch (error: any) {
      renderToastError(error?.data?.message || "Error in creating card");
    }
  };
  const handleImagePick = async (type: 'photo' | 'logo') => {

    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();

    if (status !== 'granted') {
      showToast("Permission to access media library is required!")
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      base64: true,
      allowsEditing: true,
      quality: 0.7,
    });



    if (!result.canceled && result?.assets?.[0]?.base64) {
      setCardData((prevData) => ({
        ...prevData,
        ContactDetails: {
          ...prevData.ContactDetails,
          [type]: `data:image/jpeg;base64,${result?.assets?.[0]?.base64}`,
        },
      }));
    }
  };


  useEffect(() => {
    (async () => {
      const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
      if (status !== 'granted') {
        renderToastError("Permission to access media library is required!")
      }
    })();
  }, []);

  // Remove this line:
// const [socialLinks, setSocialLinks] = useState<Array<{platform: string, url: string}>>([]);

const addSocialLink = () => {
  setCardData(prev => ({
    ...prev,
    ContactDetails: {
      ...prev.ContactDetails,
      socialLinks: [...prev.ContactDetails.socialLinks, {platform: "", url: ""}]
    }
  }));
};

const removeSocialLink = (index: number) => {
  setCardData(prev => {
    const updatedLinks = [...prev.ContactDetails.socialLinks];
    updatedLinks.splice(index, 1);
    return {
      ...prev,
      ContactDetails: {
        ...prev.ContactDetails,
        socialLinks: updatedLinks
      }
    };
  });
};

const updateSocialLink = (index: number, field: 'platform' | 'url', value: string) => {
  setCardData(prev => {
    const updatedLinks = [...prev.ContactDetails.socialLinks];
    updatedLinks[index][field] = value;
    return {
      ...prev,
      ContactDetails: {
        ...prev.ContactDetails,
        socialLinks: updatedLinks
      }
    };
  });
};

  return (
    <ScrollView contentContainerStyle={[styles.constainer, { flexGrow: 1 }]}>
      <View style={styles.headerContainer}>
        <CircleButton
          onPress={() => {
            router.push("/(main)/cards");
            bottomSheetRef.current?.close();

          }}
          iconSource={require("@/assets/main/cross-icon.png")}
        />
        <Text style={styles.centerTitle}>Create Card</Text>
        <CircleButton
          iconSource={require("@/assets/settings/account-icon.png")}
        />
      </View>

      <TabButtons
        buttons={tabButtons}
        selectedTab={selectedTab}
        setSelectedTab={(index) => {
          if (index === 0) {
            setSelectedTab("personal");
          } else {
            setSelectedTab("business");
          }
        }}
      />

      {originalCard ? (
        <View
        style={{
          marginVertical: 10,
        }}>
        <Text style={styles.sectionTitle}>Original Card</Text>
      <Image
        source={{ uri: `data:image/jpeg;base64,${originalCard}` }}
         style={{
              width: "100%",
              height: 194,
              objectFit: "fill",
              borderRadius: 20,
            }}
            resizeMode="contain"
      />
      </View>
      ) : (
      <View
        style={{
          marginVertical: 10,
        }}
      >
        <SingleBizCard
          isProUser={isProUser}
          cardDetails={cardData}
        />
      </View>
      )}
      
      <Text style={styles.sectionTitle}>Contact Details</Text>
      <View style={styles.card}>
        <Text style={styles.cardTitle}>Full Name</Text>

        <View style={styles.inputContainer}>
          <View style={styles.inputRow}>
            <TextInput
              mode="flat"
              label="First Name"
              value={cardData.ContactDetails.firstName}
              onChangeText={createFieldSetter("ContactDetails", "firstName")}
              style={styles.input}
              textColor="white"
              underlineColor="transparent"
              theme={{ colors: { text: "#fff", primary: "#fff" } }}
            />
            {/* <Icon name="edit" size={18} color="#888" /> */}
          </View>
        </View>

        <View style={styles.inputContainer}>
          <View style={styles.inputRow}>
            <TextInput
              label="Last Name"
              mode="flat"
              value={cardData.ContactDetails.lastName}
              onChangeText={createFieldSetter("ContactDetails", "lastName")}
              style={styles.input}
              textColor="white"
              underlineColor="transparent"
              theme={{ colors: { text: "#fff", primary: "#fff" } }}
            />
            {/* <Icon name="edit" size={18} color="#888" /> */}
          </View>
        </View>
      </View>

      <FormField
        value={cardData.ContactDetails.email}
        label="Email"
        placeholder="e.g john@gmail.com"
        onChangeText={createFieldSetter("ContactDetails", "email")}
      />

      <FormField
        value={cardData.ContactDetails.phoneNumber}
        label="Phone Number"
        placeholder="e.g +443232211232"
        onChangeText={createFieldSetter("ContactDetails", "phoneNumber")}
      />

      <FormField
        value={cardData.ContactDetails.organization}
        label="Organization"
        placeholder="e.g Tech Solutions Ltd"
        onChangeText={createFieldSetter("ContactDetails", "organization")}
      />

      <FormField
        value={cardData.ContactDetails.position}
        label="Position"
        placeholder="e.g Manager, UI Expert"
        onChangeText={createFieldSetter("ContactDetails", "position")}
      />





      <FormField
        value={cardData.ContactDetails.website}
        label="Website"
        placeholder="e.g https://www.techsolutions.com"
        onChangeText={createFieldSetter("ContactDetails", "website")}
      />

      <FormField
        value={cardData.ContactDetails.address}
        label="Complete Address"
        placeholder="e.g h no 10 st no 12"
        onChangeText={createFieldSetter("ContactDetails", "address")}
      />

      <FormField
        value={cardData.ContactDetails.note}
        label="Note"
        placeholder="Write note here.."
        onChangeText={createFieldSetter("ContactDetails", "note")}
      />

      <View style={styles.switchRow}>
        <Text style={styles.switchLabel}>Save As My Card</Text>
        <Switch
          value={cardData.ContactDetails.myContact}
          onValueChange={(value) =>
            setCardData((prev) => ({
              ...prev,
              ContactDetails: {
                ...prev.ContactDetails,
                myContact: value,
              },
            }))
          }
          trackColor={{ false: "#444", true: "#00FF99" }}
          thumbColor={cardData.ContactDetails.myContact ? "#ffffff" : "#d1d1d1"}
        />
      </View>

      <Text style={styles.sectionTitle}>Sub Category</Text>
<Dropdown
  style={styles.dropdown}
  containerStyle={styles.dropdownContainer}   
  itemContainerStyle={styles.dropdownItem}      
  selectedTextStyle={{ color: "gray" }}
  placeholderStyle={{ color: "gray" }}
  itemTextStyle={styles.itemText}       
  activeColor="#222"    
  data={CATEGORIES.map(cat => ({ label: cat.label, value: cat.value }))}
  labelField="label"
  valueField="value"
  placeholder="Select Sub Category"
  value={cardData.ContactDetails.subCategory}
  onChange={item => {
    setCardData(prev => ({
      ...prev,
      ContactDetails: {
        ...prev.ContactDetails,
        subCategory: item.value,
      },
    }));
  }}
/>

      <Text style={styles.sectionTitle}>Industry</Text>
<Dropdown
  style={styles.dropdown}
  containerStyle={styles.dropdownContainer}  
  itemContainerStyle={styles.dropdownItem}   
  selectedTextStyle={{ color: "gray" }}
  placeholderStyle={{ color: "gray" }}
  itemTextStyle={styles.itemText}            
  activeColor="#222" 
  data={INDUSTRIES.map(ind => ({ label: ind.label, value: ind.value }))}
  labelField="label"
  valueField="value"
  placeholder="Select Industry"
  value={cardData.ContactDetails.industry}
  onChange={item => {
    setCardData(prev => ({
      ...prev,
      ContactDetails: {
        ...prev.ContactDetails,
        industry: item.value,
      },
    }));
  }}
/>


      {cardData.ContactDetails.industry === "Other" && (
        <View style={{ marginTop: 10 }}>
        <FormField
          value={otherIndustry}
          label="Specify Industry"
          placeholder="Write your industry"
          onChangeText={setOtherIndustry}
        />
        </View>
      )}

<Text style={styles.sectionTitle}>Social Links</Text>

{cardData.ContactDetails.socialLinks.map((link, index) => {
  const platformInfo = getPlatformInfo(link.platform);
  return (
    <View key={index} style={styles.socialLinkContainer}>
      {/* Card header */}
      <View style={styles.socialLinkHeader}>
        <View style={[styles.platformIconBadge, { backgroundColor: platformInfo.color + "22" }]}>
          <FontAwesome6 name={platformInfo.icon as any} size={16} color={platformInfo.color} />
        </View>
        <Text style={styles.socialLinkTitle}>
          {link.platform || `Social Link ${index + 1}`}
        </Text>
        <TouchableOpacity style={styles.removeButton} onPress={() => removeSocialLink(index)}>
          <Feather name="trash-2" size={16} color="#FF3B30" />
        </TouchableOpacity>
      </View>

      {/* Divider */}
      <View style={styles.socialDivider} />

      {/* Platform Dropdown */}
      <Text style={styles.socialFieldLabel}>Platform</Text>
      <Dropdown
        style={styles.socialDropdown}
        containerStyle={styles.dropdownContainer}
        itemContainerStyle={styles.dropdownItem}
        selectedTextStyle={{ color: "white", fontSize: 13 }}
        placeholderStyle={{ color: "gray", fontSize: 13 }}
        itemTextStyle={styles.itemText}
        activeColor="#222"
        data={SOCIAL_PLATFORMS}
        labelField="label"
        valueField="value"
        placeholder="Select platform"
        value={link.platform}
        onChange={(item) => updateSocialLink(index, "platform", item.value)}
        renderLeftIcon={() =>
          link.platform ? (
            <FontAwesome6
              name={getPlatformInfo(link.platform).icon as any}
              size={14}
              color={getPlatformInfo(link.platform).color}
              style={{ marginRight: 8 }}
            />
          ) : (
            <Feather name="grid" size={14} color="#888" style={{ marginRight: 8 }} />
          )
        }
      />

      {/* URL Input */}
      <Text style={[styles.socialFieldLabel, { marginTop: 12 }]}>Profile URL</Text>
      <View style={styles.urlInputWrapper}>
        <Feather name="link-2" size={14} color="#888" style={styles.urlIcon} />
        <TextInput
          mode="flat"
          placeholder="https://..."
          placeholderTextColor="#555"
          value={link.url}
          onChangeText={(value) => updateSocialLink(index, "url", value)}
          style={styles.urlInput}
          textColor="white"
          underlineColor="transparent"
          activeUnderlineColor="transparent"
          theme={{ colors: { text: "#fff", primary: "#fff" } }}
        />
      </View>
    </View>
  );
})}

<TouchableOpacity style={styles.addButton} onPress={addSocialLink}>
  <View style={styles.addButtonInner}>
    <Feather name="plus-circle" size={18} color="#00FF99" />
    <Text style={styles.addButtonText}>Add Social Link</Text>
  </View>
</TouchableOpacity>


      {!originalCard && <Text style={styles.sectionTitle}>Upload Images</Text>}

      {!originalCard && (
      <TouchableOpacity
        style={styles.uploadButton}
        onPress={() => handleImagePick('photo')}
      >
        <Text style={styles.uploadText}>Upload Your Photo</Text>
        <Feather name="upload-cloud" size={20} color="white" />

      </TouchableOpacity>
      )}

      {!originalCard && (
      <TouchableOpacity
        style={styles.uploadButton}
        onPress={() => handleImagePick('logo')}
      >
        <Text style={styles.uploadText}>Upload Business Logo</Text>

        <Feather name="upload-cloud" size={20} color="white" />

      </TouchableOpacity>
      )}


      {!originalCard && (
      <View style={{ flexDirection: "row", gap: 10, marginBottom: 10, display: "flex", justifyContent: "center" }}>

        {cardData.ContactDetails.photo !== 'none' && (
          <Image
            source={{ uri: cardData.ContactDetails.photo }}
            style={styles.imagePreview}
          />
        )}
        {cardData.ContactDetails.logo !== 'none' && (
          <Image
            source={{ uri: cardData.ContactDetails.logo }}
            style={styles.imagePreview}
          />
        )}
      </View>
      )}


{!originalCard && !isProUser ? <RemoveWatermark /> : null}

      {!originalCard && <Text style={styles.newlabel}>Card Details</Text>}
      {!originalCard && <Text style={styles.sectionSubTitle}>
        Edit the name and appearance of the card.
      </Text>}

      {!originalCard && (
      <View style={styles.formInner}>
        <Typo size={12} color="white">
          Card Name
        </Typo>
        <Input
          containerStyle={{
            borderRadius: 40,
          }}
          onChangeText={createFieldSetter("cardDetails", "cardName")}
          inputStyle={{
            color: "white",
          }}
          placeholder="Business Card"
        />
      </View>
      )}

      {!originalCard && <Text style={styles.sectionTitle}>Select Your Template </Text>}

      {!originalCard && (
      <View style={styles.grid}>
      {cardTemplates.map((template) => {
  const isDisabled = template.premium && !isProUser;

  return (
    <View>
    <TouchableOpacity
      key={template.id}
      onPress={() => {
        if (!isDisabled) {
          setCardData((prev) => ({
            ...prev,
            cardDetails: {
              ...prev.cardDetails,
              template: {
                ...prev.cardDetails.template,
                templateType: template.id,
              },
            },
          }));
        } else {
          showToast("Upgrade to Pro to access this template!");
        }
      }}
      style={[
        styles.cardWrapper,
        cardData.cardDetails.template.templateType === template.id && styles.selectedCard,
        isDisabled && styles.disabledCard,
      ]}
      disabled={isDisabled}
    >
      <View style={styles.templateContainer}>
        <Image
          source={template.image}
          style={[styles.cardImage, isDisabled && styles.disabledImage]}
          resizeMode="contain"
        />

        {/* Pro badge positioned at bottom right */}
        {template.premium && !isProUser && (
          <View style={styles.badgeContainer}>
            <ProBadge />
          </View>
        )}
      </View>
    </TouchableOpacity>
        <Text style={styles.cardLabel}>{template.name}</Text>
    </View>
  );
})}

      </View>
      )}

      {!originalCard && <Text style={styles.sectionTitle}>Template Color</Text>}

      {!originalCard && (
      <View
        style={{
          paddingHorizontal: spacingX._10,
          paddingBottom: 10,
        }}
      >
        <Text style={styles.subHeader}>Basic</Text>
        <View style={styles.row}>
          {BASIC_COLORS.map((color, index) => renderColor(color, index))}
        </View>

        <Text style={styles.subHeader}>Gradiant</Text>
        <View style={[styles.row, { marginTop: 10 }]}>
          {GRADIENT_COLORS.map((color, index) =>
            renderColor(color, index, true)
          )}
        </View>
      </View>
      )}

      {!originalCard && (
      <View>


        <Text style={styles.newlabel}>Text Color</Text>
<View style={styles.newrow}>
  <Dropdown
  style={styles.colorDropdown}
  containerStyle={styles.dropdownContainer}
  itemContainerStyle={styles.dropdownItem}
  selectedTextStyle={{ color: "gray" }}
  placeholderStyle={{ color: "gray" }}
  itemTextStyle={styles.itemText}
  activeColor="#222"
    data={COLORS.map(c => ({ label: c.label, value: c.value }))}
    labelField="label"
    valueField="value"
    placeholder="Select Text Color"
    value={cardData.cardDetails.template.textColor}
    onChange={item => {
      setCardData(prev => ({
        ...prev,
        cardDetails: {
          ...prev.cardDetails,
          template: {
            ...prev.cardDetails.template,
            textColor: item.value,
          },
        },
      }));
    }}
  />
  <View
    style={[
      styles.colorPreview,
      { backgroundColor: cardData.cardDetails.template.textColor },
    ]}
  />
</View>
      </View>
      )}


        {/* <Text style={styles.sectionTitle}>Name field font</Text>

        <View style={styles.fontRow}>
          <View style={{ borderRadius: 30, overflow: "hidden" }}>
            <Picker
              selectedValue={font1}
              style={styles.picker}
              dropdownIconColor="white"
              onValueChange={(itemValue: any) => setFont1(itemValue)}
            >
              {FONTS.map((font) => (
                <Picker.Item
                  key={font.value}
                  label={font.label}
                  value={font.value}
                />
              ))}
            </Picker>
          </View>


        </View> */}

      <View style={{ gap: 10, marginBottom: 10 }}>
        <SingleButton onPress={() => { handleOpen(); }} title="Preview" />

        <SingleButton
          disabled={
            !cardData.ContactDetails.email ||
            !cardData.ContactDetails.firstName ||
            !cardData.ContactDetails.lastName
          }
          loading={isLoading}
          onPress={() => {
            handleCreateCard();
          }}
          title="Save"
        />
      </View>




      <Portal>
        <BottomSheet
          ref={bottomSheetRef}
          index={-1}
          snapPoints={snapPoints}
          enablePanDownToClose
          animationConfigs={{
            duration: 400,
          }}
          backgroundStyle={{
            borderColor: "#00FF99",
            borderWidth: 2,
            borderTopWidth: 0,
            backgroundColor: '#000',
            borderTopLeftRadius: 30,
            borderTopRightRadius: 30,
          }}
          handleStyle={{
            paddingVertical: 20,
          }}

          handleIndicatorStyle={{ backgroundColor: '#00FF99' }}
        >
          <BottomSheetView style={styles.containerBottomSheet}>
            <SingleBizCard
              isProUser={isProUser}
              cardDetails={cardData}
            />
          </BottomSheetView>
        </BottomSheet>
      </Portal>
    </ScrollView>
  );
};

export default CreateCards;

const styles = StyleSheet.create({
  bottomSheetheading: {
    color: 'white',
    fontSize: 16,
    fontWeight: '500',
    marginBottom: 12,
  },

  containerBottomSheet: {
    flex: 1,
    padding: 20,
    backgroundColor: '#000',
  },

  constainer: {
    backgroundColor: "#0E0E0E",
    justifyContent: "flex-start",
    paddingTop: spacingY._7,
    paddingHorizontal: spacingX._12,
  },
  container: { padding: 16, backgroundColor: "#000", flex: 1 },
  formInner: {
    gap: spacingY._10,
    marginBottom: 10,
  },
  headerContainer: {
    backgroundColor: "#0E0E0E",
    display: "flex",
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "space-between",
    paddingTop: spacingY._7,
    marginBottom: spacingY._12,
  },
  centerTitle: {
    textAlign: "center",
    color: "white",
    fontSize: 18,
    fontWeight: "500",
  },

  sectionTitle: {
    color: "#fff",
    fontSize: 14,
    paddingVertical: 10,
  },

  sectionSubTitle: {
    color: "#fff",
    fontSize: 12,
    marginBottom: 8,
  },
  card: {
    backgroundColor: "#1a1a1a",
    borderRadius: 30,
    marginBottom: 20,
    borderColor: "#383637",
    borderWidth: 2,
    paddingBottom: 10,
  },
  templateContainer: {
  width: "100%",
  position: "relative",
},
badgeContainer: {
  position: "absolute",
  bottom: 33,
  right: 0, 
  backgroundColor: "rgba(0,0,0,0.1)",
},
disabledCard: {
  opacity: 0.9,
},
disabledImage: {
  opacity: 0.7,
},
  cardTitle: {
    color: "#fff",
    fontSize: 14,
    fontWeight: "600",
    paddingHorizontal: 20,
    paddingTop: 20,
  },
  inputContainer: {
    // marginBottom: 12,
    padding: 10,
  },
  label: {
    color: "white",
    fontSize: 12,
    backgroundColor: "#111",
  },
  required: { color: "red" },
  inputRow: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#111",
    borderRadius: 8,
    paddingHorizontal: 6,
    marginTop: 2,
  },
    dropdown: {
    height: 50,
    borderColor: '#383637',
    borderWidth: 1,
    borderRadius: 30,
    paddingHorizontal: 16,
    backgroundColor: '#111',
    marginBottom: 10,
    width: "100%",
  },
    colorDropdown: {
    height: 50,
    borderColor: '#383637',
    borderWidth: 1,
    borderRadius: 30,
    paddingHorizontal: 16,
    backgroundColor: '#111',
    marginBottom: 10,
    width: "80%",
  },
  dropdownContainer: {
    backgroundColor: '#111',
    borderRadius: 12,
    borderColor: '#383637',
    borderWidth: 1,
  },
  dropdownItem: {
    backgroundColor: '#111', 
    borderRadius: 12,
  },
  dropdownSelectedItem: {
    backgroundColor: '#222',
  },
  itemText: {
    color: '#fff',
    fontSize: 14,
  },
  input: {
    flex: 1,
    backgroundColor: "transparent",
    color: "#fff",

  },
  gradientContainer: {
  position: "relative",
},
gradientBadgeContainer: {
  position: "absolute",
  top: -15,
  right: -5,
  zIndex: 1,
},
disabledGradient: {
  opacity: 0.6,
},
  uploadButton: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#222",
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 30,
    marginTop: 10,
    marginBottom: 5,
    justifyContent: "space-between",
  },
  uploadText: { color: "#fff", fontSize: 14 },
  switchRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 12,
    borderWidth: 1,
    borderColor: "#383637",
    borderRadius: 30,
    backgroundColor: "#111",
    paddingVertical: 10,
    paddingHorizontal: 16,
  },
  switchLabel: {
    color: "#fff",
    fontSize: 14,
    fontWeight: "500",
  },

  // container: {
  //     flex: 1,
  //     backgroundColor: '#000',
  //     padding: 16,
  // },
  heading: {
    fontSize: 22,
    fontWeight: "bold",
    color: "#fff",
    marginBottom: 16,
  },
  imagePreview: { width: 100, height: 100, marginTop: 10, borderRadius: 10 },
  grid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
  },
  cardWrapper: {
    width: (screenWidth - 48) / 2,
    backgroundColor: "#111",
    padding: 8,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: "#222",
    alignItems: "center",
  },
  selectedCard: {
    borderColor: "#00FF99",
    borderWidth: 1,
  },
  cardImage: {
    width: "100%",
    height: 80,
    borderRadius: 8,
  },
  socialLinkContainer: {
    backgroundColor: "#161616",
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: "#2a2a2a",
  },
  socialLinkHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    marginBottom: 4,
  },
  platformIconBadge: {
    width: 34,
    height: 34,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
  },
  socialLinkTitle: {
    flex: 1,
    color: "#fff",
    fontSize: 14,
    fontWeight: "600",
  },
  socialDivider: {
    height: 1,
    backgroundColor: "#2a2a2a",
    marginVertical: 12,
  },
  socialFieldLabel: {
    color: "#888",
    fontSize: 11,
    fontWeight: "500",
    textTransform: "uppercase",
    letterSpacing: 0.8,
    marginBottom: 6,
  },
  socialDropdown: {
    backgroundColor: "#111",
    borderRadius: 10,
    paddingHorizontal: 12,
    height: 48,
    borderWidth: 1,
    borderColor: "#2a2a2a",
  },
  urlInputWrapper: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#111",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "#2a2a2a",
    paddingLeft: 12,
    height: 48,
  },
  urlIcon: {
    marginRight: 6,
  },
  urlInput: {
    flex: 1,
    backgroundColor: "transparent",
    height: 48,
  },
  removeButton: {
    padding: 6,
    borderRadius: 8,
    backgroundColor: "#FF3B3011",
    alignItems: "center",
    justifyContent: "center",
  },
  addButton: {
    marginTop: 4,
    marginBottom: 20,
  },
  addButtonInner: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#0d1f14",
    padding: 14,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: "#00FF9933",
    gap: 8,
  },
  addButtonText: {
    color: "#00FF99",
    fontWeight: "600",
    fontSize: 14,
  },
  cardLabel: {
    color: "#fff",
    marginTop: 4,
    fontWeight: "600",
    fontSize: 14,
    textAlign: "center",
    marginBottom: 10,
  },

  header: {
    color: "white",
    fontSize: 18,
    fontWeight: "600",
    marginBottom: 10,
  },
  subHeader: {
    color: "#aaa",
    marginTop: 12,
    marginBottom: 8,
  },
  row: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 2,
  },
  colorWrapper: {
    marginRight: 12,
    marginBottom: 12,
    position: "relative",
  },
  colorCircle: {
    width: 30,
    height: 30,
    borderRadius: 20,
  },
  selectedCircle: {
    borderWidth: 2,
    borderRadius: 20,
    borderColor: "#00FFCC",
  },
  crownIcon: {
    position: "absolute",
    top: -5,
    left: -5,
  },

  newlabel: {
    color: "white",
    marginVertical: 10,
    fontSize: 16,
  },

  newrow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 20,
  },
  picker: {
    // borderRadius: 30
    height: 50,
    width: 150,
    color: "white",
    backgroundColor: "#222",
  },

  categoryPicker: {
    height: 50,
    width: "100%",
    color: "white",
    backgroundColor: "#222",
  },
  colorPreview: {
    width: 30,
    height: 30,
    borderRadius: 15,
    marginLeft: 10,
    borderWidth: 1,
    borderColor: "#fff",
  },
  fontRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 20,
  },
  counterRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    // backgroundColor: '#222',
  },
  counterButton: {
    backgroundColor: "#222",
    padding: 10,
    height: 40,
    width: 40,
    textAlign: "center",
    alignItems: "center",
    borderRadius: 20,
    marginHorizontal: 15,
  },
  counterText: {
    color: "white",
    fontSize: 20,
  },
  fontSizeText: {
    color: "white",
    fontSize: 18,
  },
});
