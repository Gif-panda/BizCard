import { StyleSheet, Text, View } from "react-native";
import React, { useMemo } from "react";
import { colors, spacingX, spacingY } from "@/constants/theme";
import ShareComponent from "@/src/components/share";
import CircleButton from "@/src/components/globals/CircleButton";
import { useRouter, useLocalSearchParams } from "expo-router";
import { useGetAllCardsQuery } from "@/store/api/card/mainApis";
import { useSelector } from "react-redux";
import { useCardDetails } from "@/store/selectors/card/card";

const Share = () => {
  const router = useRouter();
  const { cardDetails } = useLocalSearchParams<{ cardDetails?: string | string[] }>();
  const { jwt } = useSelector(useCardDetails);

  const routeCard = useMemo(() => {
    const raw = Array.isArray(cardDetails) ? cardDetails[0] : cardDetails;
    if (!raw) return null;

    try {
      return JSON.parse(raw);
    } catch (error) {
      console.error("Failed to parse share cardDetails param:", error);
      return null;
    }
  }, [cardDetails]);

  const { data: personalCards } = useGetAllCardsQuery(
    { category: "personal", subCategory: "", industry: "", name: "" },
    { skip: !jwt || Boolean(routeCard) }
  );

  const { data: businessCards } = useGetAllCardsQuery(
    { category: "business", subCategory: "", industry: "", name: "" },
    { skip: !jwt || Boolean(routeCard) }
  );

  const currentCard =
    routeCard ||
    personalCards?.data?.[0] ||
    businessCards?.data?.[0] ||
    null;

  return (
    <View style={styles.container}>
      <View style={styles.headerContainer}>
        <CircleButton
          onPress={() => router.push("/(main)/home")}
          iconSource={require("@/assets/main/cross-icon.png")}
        />
        <Text style={styles.centerTitle}>Share Card</Text>
        <Text style={{color:colors.neutral900}}>.............</Text>
        {/* <CircleButton iconSource={require("@/assets/main/qs-icon.png")} /> */}
      </View>
      {currentCard ? (
        <ShareComponent cardDetails={currentCard} />
      ) : (
        <View style={styles.emptyStateContainer}>
          <Text style={styles.errorText}>No card to share</Text>
        </View>
      )}
    </View>
  );
};

export default Share;

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.neutral900,
    flex: 1,
    justifyContent: "flex-start",
    paddingVertical: spacingY._7,
  },
  headerContainer: {
    backgroundColor: "#0E0E0E",
    display: "flex",
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "space-between",
    paddingTop: spacingY._7,
    paddingHorizontal: spacingX._12,
  },
  centerTitle: {
    textAlign: "center",
    color: "white",
    fontSize: 18,
    fontWeight: "500",
  },
  emptyStateContainer: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
  },
  errorText: {
    color: "white",
    textAlign: "center",
    fontSize: 16,
  },
});
