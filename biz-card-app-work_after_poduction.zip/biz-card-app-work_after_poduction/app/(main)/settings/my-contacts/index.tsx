import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  SafeAreaView,
} from "react-native";
import { useRouter } from "expo-router";
import { spacingX, spacingY } from "@/constants/theme";
import CircleButton from "@/src/components/globals/CircleButton";
import CardList from "@/src/components/common/main/CardList";
import { useGetAllCardsQuery } from "@/store/api/card/mainApis";
import { useSelector } from "react-redux";
import { useCardDetails } from "@/store/selectors/card/card";
import useLoading from "@/src/hooks/useLoading";
import { AntDesign } from "@expo/vector-icons";
import MycontactsCardList from "@/src/components/common/main/MycontactsCardList";

const MyContacts = () => {
  const router = useRouter();
  const { jwt } = useSelector(useCardDetails);

  const { data, isLoading, isFetching, refetch } = useGetAllCardsQuery(
    {
      category: "",
      subCategory: "",
      industry: "",
      name: "",
      myContact: true,
    },
    {
      skip: !jwt,
      refetchOnFocus: true,
      refetchOnReconnect: true,
      refetchOnMountOrArgChange: true,
    }
  );

  const loading = useLoading([isLoading, isFetching]);

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        <View style={styles.headerContainer}>
          <CircleButton
            onPress={() => router.push("/(main)/settings")}
            iconSource={require("@/assets/main/chevron-back.png")}
          />
          <Text style={styles.centerTitle}>My Cards</Text>
          <CircleButton
            onPress={() => router.push("/(main)/home")}
            iconSource={require("@/assets/tab/home.png")}
          />
        </View>

        <MycontactsCardList
          cardData={data?.data}
          loading={loading}
          category={""}
          refetch={refetch}
        />
      </View>
    </SafeAreaView>
  );
};

export default MyContacts;

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: "#0E0E0E",
  },
  container: {
    flex: 1,
    backgroundColor: "#0E0E0E",
    paddingTop: spacingY._10,
  },
  headerContainer: {
    marginBottom: spacingY._15,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingTop: spacingY._5,
  },
  centerTitle: {
    textAlign: "center",
    color: "white",
    fontSize: 18,
    fontWeight: "600",
  },
  fab: {
    position: "absolute",
    bottom: 30,
    right: 24,
    width: 58,
    height: 58,
    borderRadius: 29,
    backgroundColor: "#00FFAA",
    justifyContent: "center",
    alignItems: "center",
    elevation: 6,
    shadowColor: "#00FFAA",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 8,
  },
});
