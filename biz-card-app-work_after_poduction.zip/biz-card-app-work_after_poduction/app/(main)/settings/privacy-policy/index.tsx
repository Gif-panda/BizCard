import Typo from "@/components/Typo";
import { getCopyright } from "@/utils/common";
import { privacyPolicyData } from "@/constants/data";
import { spacingX, spacingY } from "@/constants/theme";
import { SlideInView } from "@/src/components/animations";
import CircleButton from "@/src/components/globals/CircleButton";
import { useRouter } from "expo-router";
import React from "react";
import {
  View,
  Text,
  StyleSheet,
  FlatList,
  ListRenderItemInfo,
} from "react-native";


const PrivacyPolicy = () => {
  const router = useRouter();

  const renderItem = ({ item }: ListRenderItemInfo<typeof privacyPolicyData[0]>) => (
    <SlideInView>
      <Typo style={styles.heading}>{item.title}</Typo>
      <Typo style={styles.text}>{item.content}</Typo>
    </SlideInView>
  );

  return (
    <View style={styles.container}>
      <View style={styles.headerContainer}>
        <CircleButton
          onPress={() => router.push("/(main)/settings")}
          iconSource={require("@/assets/main/chevron-back.png")}
        />
        <Text style={styles.centerTitle}>Terms & Conditions</Text>
        <CircleButton
          onPress={() => router.push("/(main)/home")}
          iconSource={require("@/assets/tab/home.png")}
        />
      </View>

      <FlatList
        data={privacyPolicyData}
        renderItem={renderItem}
        keyExtractor={(item) => item.title}
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingBottom: spacingY._30 }}
        ListFooterComponent={
          <Text style={styles.copyright}>{getCopyright()}</Text>
        }
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#0E0E0E",
    paddingHorizontal: spacingX._15,
    paddingVertical: spacingY._10,
  },
  headerContainer: {
    marginBottom: spacingY._10,
    backgroundColor: "#0E0E0E",
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingTop: spacingY._5,
  },
  centerTitle: {
    textAlign: "center",
    color: "white",
    fontSize: 18,
    fontWeight: "500",
  },
  text: {
    color: "#999",
    fontSize: 16,
    lineHeight: 24,
    marginBottom: spacingY._5,
  },
  heading: {
    fontWeight: "bold",
    fontSize: 18,
    color: "white",
    marginBottom: spacingY._5,
  },
  copyright: {
    color: "#666",
    fontSize: 12,
    textAlign: "center",
    paddingVertical: 20,
  },
});

export default PrivacyPolicy;
