import React, { useEffect, useMemo, useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  ScrollView,
  TextInput,
} from "react-native";
import { FontAwesome6 } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import CircleButton from "@/src/components/globals/CircleButton";
import { spacingY } from "@/constants/theme";
import Purchases, {
  PurchasesOfferings,
  PurchasesPackage,
} from "react-native-purchases";
import { useDispatch, useSelector } from "react-redux";
import { setCustomerInfo } from "@/store/slices/subscription/subscriptionSlice";
import { useSubscriptionDetails } from "@/store/selectors/subscription/subscription";
import { useVerifyCouponMutation } from "@/store/api/card/mainApis";
import { RootState } from "@/store";

const { width } = Dimensions.get("window");

const Subscription = () => {
  const dispatch = useDispatch();
  const subscriptionState = useSelector(useSubscriptionDetails);
  const isCouponVerified = useSelector(
    (state: RootState) => Boolean(state.card.userData?.couponVerfied)
  );
  const [offerings, setOfferings] = useState<PurchasesOfferings | null>(null);
  const [isOfferingsLoading, setIsOfferingsLoading] = useState(true);
  const [selected, setSelected] = useState<"monthly" | "yearly">("yearly");
  const [couponCode, setCouponCode] = useState("");
  const [verifyCoupon, { isLoading: isVerifyingCoupon }] = useVerifyCouponMutation();
  const router = useRouter();

  async function getOfferings() {
    try {
      setIsOfferingsLoading(true);
      const offering = await Purchases.getOfferings();
      if (offering.current !== null && offering.current.availablePackages.length !== 0) {
        setOfferings(offering);
      }
    } finally {
      setIsOfferingsLoading(false);
    }
  }

  useEffect(() => {
    getOfferings();
  }, []);

  const handleVerifyCoupon = async () => {
    const trimmedCouponCode = couponCode.trim();
    if (!trimmedCouponCode) {
      console.log("verifyCoupon error: coupon code is required");
      return;
    }

    try {
      const response = await verifyCoupon({ couponCode: trimmedCouponCode }).unwrap();
      console.log("verifyCoupon response:", JSON.stringify(response, null, 2));
    } catch (error) {
      console.log("verifyCoupon error:", error);
    }
  };

  const availablePackages = useMemo(() => {
    if (!offerings) return [];
    const current = offerings.current?.availablePackages ?? [];
    const all = Object.values(offerings.all ?? {}).flatMap(
      offering => offering.availablePackages ?? []
    );

    const deduped = new Map<string, PurchasesPackage>();
    [...current, ...all].forEach(pkg => {
      deduped.set(pkg.identifier, pkg);
    });

    return Array.from(deduped.values());
  }, [offerings]);

  const monthlyPackage = availablePackages.find(pkg => pkg.packageType === "MONTHLY");
  const yearlyPackage = availablePackages.find(pkg => pkg.packageType === "ANNUAL");

  const getPackageProductIds = (pkg?: PurchasesPackage) => {
    if (!pkg) return [];

    const ids = new Set<string>();
    const productIdentifier = pkg.product.identifier;
    const baseProductIdentifier = productIdentifier.split(":")[0];
    const defaultOptionProductId = pkg.product.defaultOption?.productId;

    ids.add(productIdentifier);
    if (baseProductIdentifier) ids.add(baseProductIdentifier);
    if (defaultOptionProductId) ids.add(defaultOptionProductId);

    return Array.from(ids);
  };

  const getPackageStatus = (pkg?: PurchasesPackage) => {
    if (!pkg) return null;

    const possibleIds = getPackageProductIds(pkg);
    return possibleIds
      .map(id => subscriptionState.products[id])
      .find(status => status?.isBought);
  };

  const monthlyStatus = getPackageStatus(monthlyPackage);
  const yearlyStatus = getPackageStatus(yearlyPackage);
  const isMonthlyBought = Boolean(monthlyStatus?.isBought);
  const isYearlyBought = Boolean(yearlyStatus?.isBought);

  useEffect(() => {
    if (selected === "monthly" && isMonthlyBought && !isYearlyBought && yearlyPackage) {
      setSelected("yearly");
      return;
    }

    if (selected === "yearly" && isYearlyBought && !isMonthlyBought && monthlyPackage) {
      setSelected("monthly");
    }
  }, [isMonthlyBought, isYearlyBought, monthlyPackage, selected, yearlyPackage]);

  const formatCurrency = (value: number, currencyCode?: string) => {
    if (!currencyCode) return value.toFixed(2);
    try {
      return new Intl.NumberFormat(undefined, {
        style: "currency",
        currency: currencyCode,
        maximumFractionDigits: 2,
      }).format(value);
    } catch {
      return value.toFixed(2);
    }
  };

  const monthlyPriceValue = monthlyPackage?.product?.price;
  const yearlyPriceValue = yearlyPackage?.product?.price;
  const actualYearlyPriceValue =
    monthlyPriceValue && yearlyPriceValue ? monthlyPriceValue * 12 : null;
  const yearlySavingsValue =
    actualYearlyPriceValue && yearlyPriceValue
      ? actualYearlyPriceValue - yearlyPriceValue
      : null;
  const yearlySavingsPercent =
    actualYearlyPriceValue && yearlySavingsValue
      ? ((yearlySavingsValue / actualYearlyPriceValue) * 100).toFixed(0)
      : null;
  const currencyCode =
    monthlyPackage?.product?.currencyCode ||
    yearlyPackage?.product?.currencyCode;

  const handleSubscribe = async () => {
    if (isCouponVerified) return;

    if (selected === "yearly") {
      if (!yearlyPackage || isYearlyBought) return;

      const { customerInfo } = await Purchases.purchasePackage(yearlyPackage);
      dispatch(setCustomerInfo(customerInfo));
      return;
    }

    if (!monthlyPackage || isMonthlyBought) return;

    const { customerInfo } = await Purchases.purchasePackage(monthlyPackage);
    dispatch(setCustomerInfo(customerInfo));
  };

  const isSelectedPlanBought =
    isCouponVerified ||
    (selected === "monthly" && isMonthlyBought) ||
    (selected === "yearly" && isYearlyBought);

  const activePlanSummary = isCouponVerified
    ? "Coupon Access (Active)"
    : subscriptionState.isBought
    ? `${subscriptionState.activeSubscriptionName ?? "Active Plan"} (${subscriptionState.activeTimeRemainingLabel ?? "Active"})`
    : null;

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <View style={styles.headerContainer}>
        <Text style={styles.centerTitle}>Subscription</Text>
        <CircleButton
          wrapperStyle={{ width: 30, height: 30 }}
          iconStyle={{ width: 10, height: 10 }}
          onPress={() => router.push("/(main)/home")}
          iconSource={require("@/assets/main/cross-icon.png")}
        />
      </View>

      {activePlanSummary ? (
        <Text style={styles.activePlanText}>Current: {activePlanSummary}</Text>
      ) : null}

      {isOfferingsLoading ? <SubscriptionCardSkeleton /> : (
      <TouchableOpacity
        style={[
          styles.card,
          selected === "yearly" && styles.selectedCard,
          (isYearlyBought || isCouponVerified) && styles.disabledCard,
        ]}
        onPress={() => !isYearlyBought && !isCouponVerified && setSelected("yearly")}
        disabled={isYearlyBought || isCouponVerified}
      >
        <View style={styles.cardHeader}>
          <View style={styles.header}>
            <Text style={styles.proText}>PRO</Text>
            <FontAwesome6 name="crown" size={14} color="gold" style={{ marginLeft: 4 }} />
          </View>

          {selected === "yearly" && (
            <View style={styles.checkIconContainer}>
              <FontAwesome6 name="check-circle" size={20} color="#00FFAA" style={styles.checkIcon} />
            </View>
          )}
        </View>

        {monthlyPackage?.product?.pricePerYearString ? (
          <Text style={styles.oldPrice}>
            {monthlyPackage.product.pricePerYearString} / Year
          </Text>
        ) : null}
        <Text style={styles.price}>
          {yearlyPackage?.product?.priceString ?? "-"} / Year
        </Text>
        {yearlySavingsValue !== null && yearlySavingsPercent !== null ? (
          <Text style={styles.savings}>
            Save {formatCurrency(yearlySavingsValue, currencyCode)} ({yearlySavingsPercent}%)
          </Text>
        ) : null}
        {isYearlyBought ? (
          <Text style={styles.disabledText}>
            Active until {yearlyStatus?.expiresDate ?? "N/A"} ({yearlyStatus?.timeRemainingLabel})
          </Text>
        ) : null}

        <View style={styles.features}>
          <Feature text="AI Research Insights" />
          <Feature text="Unlimited Business Card Scans" />
          <Feature text="Export to Excel/CSV" />
          <Feature text="Salesforce & CRM Integration" />
          <Feature text="Unlimited exports" />
          <Feature text="Unlimited Contact Sharing" />
        </View>
      </TouchableOpacity>
      )}

      {isOfferingsLoading ? <SubscriptionCardSkeleton /> : (
      <TouchableOpacity
        style={[
          styles.card,
          selected === "monthly" && styles.selectedCard,
          (isMonthlyBought || isCouponVerified) && styles.disabledCard,
        ]}
        onPress={() => !isMonthlyBought && !isCouponVerified && setSelected("monthly")}
        disabled={isMonthlyBought || isCouponVerified}
      >
        <View style={styles.cardHeader}>
          <View style={styles.header}>
            <Text style={styles.proText}>PRO</Text>
            <FontAwesome6 name="crown" size={14} color="gold" style={{ marginLeft: 4 }} />
          </View>

          {selected === "monthly" && (
            <View style={styles.checkIconContainer}>
              <FontAwesome6 name="check-circle" size={20} color="#00FFAA" style={styles.checkIcon} />
            </View>
          )}
        </View>

        <Text style={styles.price}>
          {monthlyPackage?.product?.priceString ?? "-"} / Month
        </Text>
        <Text style={styles.subText}>
          {monthlyPackage ? "Billed Monthly" : "Loading..."}
        </Text>
        {isMonthlyBought ? (
          <Text style={styles.disabledText}>
            Active until {monthlyStatus?.expiresDate ?? "N/A"} ({monthlyStatus?.timeRemainingLabel})
          </Text>
        ) : null}

        <View style={styles.features}>
          <Feature text="AI Research Insights" />
          <Feature text="Unlimited Business Card Scans" />
          <Feature text="Export to Excel/CSV" />
          <Feature text="Salesforce & CRM Integration" />
          <Feature text="Unlimited exports" />
          <Feature text="Unlimited Contact Sharing" />
        </View>
      </TouchableOpacity>
      )}

      <View style={styles.couponContainer}>
        <TextInput
          value={couponCode}
          onChangeText={setCouponCode}
          placeholder="Enter coupon code"
          placeholderTextColor="#777"
          autoCapitalize="characters"
          style={styles.couponInput}
          editable={!isCouponVerified}
        />
        <TouchableOpacity
          style={[styles.couponButton, isVerifyingCoupon && styles.disabledButton]}
          onPress={handleVerifyCoupon}
          disabled={isVerifyingCoupon || isCouponVerified}
        >
          <Text style={styles.couponButtonText}>
            {isCouponVerified ? "Coupon Applied" : isVerifyingCoupon ? "Verifying..." : "Apply Coupon"}
          </Text>
        </TouchableOpacity>
      </View>

      <TouchableOpacity
        style={[styles.logButton, isSelectedPlanBought && styles.disabledButton]}
        onPress={handleSubscribe}
        disabled={isSelectedPlanBought || isOfferingsLoading}
      >
        <Text style={styles.logButtonText}>
          {isOfferingsLoading ? "Loading..." : isCouponVerified || isSelectedPlanBought ? "Already Active" : "Subscribe"}
        </Text>
      </TouchableOpacity>
    </ScrollView>
  );
};

const Feature = ({ text }: { text: string }) => (
  <View style={styles.featureRow}>
    <FontAwesome6 name="check-circle" size={14} color="#00FFAA" />
    <Text style={styles.featureText}>{text}</Text>
  </View>
);

const SubscriptionCardSkeleton = () => (
  <View style={styles.card}>
    <View style={styles.cardHeader}>
      <View style={styles.skeletonPill} />
    </View>
    <View style={[styles.skeletonLine, { width: "55%", height: 20, marginBottom: 8 }]} />
    <View style={[styles.skeletonLine, { width: "35%", marginBottom: 14 }]} />
    <View style={styles.features}>
      <View style={styles.skeletonFeatureRow} />
      <View style={styles.skeletonFeatureRow} />
      <View style={styles.skeletonFeatureRow} />
      <View style={styles.skeletonFeatureRow} />
      <View style={styles.skeletonFeatureRow} />
    </View>
  </View>
);

const styles = StyleSheet.create({
  container: {
    paddingVertical: 20,
    paddingHorizontal: 16,
    alignItems: "center",
    backgroundColor: "#000",
    flexGrow: 1,
  },
  headerContainer: {
    marginBottom: spacingY._10,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingTop: spacingY._5,
    width: "100%",
  },
  centerTitle: {
    color: "white",
    fontSize: 16,
    fontWeight: "500",
  },
  title: {
    fontSize: 20,
    fontWeight: "700",
    color: "#fff",
    marginBottom: 16,
  },
  activePlanText: {
    color: "#00FFAA",
    fontSize: 12,
    marginBottom: 12,
    width: "90%",
  },
  card: {
    width: width * 0.9,
    backgroundColor: "#111",
    borderRadius: 14,
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: "#333",
    position: "relative",
  },
  selectedCard: {
    borderColor: "#00FFAA",
    shadowColor: "#00FFAA",
    shadowOpacity: 0.4,
    shadowOffset: { width: 0, height: 2 },
    shadowRadius: 6,
    elevation: 4,
  },
  disabledCard: {
    opacity: 0.5,
  },
  cardHeader: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "flex-start",
    marginBottom: 8,
  },
  header: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "rgba(255, 255, 255, 0.1)",
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  skeletonPill: {
    width: 68,
    height: 20,
    borderRadius: 8,
    backgroundColor: "#2B2B2B",
  },
  skeletonLine: {
    height: 14,
    borderRadius: 6,
    backgroundColor: "#2B2B2B",
  },
  skeletonFeatureRow: {
    width: "100%",
    height: 18,
    borderRadius: 6,
    backgroundColor: "#2B2B2B",
    marginBottom: 8,
  },
  checkIconContainer: {
    position: "absolute",
    top: 0,
    right: 0,
  },
  checkIcon: {
    textShadowColor: "#00FFAA",
    textShadowOffset: { width: 0, height: 0 },
    textShadowRadius: 6,
  },
  proText: {
    color: "#fff",
    fontWeight: "700",
    fontSize: 12,
  },
  oldPrice: {
    color: "gray",
    textDecorationLine: "line-through",
    fontSize: 14,
    marginBottom: 2,
  },
  price: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "700",
  },
  subText: {
    color: "gray",
    fontSize: 13,
    marginBottom: 6,
  },
  savings: {
    color: "#00FFAA",
    fontWeight: "600",
    fontSize: 14,
    marginBottom: 6,
  },
  disabledText: {
    color: "#00FFAA",
    fontSize: 12,
    marginTop: 6,
  },
  features: {
    marginTop: 8,
  },
  featureRow: {
    flexDirection: "row",
    alignItems: "center",
    borderBottomWidth: 1,
    paddingVertical: 8,
    borderBottomColor: "gray",
  },
  featureText: {
    color: "#fff",
    marginLeft: 8,
    fontSize: 13,
  },
  logButton: {
    width: width * 0.9,
    backgroundColor: "#00FFAA",
    paddingVertical: 12,
    borderRadius: 10,
    alignItems: "center",
    marginTop: 4,
    marginBottom: 16,
  },
  logButtonText: {
    color: "#000",
    fontWeight: "700",
    fontSize: 14,
  },
  disabledButton: {
    opacity: 0.6,
  },
  couponContainer: {
    width: width * 0.9,
    marginBottom: 16,
  },
  couponInput: {
    width: "100%",
    backgroundColor: "#111",
    color: "#fff",
    borderWidth: 1,
    borderColor: "#333",
    borderRadius: 10,
    paddingHorizontal: 12,
    paddingVertical: 10,
    marginBottom: 10,
    textTransform: "uppercase",
  },
  couponButton: {
    backgroundColor: "#1E90FF",
    paddingVertical: 12,
    borderRadius: 10,
    alignItems: "center",
  },
  couponButtonText: {
    color: "#fff",
    fontWeight: "700",
    fontSize: 14,
  },
});

export default Subscription;
