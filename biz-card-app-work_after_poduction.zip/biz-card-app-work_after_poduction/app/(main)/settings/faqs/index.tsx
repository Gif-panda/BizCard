import { faqData } from "@/constants/data";
import { getCopyright } from "@/utils/common";
import { spacingX, spacingY } from "@/constants/theme";
import Accordion from "@/src/components/globals/accordian";
import CircleButton from "@/src/components/globals/CircleButton";
import { useRouter } from "expo-router";
import React, { useState } from "react";
import { View, Text, StyleSheet, FlatList } from "react-native";

const Faqs = () => {
  const [activeId, setActiveId] = useState<string | null>(null);
  const router = useRouter();
  return (
    <View style={styles.container}>
      <View style={styles.headerContainer}>
        <CircleButton
          onPress={() => {
            router.push("/(main)/settings");
          }}
          iconSource={require("@/assets/main/chevron-back.png")}
        />
        <Text style={styles.centerTitle}>FAQs</Text>
        <CircleButton
          onPress={() => {
            router.push("/(main)/home");
          }}
          iconSource={require("@/assets/tab/home.png")}
        />
      </View>

      <FlatList
        data={faqData}
        keyExtractor={(item) => item.id}
        contentContainerStyle={styles.contentContainer}
        showsVerticalScrollIndicator={false}
        ListFooterComponent={
          <Text style={styles.copyright}>{getCopyright()}</Text>
        }
        renderItem={({ item, index }) => (
          <Accordion
            key={item.id}
            id={item.id}
            title={item.question}
            content={item.answer}
            expanded={activeId === item.id}
            onPress={() => setActiveId(activeId === item.id ? null : item.id)}
            isFirst={index === 0}
            isLast={index === faqData.length - 1}
          />
        )}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#0E0E0E",
    paddingHorizontal: spacingX._10,
    paddingVertical: spacingY._10,
  },
  contentContainer: {
    paddingHorizontal: spacingX._5,
    paddingBottom: spacingY._30,
  },
  headerContainer: {
    marginBottom: spacingY._10,
    backgroundColor: "#0E0E0E",
    display: "flex",
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "space-between",
    paddingHorizontal: 2,
    paddingTop: spacingY._5,
  },
  centerTitle: {
    textAlign: "center",
    color: "white",
    fontSize: 24,
    fontWeight: "500",
  },
  copyright: {
    color: "#666",
    fontSize: 12,
    textAlign: "center",
    paddingVertical: 20,
  },
});

export default Faqs;
