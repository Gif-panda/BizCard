import { StyleSheet, Text, View } from "react-native";
import React, { useState } from "react";
import { colors, spacingX, spacingY } from "@/constants/theme";
import UserSettings from "@/src/components/Settings";

const Settings = () => {
  return (
    <View style={styles.container}>
      <UserSettings />
    </View>
  );
};

export default Settings;

const styles = StyleSheet.create({
  container: {
    backgroundColor: "#0E0E0E",
    flex: 1,
    justifyContent: "flex-start",
    paddingTop: spacingY._7,
  },
});
