import React, { useEffect } from 'react';
import { 
  View, 
  Text, 
  FlatList, 
  StyleSheet, 
  TouchableOpacity, 
  Linking,
  ActivityIndicator,
  SafeAreaView
} from 'react-native';
import { useGetContactDetailsQuery } from '@/store/api/card/mainApis';
import { Ionicons } from '@expo/vector-icons';
import CircleButton from "@/src/components/globals/CircleButton";
import { useRouter } from "expo-router";
import { spacingX, spacingY } from "@/constants/theme";
import Loading from '@/components/Loading';

const ContactList = () => {
  const router = useRouter();
  const { data, isLoading, isFetching, error, refetch } = useGetContactDetailsQuery();
  const handleCall = (phoneNumber: string) => {
    Linking.openURL(`tel:${phoneNumber}`);
  };

  const handleMessage = (phoneNumber: string) => {
    Linking.openURL(`sms:${phoneNumber}`);
  };

  const renderItem = ({ item }: any) => {
    const contact = item.ContactDetails;
    const hasPhoneNumber = contact.phoneNumber && contact.phoneNumber.trim() !== '';
    
    return (
      <View style={styles.contactCard}>
        <View style={styles.contactInfo}>
          <View style={styles.avatarContainer}>
            <Text style={styles.avatarText}>
              {contact.firstName ? contact.firstName.charAt(0).toUpperCase() : 'C'}
              {contact.lastName ? contact.lastName.charAt(0).toUpperCase() : ''}
            </Text>
          </View>
          <View style={styles.textContainer}>
            <Text style={styles.contactName} numberOfLines={1}>
              {`${contact.firstName || 'No Name'} ${contact.lastName || ''}`.trim()}
            </Text>
            <Text style={styles.contactPhone} numberOfLines={1}>
              {hasPhoneNumber ? contact.phoneNumber : 'No phone number'}
            </Text>
          </View>
        </View>
        
        {hasPhoneNumber && (
          <View style={styles.actionButtons}>
            <TouchableOpacity 
              style={styles.actionButton} 
              onPress={() => handleMessage(contact.phoneNumber)}
            >
              <Ionicons name="chatbubble" size={20} color="#3B82F6" />
            </TouchableOpacity>
            <TouchableOpacity 
              style={styles.actionButton} 
              onPress={() => handleCall(contact.phoneNumber)}
            >
              <Ionicons name="call" size={20} color="#10B981" />
            </TouchableOpacity>
          </View>
        )}
      </View>
    );
  };

  return (
    <SafeAreaView style={styles.safeArea}>
      <View style={styles.container}>
        {/* Header */}
        <View style={styles.headerContainer}>
          <CircleButton
            onPress={() => router.push("/(main)/home")}
            iconSource={require("@/assets/main/chevron-back.png")}
          />
          <Text style={styles.centerTitle}>All Contacts</Text>
          <CircleButton
            onPress={() => router.push("/(main)/home")}
            iconSource={require("@/assets/tab/home.png")}
          />
        </View>

        {/* Content */}
        {isLoading || isFetching ? (
            <Loading />
        ) : error ? (
          <View style={styles.centered}>
            <Ionicons name="alert-circle" size={48} color="#EF4444" />
            <Text style={styles.errorTitle}>Error loading contacts</Text>
            <TouchableOpacity style={styles.retryButton} onPress={refetch}>
              <Text style={styles.retryText}>Try Again</Text>
            </TouchableOpacity>
          </View>
        ) : data?.data && data.data.length > 0 ? (
          <FlatList
            data={data.data}
            keyExtractor={(item) => item._id}
            renderItem={renderItem}
            contentContainerStyle={styles.listContainer}
            showsVerticalScrollIndicator={false}
            refreshing={isLoading}
            onRefresh={refetch}
          />
        ) : (
          <View style={styles.centered}>
            <Ionicons name="people" size={48} color="#6B7280" />
            <Text style={styles.emptyTitle}>No contacts found</Text>
          </View>
        )}
      </View>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#0E0E0E',
  },
  container: {
    flex: 1,
    backgroundColor: '#0E0E0E',
    paddingHorizontal: spacingX._15,
    paddingTop: spacingY._10,
  },
  headerContainer: {
    marginBottom: spacingY._15,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    paddingTop: spacingY._5,
  },
  centerTitle: {
    textAlign: "center",
    color: "white",
    fontSize: 18,
    fontWeight: "600",
  },
  listContainer: {
    paddingBottom: spacingY._30,
  },
  contactCard: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: '#1A1A1A',
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
  },
  contactInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  avatarContainer: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#2D2D2D',
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: 12,
  },
  avatarText: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
  },
  textContainer: {
    flex: 1,
  },
  contactName: {
    color: 'white',
    fontSize: 16,
    fontWeight: '600',
    marginBottom: 2,
  },
  contactPhone: {
    color: '#999',
    fontSize: 14,
  },
  actionButtons: {
    flexDirection: 'row',
  },
  actionButton: {
    padding: 8,
    marginLeft: 8,
  },
  centered: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 20,
  },
  loadingText: {
    color: '#D1D5DB',
    fontSize: 16,
    marginTop: 16,
  },
  errorTitle: {
    color: 'white',
    fontSize: 18,
    fontWeight: '600',
    marginTop: 16,
    marginBottom: 16,
  },
  retryButton: {
    backgroundColor: '#6366F1',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 8,
  },
  retryText: {
    color: 'white',
    fontWeight: '500',
  },
  emptyTitle: {
    color: 'white',
    fontSize: 18,
    fontWeight: '600',
    marginTop: 16,
  },
});

export default ContactList;