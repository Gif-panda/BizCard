import { FlatList, StyleSheet, Text, View } from "react-native";
import React, { useState } from "react";
import { spacingX, spacingY } from "@/constants/theme";
import CircleButton from "@/src/components/globals/CircleButton";
import { useRouter } from "expo-router";
import TabButtons from "@/src/components/globals/TabButton";
import SearchBar from "@/src/components/common/main/SearchBar";
import SingleButton from "@/src/components/globals/single-card/SingleButton";
import TeamCard from "@/src/components/teams/components/TeamCard";
import { useSelector } from "react-redux";
import { useCardDetails } from "@/store/selectors/card/card";
import { useGetAllTeamsQuery } from "@/store/api/card/mainApis";
import { tabButtons } from "@/constants/categorySwitcher";
import useLoading from "@/src/hooks/useLoading";
import Loading from "@/components/Loading";

const Team = () => {
  const router = useRouter();
  const [selectedTab, setSelectedTab] = useState<any>("personal");
  const { jwt } = useSelector(useCardDetails);
  const { data, isLoading, isFetching } = useGetAllTeamsQuery(
    { category: selectedTab },
    { skip: !jwt }
  );

  const loading = useLoading([isLoading, isFetching]);

  return (
    <View style={styles.container}>
      <View style={styles.headerContainer}>
        <CircleButton onPress={() => router.push("/(main)/home")} iconSource={require("@/assets/main/cross-icon.png")} />
        <Text style={styles.centerTitle}>Teams</Text>
        <CircleButton iconSource={require("@/assets/main/qs-icon.png")} />
      </View>

      <TabButtons
        buttons={tabButtons}
        selectedTab={selectedTab}
        setSelectedTab={(index) => {
          if (index === 0) {
            setSelectedTab("personal");
          } else {
            setSelectedTab("business");
          }
        }}
      />
      <SearchBar />
      <View
        style={{
          paddingHorizontal: spacingX._12,
        }}
      >
        <SingleButton
          onPress={() => {
            router.push("/(main)/team/CreateTeams");
          }}
          title="+ create new team"
        />
      </View>

      <View style={styles.teamListHeader}>
        <Text style={styles.name}>Your Teams</Text>
        {/* <CircleButton iconSource={require('@/assets/main/menu-dot-icon.png')} /> */}
      </View>

      {loading ? (
        <Loading />
      ) : data?.teams?.length === 0 || !data?.teams ? (
        <Text
          style={{
            color: "#fff",
            fontSize: 12,
            textAlign: "center",
            marginTop: 20,
            fontStyle: "italic",
          }}
        >
          {`No ${selectedTab} Teams yet.\nCreate your first Contact and start sharing cards instantly!`}
        </Text>
      ) : (
        <FlatList
          style={{
            paddingHorizontal: spacingX._12,
          }}
          data={data?.teams}
          keyExtractor={(item) => item._id.toString()}
          renderItem={({ item }) => <TeamCard team={item} />}
          contentContainerStyle={{ paddingBottom: 20 }}
        />
      )}
    </View>
  );
};

export default Team;

const styles = StyleSheet.create({
  container: {
    backgroundColor: "#0E0E0E",
    flex: 1,
    justifyContent: "flex-start",
    paddingTop: spacingY._7,
  },
  name: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 16,
  },
  teamListHeader: {
    paddingHorizontal: spacingX._12,
    paddingVertical: spacingY._15,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  headerContainer: {
    backgroundColor: "#0E0E0E",
    display: "flex",
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "space-between",
    paddingTop: spacingY._7,
    paddingHorizontal: spacingX._12,
    marginBottom: spacingY._12,
  },
  centerTitle: {
    textAlign: "center",
    color: "white",
    fontSize: 18,
    fontWeight: "500",
  },
});
