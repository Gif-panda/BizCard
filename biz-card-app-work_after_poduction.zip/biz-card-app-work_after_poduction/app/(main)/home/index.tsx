import {
  Modal,
  Pressable,
  StyleSheet,
  TouchableOpacity,
  View,
} from "react-native";
import React, { useEffect, useState } from "react";
import { spacingY } from "@/constants/theme";
import ProfileHeader from "@/src/components/common/main/ProfileHeader";
import SearchBar from "@/src/components/common/main/SearchBar";
import TabButtons from "@/src/components/globals/TabButton";
import ContactTabs from "@/src/components/common/main/ContactTabs";
import CardList from "@/src/components/common/main/CardList";
import { useGetAllCardsQuery } from "@/store/api/card/mainApis";
import { useSelector } from "react-redux";
import { useCardDetails } from "@/store/selectors/card/card";
import useLoading from "@/src/hooks/useLoading";
import { tabButtons } from "@/constants/categorySwitcher";
import { Text } from "react-native-paper";
import IndustryTabs from "@/src/components/common/main/IndustryTabs";
import Animated, { SlideInRight, SlideOutRight } from "react-native-reanimated";
import { filterOptions } from "@/src/constants/tabs";

const Home = () => {
  const [selectedTab, setSelectedTab] = useState<any>("personal");
  const [subCategory, setSubCategory] = useState<any>("");
  const [industry, setIndustry] = useState("");
  const [name, setName] = useState("");
  const [selectedOption, setSelectedOption] = useState("By Category");
  const [modalVisible, setModalVisible] = useState(false);
  const [debouncedName, setDebouncedName] = useState(name);

  useEffect(() => {
    const handler = setTimeout(() => {
      setDebouncedName(name);
    }, 500);

    return () => {
      clearTimeout(handler);
    };
  }, [name]);

  const { jwt } = useSelector(useCardDetails);
  const { data, isLoading, isFetching, refetch } = useGetAllCardsQuery(
    {
      category: selectedTab,
      subCategory: selectedOption === "By Category" ? subCategory : "",
      industry: selectedOption === "By Industry" ? industry : "",
      name: debouncedName,
      myContact: false,
    },
    {
      skip: !jwt,
      refetchOnFocus: true,
      refetchOnReconnect: true,
      refetchOnMountOrArgChange: true,
    }
  );
  const loading = useLoading([isLoading, isFetching]);

  const handleSelect = (option: string) => {
    setSelectedOption(option);

    if (option === "By Category") {
      setIndustry(""); // clear industry
      setSubCategory(subCategory); // keep subCategory as is (or reset if you prefer)
    } else if (option === "By Industry") {
      setSubCategory(""); // clear category
      setIndustry(industry); // keep industry as is (or reset if you prefer)
    }

    setModalVisible(false);
  };

  //     const handleSelect = (option: string) => {
  //     setSelectedOption(option);

  //     if (option === 'By Category') {
  //         setSubCategory('');
  //     } else if (option === 'By Industry') {
  //         setIndustry('');
  //     }

  //     setModalVisible(false);
  // };

  return (
    <View style={styles.container}>
      <ProfileHeader />
      <TabButtons
        buttons={tabButtons}
        selectedTab={selectedTab}
        setSelectedTab={(index) => {
          if (index === 0) {
            setSelectedTab("personal");
          } else {
            setSelectedTab("business");
          }
        }}
      />

      <SearchBar
        setModalVisible={setModalVisible}
        setName={setName}
        name={name}
      />

      {selectedOption === "By Category" && (
        <Animated.View
          entering={SlideInRight}
          exiting={SlideOutRight}
          style={styles.animatedView}
        >
          <ContactTabs
            subCategory={subCategory}
            setSubCategory={setSubCategory}
          />
        </Animated.View>
      )}

      {selectedOption === "By Industry" && (
        <Animated.View
          entering={SlideInRight}
          exiting={SlideOutRight}
          style={styles.animatedView}
        >
          <IndustryTabs industry={industry} setIndustry={setIndustry} />
        </Animated.View>
      )}

      <CardList
        cardData={data?.data}
        loading={loading}
        category={selectedTab}
        refetch={refetch}
      />

      <Modal
        visible={modalVisible}
        transparent
        animationType="fade"
        onRequestClose={() => setModalVisible(false)}
      >
        <Pressable
          style={styles.overlay}
          onPress={() => setModalVisible(false)}
        >
          <View style={styles.popup}>
            {filterOptions.map((option, index) => (
              <TouchableOpacity
                key={index}
                onPress={() => handleSelect(option)}
                style={styles.option}
              >
                <Text
                  style={[
                    styles.optionText,
                    selectedOption === option && styles.selectedText,
                  ]}
                >
                  {option}
                </Text>
                {selectedOption === option && (
                  <Text style={styles.checkmark}>✓</Text>
                )}
              </TouchableOpacity>
            ))}
          </View>
        </Pressable>
      </Modal>
    </View>
  );
};

export default Home;

const styles = StyleSheet.create({
  container: {
    backgroundColor: "#0E0E0E",
    flex: 1,
    justifyContent: "flex-start",
    paddingTop: spacingY._7,
  },

  animatedView: {
    width: "100%",
    // position: 'absolute',
  },
  triggerText: {
    fontSize: 24,
    color: "white",
  },
  overlay: {
    flex: 1,
    paddingTop: 180,
    justifyContent: "flex-start",
    alignItems: "flex-end",
    paddingRight: 20,
    backgroundColor: "rgba(0, 0, 0, 0.3)",
  },
  popup: {
    backgroundColor: "#0F0F0F",
    borderRadius: 12,
    paddingVertical: 12,
    paddingHorizontal: 16,
    width: 180,
  },
  option: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingVertical: 10,
  },
  optionText: {
    color: "#fff",
    fontSize: 16,
  },
  selectedText: {
    fontWeight: "bold",
    color: "#ffffff",
  },
  checkmark: {
    color: "#fff",
    fontSize: 16,
  },
});
