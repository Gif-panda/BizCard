import {
  Dimensions,
  Image,
  Linking,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from "react-native";
import React, { useEffect, useState } from "react";
import { router, useLocalSearchParams } from "expo-router";
import { colors, spacingX, spacingY } from "@/constants/theme";
import SingleButton from "@/src/components/globals/single-card/SingleButton";
import CircleButton from "@/src/components/globals/CircleButton";
import OptionsList from "@/src/components/globals/OptionList";
import {
  optionsListOne,
  optionsListThree,
  optionsListTwo,
} from "@/src/constants/singleCard";
import { LinearGradient } from "expo-linear-gradient";
import { Picker } from "@react-native-picker/picker";
import { FormField } from "@/src/components/common/main/createCard/formField";
import {
  BASIC_COLORS,
  cardTemplates,
  CATEGORIES,
  COLORS,
  GRADIENT_COLORS,
  INDUSTRIES,
} from "@/src/constants/createCard";
import Feather from "@expo/vector-icons/Feather";
import Typo from "@/components/Typo";
import Input from "@/components/Input";
import {
  useDeleteCardMutation,
  useGetSingleCardDetailsQuery,
  useUpdateCardMutation,
} from "@/store/api/card/mainApis";
import {
  renderToastError,
  renderToastSuccess,
} from "@/src/components/globals/ToastNotification";
import * as ImagePicker from "expo-image-picker";
import SingleBizCard from "@/src/components/globals/single-card/SingleBizCard";
import AiOrganization from "@/src/components/common/main/AiOrganization";
import ProBadge from "@/src/components/globals/proBadge";
import { FontAwesome6 } from "@expo/vector-icons";
import RemoveWatermark from "@/src/components/common/main/removeWatermark";
import useLoading from "@/src/hooks/useLoading";
import { Dropdown } from "react-native-element-dropdown";
import ConfirmationModal from "@/src/components/globals/confirmationModal";
import { useSelector } from "react-redux";
import { useSubscriptionDetails } from "@/store/selectors/subscription/subscription";
import { RootState } from "@/store";

const screenWidth = Dimensions.get("window").width;
interface SocialLink {
  platform: string;
  url: string;
}
const SOCIAL_PLATFORMS = [
  { label: "LinkedIn", value: "LinkedIn", icon: "linkedin", color: "#0A66C2" },
  { label: "Twitter / X", value: "Twitter", icon: "x-twitter", color: "#000000" },
  { label: "Facebook", value: "Facebook", icon: "facebook", color: "#1877F2" },
  { label: "Instagram", value: "Instagram", icon: "instagram", color: "#E1306C" },
  { label: "YouTube", value: "YouTube", icon: "youtube", color: "#FF0000" },
  { label: "TikTok", value: "TikTok", icon: "tiktok", color: "#69C9D0" },
  { label: "GitHub", value: "GitHub", icon: "github", color: "#ffffff" },
  { label: "WhatsApp", value: "WhatsApp", icon: "whatsapp", color: "#25D366" },
  { label: "Telegram", value: "Telegram", icon: "telegram", color: "#2AABEE" },
  { label: "Snapchat", value: "Snapchat", icon: "snapchat", color: "#FFFC00" },
  { label: "Pinterest", value: "Pinterest", icon: "pinterest", color: "#E60023" },
  { label: "Reddit", value: "Reddit", icon: "reddit", color: "#FF4500" },
  { label: "Discord", value: "Discord", icon: "discord", color: "#5865F2" },
];

const getPlatformInfo = (platform: string) => {
  return SOCIAL_PLATFORMS.find((p) => p.value === platform) || { icon: "link", color: "#888" };
};

const CardSingle = () => {
  const params = useLocalSearchParams<{ id: string }>();
  const { id } = params;
  const subscriptionState = useSelector(useSubscriptionDetails);
  const isCouponVerified = useSelector(
    (state: RootState) => Boolean(state.card.userData?.couponVerfied)
  );
  const isProUser = subscriptionState.isBought || isCouponVerified;

  const {
    data,
    isLoading: getSingleDataLoading,
    isFetching,
  } = useGetSingleCardDetailsQuery(
    {
      cardId: id,
    },
    {
      skip: !id,
    }
  );

  const [updateCard, { isLoading }] = useUpdateCardMutation();
  const [otherIndustry, setOtherIndustry] = useState("");
  const [cardData, setCardData] = useState({
    ContactDetails: {
      firstName: "",
      lastName: "",
      email: "",
      phoneNumber: "",
      organization: "",
      position: "",
      category: "",
      subCategory: "",
      website: "",
      address: "",
      photo: "",
      logo: "",
      note: "",
      dataFromAi: "",
      industry: "",
      originalCard: "",
      socialLinks: [] as SocialLink[],
    },
    cardDetails: {
      cardName: "",
      waterMark: true,
      template: {
        useGradient: false,
        textColor: "",
        templateColor: "",
        templateType: "",
      },
    },
  });
  useEffect(() => {
    if (data) {
      setCardData(data?.Card);
      if (data?.Card?.ContactDetails?.industry === "Other") {
        setOtherIndustry(data?.Card?.ContactDetails?.otherIndustry || "");
      }
      // Initialize socialLinks if they exist in the response
      if (data?.Card?.ContactDetails?.socialLinks) {
        setCardData((prev) => ({
          ...prev,
          ContactDetails: {
            ...prev.ContactDetails,
            socialLinks: data.Card.ContactDetails.socialLinks,
          },
        }));
      }
    }
  }, [data]);

  const createFieldSetter =
    <
      Section extends keyof typeof cardData,
      Field extends keyof (typeof cardData)[Section]
    >(
      section: Section,
      field: Field
    ) =>
    (value: string | boolean) => {
      setCardData((prev) => ({
        ...prev,
        [section]: {
          ...prev[section],
          [field]: value,
        },
      }));
    };

  const renderColor = (color: any, index: number, isGradient = false) => {
    const isSelected =
      cardData.cardDetails.template.templateColor ===
      `${isGradient ? "gradient-" : "basic-"}${index}`;

    return (
      <TouchableOpacity
        key={index}
        style={styles.colorWrapper}
        onPress={() => {
          if (!color.premium || isProUser) {
            setCardData((prev) => ({
              ...prev,
              cardDetails: {
                ...prev.cardDetails,
                template: {
                  ...prev.cardDetails.template,
                  useGradient: isGradient,
                  templateColor: `${
                    isGradient ? "gradient-" : "basic-"
                  }${index}`,
                },
              },
            }));
          } else {
            renderToastError("Upgrade to Pro to access this gradient!");
          }
        }}
        disabled={color.premium && !isProUser}
      >
        {isGradient ? (
          <View
            style={[
              styles.gradientContainer,
              color.premium && !isProUser && styles.disabledGradient,
            ]}
          >
            <LinearGradient
              colors={color.colors}
              style={[styles.colorCircle, isSelected && styles.selectedCircle]}
            />
            {color.premium && !isProUser && (
              <View style={styles.gradientBadgeContainer}>
                <FontAwesome6 name="crown" size={12} color="gold" />
              </View>
            )}
          </View>
        ) : (
          <View
            style={[
              styles.colorCircle,
              { backgroundColor: color },
              isSelected && styles.selectedCircle,
            ]}
          />
        )}
      </TouchableOpacity>
    );
  };

  const handleImagePick = async (type: "photo" | "logo") => {
    const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
    if (status !== "granted") {
      renderToastSuccess("Permission to access media library is required!");
      return;
    }
    const result = await ImagePicker.launchImageLibraryAsync({
      mediaTypes: ImagePicker.MediaTypeOptions.Images,
      base64: true,
      allowsEditing: true,
      quality: 0.7,
    });

    if (!result.canceled && result?.assets?.[0]?.base64) {
      setCardData((prevData) => ({
        ...prevData,
        ContactDetails: {
          ...prevData.ContactDetails,
          [type]: `data:image/jpeg;base64,${result?.assets?.[0]?.base64}`,
        },
      }));
    }
  };
  const handleUpdateCard = async () => {
    try {
      const dataToSend = {
        ...cardData,
        ContactDetails: {
          ...cardData.ContactDetails,
          ...(cardData.ContactDetails.industry === "Other" && {
            otherIndustry: otherIndustry,
          }),
        },
      };
      const res = await updateCard(dataToSend).unwrap();
      renderToastSuccess(res?.data?.message || "card updated successfully");
    } catch (error: any) {
      renderToastError(error?.data?.message || "Error in updating card");
    }
  };

  const handleOrganizationData = (data: any) => {
    setCardData((prev) => ({
      ...prev,
      ContactDetails: {
        ...prev.ContactDetails,
        dataFromAi: data.dataFromAi,
      },
    }));
  };

  const addSocialLink = () => {
    setCardData((prev) => ({
      ...prev,
      ContactDetails: {
        ...prev.ContactDetails,
        socialLinks: [
          ...prev.ContactDetails.socialLinks,
          { platform: "", url: "" },
        ],
      },
    }));
  };

  const removeSocialLink = (index: number) => {
    setCardData((prev) => {
      const updatedLinks = [...prev.ContactDetails.socialLinks];
      updatedLinks.splice(index, 1);
      return {
        ...prev,
        ContactDetails: {
          ...prev.ContactDetails,
          socialLinks: updatedLinks,
        },
      };
    });
  };

  const updateSocialLink = (
    index: number,
    field: "platform" | "url",
    value: string
  ) => {
    setCardData((prev) => {
      const updatedLinks = prev.ContactDetails.socialLinks.map((link, i) => {
        if (i === index) {
          // Create a new object instead of mutating the existing one
          return {
            ...link,
            [field]: value,
          };
        }
        return link;
      });

      return {
        ...prev,
        ContactDetails: {
          ...prev.ContactDetails,
          socialLinks: updatedLinks,
        },
      };
    });
  };

  const [deleteModalVisible, setDeleteModalVisible] = useState(false);
  const [deleteCard, { isLoading: deleting }] = useDeleteCardMutation();
  const handleDeleteCard = async () => {
    try {
      if (!id) return;
      const response = await deleteCard(id).unwrap();
      renderToastSuccess("Card deleted successfully!");
      router.push("/(main)/home");
    } catch (error: any) {
      console.error("❌ Delete failed:", error);
      renderToastError("Failed to delete card");
    } finally {
      setDeleteModalVisible(false);
    }
  };

  const loading = useLoading([getSingleDataLoading, isFetching]);

  if (loading) return <CardSingleSkeleton />;

  return (
    <ScrollView contentContainerStyle={styles.container}>
      <View style={styles.headerContainer}>
        <CircleButton
          onPress={() => router.push("/(main)/home")}
          iconSource={require("@/assets/main/cross-icon.png")}
        />

        <Text style={styles.centerTitle}>Card Information</Text>
        <View style={{ flexDirection: "row", gap: 2 }}>
          <CircleButton
            onPress={() => {
              router.push({
                pathname: "/(main)/share",
                params: { cardDetails: JSON.stringify(cardData) },
              });
            }}
            iconSource={require("@/assets/main/share-icon.png")}
          />
          <CircleButton
            wrapperStyle={{
              backgroundColor: "red",
              opacity: 0.8,
              borderColor: "red",
              borderWidth: 1,
            }}
            onPress={() => {
              setDeleteModalVisible(true);
            }}
            iconSource={require("@/assets/main/delete-icon.png")}
          />
        </View>
      </View>
      {cardData?.ContactDetails?.originalCard ? (
        <View
          style={{
            marginVertical: 10,
          }}
        >
          <Text style={styles.sectionTitle}>Original Card</Text>
          <Image
            source={{ uri: `${cardData?.ContactDetails?.originalCard}` }}
            style={{
              width: "100%",
              height: 194,
              objectFit: "fill",
              borderRadius: 20,
            }}
            resizeMode="contain"
          />
        </View>
      ) : (
      <View
        style={{
          marginVertical: 10,
        }}
      >
        <SingleBizCard cardDetails={cardData} isProUser={isProUser} />
      </View>
      )}

      <Text style={styles.newlabel}>Data From AI</Text>

      <TextInput
        value={cardData?.ContactDetails?.dataFromAi || ""}
        onChangeText={createFieldSetter("ContactDetails", "dataFromAi")}
        numberOfLines={8}
        style={styles.dataFromAiInput}
        placeholderTextColor="white"
        placeholder="Data from AI will appear here..."
        multiline
      />
      <Text style={styles.aiWarning}>
        AI-generated data may be incorrect. Please review carefully.
      </Text>

      <AiOrganization
        name={
          cardData?.ContactDetails?.firstName +
          " " +
          cardData?.ContactDetails?.lastName
        }
        onDataFetched={handleOrganizationData}
      />

      <FormField
        value={cardData?.ContactDetails?.firstName}
        label="First Name"
        placeholder="e.g John"
        onChangeText={createFieldSetter("ContactDetails", "firstName")}
      />

      <FormField
        value={cardData?.ContactDetails?.lastName}
        label="Last Name"
        placeholder="e.g Doe"
        onChangeText={createFieldSetter("ContactDetails", "lastName")}
      />

      <FormField
        value={cardData?.ContactDetails?.email}
        label="Email"
        placeholder="e.g john@gmail.com"
        onChangeText={createFieldSetter("ContactDetails", "email")}
      />
      <View style={styles.phoneContainer}>
        <View style={styles.phoneField}>
          <FormField
            value={cardData?.ContactDetails?.phoneNumber}
            label="Phone Number"
            placeholder="e.g +443232211232"
            onChangeText={createFieldSetter("ContactDetails", "phoneNumber")}
          />
        </View>

        <TouchableOpacity
          onPress={() =>
            Linking.openURL(`tel:${cardData.ContactDetails.phoneNumber}`)
          }
          style={styles.phoneIcon}
        >
          <Feather name="phone" size={20} color="#fff" />
        </TouchableOpacity>
      </View>

      <FormField
        value={cardData?.ContactDetails?.organization}
        label="Organization"
        placeholder="e.g Tech Solutions Ltd"
        onChangeText={createFieldSetter("ContactDetails", "organization")}
      />

      <FormField
        value={cardData?.ContactDetails?.position}
        label="Position"
        placeholder="e.g Manager, UI Expert"
        onChangeText={createFieldSetter("ContactDetails", "position")}
      />

      <FormField
        value={cardData?.ContactDetails?.website}
        label="Website"
        placeholder="e.g https://www.techsolutions.com"
        onChangeText={createFieldSetter("ContactDetails", "website")}
      />

      <FormField
        value={cardData?.ContactDetails?.address}
        label="Complete Address"
        placeholder="e.g h no 10 st no 12"
        onChangeText={createFieldSetter("ContactDetails", "address")}
      />

      <FormField
        value={cardData?.ContactDetails?.note}
        label="Note"
        placeholder="Write note here.."
        onChangeText={createFieldSetter("ContactDetails", "note")}
      />

      <Text style={styles.sectionTitle}>Sub Category</Text>
      <Dropdown
        style={styles.dropdown}
        containerStyle={styles.dropdownContainer}
        itemContainerStyle={styles.dropdownItem}
        selectedTextStyle={{ color: "gray" }}
        placeholderStyle={{ color: "gray" }}
        itemTextStyle={styles.itemText}
        activeColor="#222"
        data={CATEGORIES}
        labelField="label"
        valueField="value"
        placeholder="Select Sub Category"
        value={cardData.ContactDetails.subCategory}
        onChange={(item) =>
          setCardData((prev) => ({
            ...prev,
            ContactDetails: { ...prev.ContactDetails, subCategory: item.value },
          }))
        }
      />

      <Text style={styles.sectionTitle}>Industry</Text>
      <Dropdown
        style={styles.dropdown}
        containerStyle={styles.dropdownContainer}
        itemContainerStyle={styles.dropdownItem}
        selectedTextStyle={{ color: "gray" }}
        placeholderStyle={{ color: "gray" }}
        itemTextStyle={styles.itemText}
        activeColor="#222"
        data={INDUSTRIES}
        labelField="label"
        valueField="value"
        placeholder="Select Industry"
        value={cardData.ContactDetails.industry}
        onChange={(item) =>
          setCardData((prev) => ({
            ...prev,
            ContactDetails: { ...prev.ContactDetails, industry: item.value },
          }))
        }
      />

      {cardData.ContactDetails.industry === "Other" && (
        <View style={{ marginTop: 10 }}>
          <FormField
            value={otherIndustry}
            label="Specify Industry"
            placeholder="Write your industry"
            onChangeText={setOtherIndustry}
          />
        </View>
      )}

      <Text style={styles.sectionTitle}>Social Links</Text>

      {cardData.ContactDetails.socialLinks.map((link, index) => {
        const platformInfo = getPlatformInfo(link.platform);
        return (
          <View key={index} style={styles.socialLinkContainer}>
            {/* Card header */}
            <View style={styles.socialLinkHeader}>
              <View style={[styles.platformIconBadge, { backgroundColor: platformInfo.color + "22" }]}>
                <FontAwesome6 name={platformInfo.icon as any} size={16} color={platformInfo.color} />
              </View>
              <Text style={styles.socialLinkTitle}>
                {link.platform || `Social Link ${index + 1}`}
              </Text>
              <TouchableOpacity style={styles.removeButton} onPress={() => removeSocialLink(index)}>
                <Feather name="trash-2" size={16} color="#FF3B30" />
              </TouchableOpacity>
            </View>

            {/* Divider */}
            <View style={styles.socialDivider} />

            {/* Platform Dropdown */}
            <Text style={styles.socialFieldLabel}>Platform</Text>
            <Dropdown
              style={styles.socialDropdown}
              containerStyle={styles.dropdownContainer}
              itemContainerStyle={styles.dropdownItem}
              selectedTextStyle={{ color: "white", fontSize: 13 }}
              placeholderStyle={{ color: "gray", fontSize: 13 }}
              itemTextStyle={styles.itemText}
              activeColor="#222"
              data={SOCIAL_PLATFORMS}
              labelField="label"
              valueField="value"
              placeholder="Select platform"
              value={link.platform}
              onChange={(item) => updateSocialLink(index, "platform", item.value)}
              renderLeftIcon={() =>
                link.platform ? (
                  <FontAwesome6
                    name={getPlatformInfo(link.platform).icon as any}
                    size={14}
                    color={getPlatformInfo(link.platform).color}
                    style={{ marginRight: 8 }}
                  />
                ) : (
                  <Feather name="grid" size={14} color="#888" style={{ marginRight: 8 }} />
                )
              }
            />

            {/* URL Input */}
            <Text style={[styles.socialFieldLabel, { marginTop: 12 }]}>Profile URL</Text>
            <View style={styles.urlInputWrapper}>
              <Feather name="link-2" size={14} color="#888" style={styles.urlIcon} />
              <TextInput
                placeholder="https://..."
                placeholderTextColor="#555"
                value={link.url}
                onChangeText={(value) => updateSocialLink(index, "url", value)}
                style={styles.urlInput}
              />
            </View>
          </View>
        );
      })}

      <TouchableOpacity style={styles.addButton} onPress={addSocialLink}>
        <View style={styles.addButtonInner}>
          <Feather name="plus-circle" size={18} color="#00FF99" />
          <Text style={styles.addButtonText}>Add Social Link</Text>
        </View>
      </TouchableOpacity>

      {!cardData?.ContactDetails?.originalCard && <Text style={styles.sectionTitle}>Upload Images</Text>}

      {!cardData?.ContactDetails?.originalCard && (
      <TouchableOpacity
        style={styles.uploadButton}
        onPress={() => handleImagePick("photo")}
      >
        <Text style={styles.uploadText}>Upload Your Photo</Text>
        <Feather name="upload-cloud" size={20} color="white" />
      </TouchableOpacity>
      )}

      {!cardData?.ContactDetails?.originalCard && (
      <TouchableOpacity
        style={styles.uploadButton}
        onPress={() => handleImagePick("logo")}
      >
        <Text style={styles.uploadText}>Upload Business Logo</Text>

        <Feather name="upload-cloud" size={20} color="white" />
      </TouchableOpacity>
      )}

      {!cardData?.ContactDetails?.originalCard && (
      <View
        style={{
          flexDirection: "row",
          gap: 10,
          marginTop: 10,
          display: "flex",
          justifyContent: "center",
        }}
      >
        {cardData?.ContactDetails?.photo !== "none" && (
          <Image
            source={{ uri: cardData?.ContactDetails?.photo }}
            style={styles.imagePreview}
          />
        )}
        {cardData?.ContactDetails?.logo !== "none" && (
          <Image
            source={{ uri: cardData?.ContactDetails?.logo }}
            style={styles.imagePreview}
          />
        )}
      </View>
      )}

      {!cardData?.ContactDetails?.originalCard && !isProUser ? <RemoveWatermark /> : null}
      {!cardData?.ContactDetails?.originalCard && <Text style={styles.sectionTitle}>Card Details</Text>}
      {!cardData?.ContactDetails?.originalCard && <Text style={styles.sectionSubTitle}>
        Edit the name and appearance of the card.
      </Text>}

      {!cardData?.ContactDetails?.originalCard && (
      <View style={styles.formInner}>
        <Typo size={12} color="white">
          Card Name
        </Typo>
        <Input
          containerStyle={{
            borderRadius: 40,
          }}
          onChangeText={createFieldSetter("cardDetails", "cardName")}
          inputStyle={{
            color: "white",
          }}
          placeholder="Business Card"
        />
      </View>
      )}

      {!cardData?.ContactDetails?.originalCard && <Text style={styles.sectionTitle}>Select Your Template </Text>}

      {!cardData?.ContactDetails?.originalCard && (
      <View style={styles.grid}>
        {cardTemplates.map((template) => {
          const isDisabled = template.premium && !isProUser;

          return (
            <View key={template.id}>
              <TouchableOpacity
                onPress={() => {
                  if (!isDisabled) {
                    setCardData((prev) => ({
                      ...prev,
                      cardDetails: {
                        ...prev.cardDetails,
                        template: {
                          ...prev.cardDetails.template,
                          templateType: template.id,
                        },
                      },
                    }));
                  } else {
                    renderToastError("Upgrade to Pro to access this template!");
                  }
                }}
                style={[
                  styles.cardWrapper,
                  cardData.cardDetails.template.templateType === template.id &&
                    styles.selectedCard,
                  isDisabled && styles.disabledCard,
                ]}
                disabled={isDisabled}
              >
                <View style={styles.templateContainer}>
                  <Image
                    source={template.image}
                    style={[
                      styles.cardImage,
                      isDisabled && styles.disabledImage,
                    ]}
                    resizeMode="contain"
                  />

                  {template.premium && !isProUser && (
                    <View style={styles.badgeContainer}>
                      <ProBadge />
                    </View>
                  )}
                </View>
              </TouchableOpacity>
              <Text style={styles.cardLabel}>{template.name}</Text>
            </View>
          );
        })}
      </View>
      )}

      {!cardData?.ContactDetails?.originalCard && <Text style={styles.sectionTitle}>Template Color</Text>}

      {!cardData?.ContactDetails?.originalCard && (
      <View
        style={{
          paddingHorizontal: spacingX._10,
          paddingBottom: 10,
        }}
      >
        <Text style={styles.subHeader}>Basic</Text>
        <View style={styles.row}>
          {BASIC_COLORS.map((color, index) => renderColor(color, index))}
        </View>

        <Text style={styles.subHeader}>Gradiant</Text>
        <View style={[styles.row, { marginTop: 10 }]}>
          {GRADIENT_COLORS.map((color, index) =>
            renderColor(color, index, true)
          )}
        </View>
      </View>
      )}

      {!cardData?.ContactDetails?.originalCard && (
      <View>
        <Text style={styles.newlabel}>Text Color</Text>
        <View style={styles.newrow}>
          <Dropdown
            style={styles.colorDropdown}
            containerStyle={styles.dropdownContainer}
            itemContainerStyle={styles.dropdownItem}
            selectedTextStyle={{ color: "gray" }}
            placeholderStyle={{ color: "gray" }}
            itemTextStyle={styles.itemText}
            activeColor="#222"
            data={COLORS}
            labelField="label"
            valueField="value"
            placeholder="Select Color"
            value={cardData.cardDetails.template.textColor}
            onChange={(item) =>
              setCardData((prev) => ({
                ...prev,
                cardDetails: {
                  ...prev.cardDetails,
                  template: {
                    ...prev.cardDetails.template,
                    textColor: item.value,
                  },
                },
              }))
            }
          />
          <View
            style={[
              styles.colorPreview,
              { backgroundColor: cardData.cardDetails.template.textColor },
            ]}
          />
        </View>
      </View>
      )}

      <View style={{ gap: 10, marginBottom: 10 }}>
        <SingleButton
          disabled={
            !cardData.ContactDetails.email ||
            !cardData.ContactDetails.firstName ||
            !cardData.ContactDetails.lastName
          }
          loading={isLoading}
          onPress={() => {
            handleUpdateCard();
          }}
          title="Update"
        />
      </View>
      <ConfirmationModal
        visible={deleteModalVisible}
        title="Delete Card"
        message="Are you sure you want to delete this card?"
        confirmText="Delete"
        cancelText="No"
        onConfirm={handleDeleteCard}
        onCancel={() => setDeleteModalVisible(false)}
        loading={deleting}
      />
    </ScrollView>
  );
};

export default CardSingle;

const CardSingleSkeleton = () => {
  return (
    <ScrollView contentContainerStyle={styles.container}>
      <View style={styles.headerContainer}>
        <View style={styles.skeletonCircle} />
        <View style={[styles.skeletonLine, { width: 130, height: 18 }]} />
        <View style={styles.skeletonRow}>
          <View style={styles.skeletonCircle} />
          <View style={styles.skeletonCircle} />
        </View>
      </View>

      <View style={[styles.skeletonBlock, { height: 190, marginTop: 10 }]} />
      <View style={[styles.skeletonBlock, { height: 160 }]} />
      <View style={[styles.skeletonBlock, { height: 110 }]} />

      <View style={[styles.skeletonLine, { width: 120, marginTop: 8 }]} />
      <View style={[styles.skeletonBlock, { height: 52 }]} />
      <View style={[styles.skeletonBlock, { height: 52 }]} />
      <View style={[styles.skeletonBlock, { height: 52 }]} />
      <View style={[styles.skeletonBlock, { height: 52 }]} />
      <View style={[styles.skeletonBlock, { height: 52 }]} />
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: "#0E0E0E",
    paddingTop: spacingY._7,
    paddingHorizontal: spacingX._12,
    paddingBottom: spacingY._12,
  },
  headerContainer: {
    backgroundColor: "#0E0E0E",
    display: "flex",
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "space-between",
    paddingTop: spacingY._7,
  },
  centerTitle: {
    textAlign: "center",
    color: "white",
    fontSize: 18,
    fontWeight: "500",
  },
  optionsContainer: {
    marginTop: spacingY._30,
  },
  phoneContainer: {
    flexDirection: "row",
    width: "100%",
    alignItems: "center",
    gap: 8,
  },

  phoneField: {
    flex: 1,
  },

  phoneIcon: {
    padding: 14,
    borderRadius: 32,
    marginTop: 12,
    backgroundColor: "#222",
    justifyContent: "center",
    alignItems: "center",
  },

  bottomSheetheading: {
    color: "white",
    fontSize: 16,
    fontWeight: "500",
    marginBottom: 12,
  },

  containerBottomSheet: {
    flex: 1,
    padding: 20,
    backgroundColor: "#000",
  },

  constainer: {
    backgroundColor: "#0E0E0E",
    justifyContent: "flex-start",
    paddingTop: spacingY._7,
    paddingHorizontal: spacingX._12,
  },
  formInner: {
    gap: spacingY._10,
    marginBottom: 10,
  },

  aiWarning: {
    color: "#FFA500",
    fontSize: 12,
    marginTop: 4,
    fontStyle: "italic",
  },

  sectionTitle: {
    color: "#fff",
    fontSize: 14,
    paddingVertical: 10,
  },

  sectionSubTitle: {
    color: "#fff",
    fontSize: 12,
    marginBottom: 8,
  },
  card: {
    backgroundColor: "#1a1a1a",
    borderRadius: 30,
    marginBottom: 20,
    borderColor: "#383637",
    borderWidth: 2,
    paddingBottom: 10,
  },
  templateContainer: {
    width: "100%",
    position: "relative",
  },
  badgeContainer: {
    position: "absolute",
    bottom: 33,
    right: 0,
    backgroundColor: "rgba(0,0,0,0.1)",
  },
  disabledCard: {
    opacity: 0.9,
  },
  disabledImage: {
    opacity: 0.7,
  },
  gradientContainer: {
    position: "relative",
  },
  gradientBadgeContainer: {
    position: "absolute",
    top: -15,
    right: -5,
    zIndex: 1,
  },
  disabledGradient: {
    opacity: 0.6,
  },
  cardTitle: {
    color: "#fff",
    fontSize: 14,
    fontWeight: "600",
    paddingHorizontal: 20,
    paddingTop: 20,
  },
  inputContainer: {
    padding: 10,
  },
  label: {
    color: "white",
    fontSize: 12,
    backgroundColor: "#111",
  },
  required: { color: "red" },
  inputRow: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#111",
    borderRadius: 8,
    paddingHorizontal: 8,
    marginTop: 4,
  },
  input: {
    flex: 1,
    backgroundColor: "transparent",
    color: "#fff",
  },
  uploadButton: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#222",
    paddingVertical: 12,
    paddingHorizontal: 16,
    borderRadius: 30,
    marginTop: 4,
    marginBottom: 4,
    justifyContent: "space-between",
  },
  uploadText: { color: "#fff", fontSize: 14 },
  heading: {
    fontSize: 22,
    fontWeight: "bold",
    color: "#fff",
    marginBottom: 16,
  },
  imagePreview: {
    width: 100,
    height: 100,
    marginTop: 4,
    marginBottom: 8,
    borderRadius: 10,
  },
  grid: {
    flexDirection: "row",
    flexWrap: "wrap",
    justifyContent: "space-between",
  },
  dropdown: {
    height: 50,
    borderColor: "#383637",
    borderWidth: 1,
    borderRadius: 30,
    paddingHorizontal: 16,
    backgroundColor: "#111",
    marginBottom: 10,
    width: "100%",
  },
  colorDropdown: {
    height: 50,
    borderColor: "#383637",
    borderWidth: 1,
    borderRadius: 30,
    paddingHorizontal: 16,
    backgroundColor: "#111",
    marginBottom: 10,
    width: "80%",
  },
  dropdownContainer: {
    backgroundColor: "#111",
    borderRadius: 12,
    borderColor: "#383637",
    borderWidth: 1,
  },
  dropdownItem: {
    backgroundColor: "#111",
    borderRadius: 12,
  },
  dropdownSelectedItem: {
    backgroundColor: "#222",
  },
  itemText: {
    color: "#fff",
    fontSize: 14,
  },
  cardWrapper: {
    width: (screenWidth - 48) / 2,
    backgroundColor: "#111",
    padding: 8,
    borderRadius: 12,
    borderWidth: 2,
    borderColor: "#222",
    alignItems: "center",
  },
  selectedCard: {
    borderColor: "#00FF99",
    borderWidth: 1,
  },
  cardImage: {
    width: "100%",
    height: 80,
    borderRadius: 8,
  },
  cardLabel: {
    color: "#fff",
    marginTop: 4,
    fontWeight: "600",
    fontSize: 14,
    textAlign: "center",
    marginBottom: 10,
  },
  header: {
    color: "white",
    fontSize: 18,
    fontWeight: "600",
    marginBottom: 10,
  },
  subHeader: {
    color: "#aaa",
    marginTop: 12,
    marginBottom: 8,
  },
  row: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 2,
  },
  colorWrapper: {
    marginRight: 12,
    marginBottom: 12,
    position: "relative",
  },
  colorCircle: {
    width: 30,
    height: 30,
    borderRadius: 20,
  },
  selectedCircle: {
    borderWidth: 2,
    borderRadius: 20,
    borderColor: "#00FFCC",
  },
  crownIcon: {
    position: "absolute",
    top: -5,
    left: -5,
  },
  newlabel: {
    color: "white",
    marginVertical: 6,
    fontSize: 14,
  },
  newrow: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 20,
  },
  picker: {
    height: 50,
    width: 150,
    color: "white",
    backgroundColor: "#222",
  },
  categoryPicker: {
    height: 50,
    width: "100%",
    color: "white",
    backgroundColor: "#222",
  },
  socialLinkContainer: {
    backgroundColor: "#161616",
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: "#2a2a2a",
  },
  socialLinkHeader: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
    marginBottom: 4,
  },
  platformIconBadge: {
    width: 34,
    height: 34,
    borderRadius: 10,
    alignItems: "center",
    justifyContent: "center",
  },
  socialLinkTitle: {
    flex: 1,
    color: "#fff",
    fontSize: 14,
    fontWeight: "600",
  },
  socialDivider: {
    height: 1,
    backgroundColor: "#2a2a2a",
    marginVertical: 12,
  },
  socialFieldLabel: {
    color: "#888",
    fontSize: 11,
    fontWeight: "500",
    textTransform: "uppercase",
    letterSpacing: 0.8,
    marginBottom: 6,
  },
  socialDropdown: {
    backgroundColor: "#111",
    borderRadius: 10,
    paddingHorizontal: 12,
    height: 48,
    borderWidth: 1,
    borderColor: "#2a2a2a",
  },
  urlInputWrapper: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#111",
    borderRadius: 10,
    borderWidth: 1,
    borderColor: "#2a2a2a",
    paddingLeft: 12,
    height: 48,
  },
  urlIcon: {
    marginRight: 6,
  },
  urlInput: {
    flex: 1,
    backgroundColor: "transparent",
    height: 48,
    color: "#fff",
    fontSize: 13,
    paddingHorizontal: 4,
  },
  socialInput: {
    backgroundColor: "#111",
    borderRadius: 8,
    paddingHorizontal: 12,
    marginTop: 4,
    height: 50,
    color: "#fff",
  },
  removeButton: {
    padding: 6,
    borderRadius: 8,
    backgroundColor: "#FF3B3011",
    alignItems: "center",
    justifyContent: "center",
  },
  addButton: {
    marginTop: 4,
    marginBottom: 20,
  },
  addButtonInner: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "#0d1f14",
    padding: 14,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: "#00FF9933",
    gap: 8,
  },
  addButtonText: {
    color: "#00FF99",
    fontWeight: "600",
    fontSize: 14,
  },
  colorPreview: {
    width: 30,
    height: 30,
    borderRadius: 15,
    marginLeft: 10,
    borderWidth: 1,
    borderColor: "#fff",
  },
  fontRow: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 20,
  },
  counterRow: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
  },
  counterButton: {
    backgroundColor: "#222",
    padding: 10,
    height: 40,
    width: 40,
    textAlign: "center",
    alignItems: "center",
    borderRadius: 20,
    marginHorizontal: 15,
  },
  counterText: {
    color: "white",
    fontSize: 20,
  },
  fontSizeText: {
    color: "white",
    fontSize: 18,
  },
  dataFromAiInput: {
    flex: 1,
    borderWidth: 1,
    borderColor: "#dadce0",
    color: "white",
    borderRadius: 16,
    padding: 8,
    fontSize: 16,
    textAlignVertical: "top",
    height: 100,
    marginVertical: 4,
  },
  skeletonRow: {
    flexDirection: "row",
    alignItems: "center",
    gap: 8,
  },
  skeletonCircle: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: "#1B1B1B",
  },
  skeletonLine: {
    height: 14,
    borderRadius: 8,
    backgroundColor: "#1B1B1B",
  },
  skeletonBlock: {
    width: "100%",
    borderRadius: 16,
    backgroundColor: "#1B1B1B",
    marginBottom: 12,
  },
});
