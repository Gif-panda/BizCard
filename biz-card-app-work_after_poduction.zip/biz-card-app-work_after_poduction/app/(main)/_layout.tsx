import { StyleSheet } from "react-native";
import React from "react";
import { Tabs } from "expo-router";
import TabBar from "@/src/components/main/TabBar";

const _layout = () => {
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarHideOnKeyboard: true,
      }}
      tabBar={(props: any) => <TabBar {...props} />}
    >
      <Tabs.Screen name="home" options={{ title: "Home" }} />
      <Tabs.Screen name="Team" options={{ title: "Team" }} />
      <Tabs.Screen name="Cards" options={{ title: "Cards" }} />
      <Tabs.Screen name="Share" options={{ title: "Share" }} />
    </Tabs>
  );
};

export default _layout;

const styles = StyleSheet.create({});
