import { StyleSheet, Text, View } from "react-native";
import React, { useEffect, useState } from "react";
import { colors, spacingX, spacingY } from "@/constants/theme";
import SingleBizCard from "@/src/components/globals/single-card/SingleBizCard";
import CircleButton from "@/src/components/globals/CircleButton";
import SingleButton from "@/src/components/globals/single-card/SingleButton";
import { useRouter } from "expo-router";
import { useLocalSearchParams } from "expo-router";
import { useGetAllCardsQuery } from "@/store/api/card/mainApis";
import { useSelector } from "react-redux";
import useLoading from "@/src/hooks/useLoading";
import { useCardDetails } from "@/store/selectors/card/card";
import TabButtons from "@/src/components/globals/TabButton";
import { tabButtons } from "@/constants/categorySwitcher";
import CardList from "@/src/components/common/main/CardList";
import { useSubscriptionDetails } from "@/store/selectors/subscription/subscription";
import { RootState } from "@/store";

const Cards = () => {
  const router = useRouter();
  const [selectedTab, setSelectedTab] = useState<any>("personal");
  const { jwt } = useSelector(useCardDetails);
  const { data, isLoading, isFetching } = useGetAllCardsQuery(
    { category: selectedTab },
    { skip: !jwt },
  );
  const subscriptionState = useSelector(useSubscriptionDetails);
  const isCouponVerified = useSelector((state: RootState) =>
    Boolean(state.card.userData?.couponVerfied),
  );
  const isProUser = subscriptionState.isBought || isCouponVerified;
  const loading = useLoading([isLoading, isFetching]);
  return (
    <View style={styles.constainer}>
      <View style={styles.headerContainer}>
        <CircleButton
          onPress={() => router.push("/(main)/home")}
          iconSource={require("@/assets/main/cross-icon.png")}
        />
        <Text style={styles.centerTitle}>Card</Text>
        <CircleButton
          onPress={() => router.push("/(main)/settings")}
          iconSource={require("@/assets/settings/account-icon.png")}
        />
      </View>
      <SingleBizCard
        isProUser={isProUser}
        cardDetails={{
          cardDetails: {
            cardName: "",
            waterMark: true,
            template: {
              templateType: "classic",
              useGradient: true,
              templateColor: "basic-1",
              textColor: "#808080",
            },
          },
          ContactDetails: {
            firstName: "John",
            lastName: "Doe",
            organization: "Tech Agency",
            position: "Software Engineer",
            email: "test@gmail.com",
            phoneNumber: "123-456-7890",
            photo: "",
          },
        }}
      />

      <SingleButton
        onPress={() => {
          router.push("/(main)/cards/CreateCards");
        }}
        title="+ Create New Card"
      />

      {/* <TabButtons
                buttons={tabButtons}
                selectedTab={selectedTab}
                setSelectedTab={(index) => {
                    if (index === 0) {
                        setSelectedTab('personal');
                    } else {
                        setSelectedTab('business');
                    }
                }}
            />
            <CardList cardData={data?.data} loading={loading} category={selectedTab} /> */}
    </View>
  );
};

export default Cards;

const styles = StyleSheet.create({
  constainer: {
    backgroundColor: "#0E0E0E",
    flex: 1,
    justifyContent: "flex-start",
    paddingTop: spacingY._7,
    paddingHorizontal: spacingX._12,
  },
  headerContainer: {
    backgroundColor: "#0E0E0E",
    display: "flex",
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "space-between",
    paddingTop: spacingY._7,
    marginBottom: spacingY._12,
  },
  centerTitle: {
    textAlign: "center",
    color: "white",
    fontSize: 18,
    fontWeight: "500",
  },
});
