import { ScrollView, StyleSheet, Text, TouchableOpacity, View } from 'react-native';
import React, { useEffect, useState } from 'react';
import { spacingX, spacingY } from '@/constants/theme';
import CircleButton from '@/src/components/globals/CircleButton';
import TabButtons from '@/src/components/globals/TabButton';
import { tabButtons, teamsButtons } from '@/constants/categorySwitcher';
import Typo from '@/components/Typo';
import Input from '@/components/Input';
import TeamTabs from '@/src/components/globals/TeamTabs';
import SingleButton from '@/src/components/globals/single-card/SingleButton';
import { useCreateTeamMutation, useGetAllUsersQuery, useJoinTeamMutation } from '@/store/api/card/mainApis';
import { AnimatePresence, MotiView } from 'moti';
import { useRouter } from 'expo-router';
import { renderToastError, renderToastSuccess } from '@/src/components/globals/ToastNotification';
import * as ImagePicker from 'expo-image-picker';
import Feather from '@expo/vector-icons/Feather';
import { Image } from 'react-native';


const CreateTeams = () => {
    const [category, setCategory] = useState<any>('personal');
    const [selectedTab, setSelectedTab] = useState<any>('createTeam');
    const [teamId, setTeamId] = useState<any>('');
    const [createATeam, setCreateATeam] = useState<any>({
        logo: '',
        teamName: '',
    });

    const [createTeam, { isLoading }] = useCreateTeamMutation();
    const [joinTeam, { isLoading: joinTeamIsLoading }] = useJoinTeamMutation();

    const handleSubmit = async () => {
        try {

            const res: any = createTeam({
                type: category,
                teamName: createATeam.teamName,
                logo: createATeam.logo,
            }).unwrap();

            setCreateATeam(
                {
                    logo: '',
                    teamName: '',
                }
            );
            renderToastSuccess(res?.data?.message || 'Team Created Successfully');
        } catch (error: any) {
            renderToastError(error?.message || 'Error creating team');
        }
    };

    const handleJoinTeamSubmit = async () => {
        try {
            const res: any = joinTeam({
                teamId: teamId,
            }).unwrap();
            setTeamId('');
            renderToastSuccess(res?.data?.message || 'JOin Team Successfully');
        } catch (error: any) {
            renderToastError(error?.message || 'Error joining team');
        }
    };

    const handleImagePick = async () => {

        const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();

        if (status !== 'granted') {
            renderToastError("Permission to access media library is required!")
            return;
        }

        const result = await ImagePicker.launchImageLibraryAsync({
            mediaTypes: ImagePicker.MediaTypeOptions.Images,
            base64: true,
            allowsEditing: true,
            quality: 0.7,
        });

        if (!result.canceled && result?.assets?.[0]?.base64) {
            setCreateATeam((prevData: any) => ({
                ...prevData,
                logo: `data:image/jpeg;base64,${result?.assets?.[0]?.base64}`,
            }));
        }
    };

    useEffect(() => {
        (async () => {
            const { status } = await ImagePicker.requestMediaLibraryPermissionsAsync();
            if (status !== 'granted') {
                renderToastError("Permission to access media library is required!")
            }
        })();
    }, []);
    const router = useRouter();
    return (
        <ScrollView contentContainerStyle={[styles.container, { flexGrow: 1 }]}>
            <View style={styles.headerContainer}>
                <CircleButton onPress={() => {
                    router.push('/(main)/team');

                }} iconSource={require('@/assets/main/cross-icon.png')} />
                <Text style={styles.centerTitle}>Create Team </Text>
                <CircleButton
                    iconSource={require('@/assets/settings/account-icon.png')}
                />
            </View>

            <TabButtons
                buttons={tabButtons}
                selectedTab={category}
                setSelectedTab={(index) => {
                    if (index === 0) {
                        setCategory('personal');
                    } else {
                        setCategory('business');
                    }
                }}
            />

            <View
                style={{
                    marginHorizontal: spacingX._30,
                    marginBottom: spacingY._20,
                    marginTop: spacingY._40,
                }}
            >
                <TeamTabs
                    buttons={teamsButtons}
                    selectedTab={selectedTab}
                    setSelectedTab={(index) => {
                        if (index === 0) {
                            setSelectedTab('createTeam');
                        } else {
                            setSelectedTab('joinTeam');
                        }
                    }}
                />
            </View>

            <AnimatePresence exitBeforeEnter>
                {selectedTab === 'createTeam' ? (
                    <MotiView
                        key="createTeam"
                        from={{ opacity: 0, translateY: 20 }}
                        animate={{ opacity: 1, translateY: 0 }}
                        exit={{ opacity: 0, translateY: -20 }}
                        transition={{ type: 'timing', duration: 300 }}
                        style={styles.innerContainer}
                    >


                        <View style={styles.formInner}>
                            <Typo size={17} color="white">Team Name</Typo>
                            <Input
                                value={createATeam.teamName}
                                onChangeText={(text) => setCreateATeam({ ...createATeam, teamName: text })}
                                containerStyle={{ borderRadius: 40 }}
                                inputStyle={{ color: 'white' }}
                                placeholder="e.g WorkSpaces"
                            />

                            <Typo size={17} color="white">Team Logo</Typo>
                            <TouchableOpacity
                                style={styles.uploadButton}
                                onPress={() => handleImagePick()}
                            >
                                <Text style={styles.uploadText}>Upload Logo</Text>
                                <Feather name="upload-cloud" size={20} color="white" />
                            </TouchableOpacity>


                            <View style={{ flexDirection: "row", gap: 10, marginTop: 10, display: "flex", justifyContent: "center" }}>


                                {createATeam.logo && (
                                    <Image
                                        source={{ uri: createATeam.logo }}
                                        style={styles.imagePreview}
                                    />
                                )}
                            </View>
                        </View>

                        <SingleButton
                            disabled={!createATeam.teamName || !createATeam.logo}
                            loading={isLoading}
                            onPress={handleSubmit}
                            title="Create Team"
                        />
                    </MotiView>
                ) : (
                    <MotiView
                        key="joinTeam"
                        from={{ opacity: 0, translateY: 20 }}
                        animate={{ opacity: 1, translateY: 0 }}
                        exit={{ opacity: 0, translateY: -20 }}
                        transition={{ type: 'timing', duration: 300 }}
                        style={styles.innerContainer}

                    >

                        <View style={styles.formInner}>
                            <Typo size={17} color="white">Enter Team Id</Typo>
                            <Input
                                value={teamId}
                                onChangeText={setTeamId}
                                containerStyle={{ borderRadius: 40 }}
                                inputStyle={{ color: 'white' }}
                                placeholder="e.g BixNetwork-4vd0xx"
                            />
                        </View>

                        <SingleButton
                            disabled={!teamId}
                            loading={joinTeamIsLoading}
                            onPress={handleJoinTeamSubmit}
                            title="Join Team"
                        />
                    </MotiView>
                )}
            </AnimatePresence>
        </ScrollView>
    );
};

export default CreateTeams;

const styles = StyleSheet.create({
    uploadButton: {
        flexDirection: "row",
        alignItems: "center",
        backgroundColor: "#222",
        paddingVertical: 17,
        paddingHorizontal: 16,
        borderRadius: 30,
        marginBottom: 5,
        justifyContent: "space-between",
    },
    imagePreview: { width: 100, height: 100, marginTop: 10, borderRadius: 10 },

    uploadText: { color: "#fff", fontSize: 14 },
    container: {
        backgroundColor: '#0E0E0E',
        justifyContent: 'flex-start',
        paddingTop: spacingY._7,
        // paddingHorizontal: spacingX._12,
    },
    innerContainer: {
        paddingHorizontal: spacingX._30,
        marginVertical: 30,
    },
    headerContainer: {
        backgroundColor: '#0E0E0E',
        display: 'flex',
        alignItems: 'center',
        flexDirection: 'row',
        justifyContent: 'space-between',
        paddingTop: spacingY._7,
        marginBottom: spacingY._12,
        paddingHorizontal: spacingX._12,
    },
    centerTitle: {
        textAlign: 'center',
        color: 'white',
        fontSize: 24,
        fontWeight: '500',
    },
    formInner: {
        gap: 15,
        marginBottom: 10,
    },
});
