import {
  Dimensions,
  FlatList,
  ScrollView,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";
import React, { useState } from "react";
import { spacingX, spacingY } from "@/constants/theme";
import CircleButton from "@/src/components/globals/CircleButton";
import {
  useDeleteTeamMutation,
  useGetTeamCardsQuery,
} from "@/store/api/card/mainApis";
import { useRouter } from "expo-router";

import { useLocalSearchParams } from "expo-router";
import useLoading from "@/src/hooks/useLoading";
import WaveSvg from "@/constants/waveSvg";
import { Image } from "react-native";
import { getBasicColor, getGradientColors } from "@/src/constants/createCard";
import Loading from "@/components/Loading";
import ConfirmationModal from "@/src/components/globals/confirmationModal";
import {
  renderToastError,
  renderToastSuccess,
} from "@/src/components/globals/ToastNotification";

const { width } = Dimensions.get("window");

const CARD_HEIGHT = 170;
const EXPANDED_CARD_HEIGHT = 180;

const TeamCards = () => {
  const profileStyles: any = {
    modern: styles.profileSectionModern,
    classic: styles.profileSection,
    sleek: styles.profileSectionSleek,
  };

  const params = useLocalSearchParams<{ teamId: string }>();
  const { teamId } = params;
  const { data, isLoading, isFetching } = useGetTeamCardsQuery(
    { teamId: teamId },
    { skip: !teamId }
  );
  const ProfileCard = ({
    id,
    lastName,
    firstName,
    organization,
    isExpanded,
    position,
    email,
    phone,
    cardDetails,
    photoLink,
    logoLink,
  }: any) => (
    <TouchableOpacity
      onPress={() => {
        router.push(`/home/single/${id}`);
      }}
      style={[styles.cardContainer, isExpanded && styles.expandedCard]}
    >
      <WaveSvg
        cardType={cardDetails?.template?.templateType}
        useGradient={cardDetails?.template?.useGradient}
        gradientColors={getGradientColors(cardDetails?.template?.templateColor)}
        solidColor={getBasicColor(cardDetails?.template?.templateColor)}
      />
      <View
        style={
          profileStyles[cardDetails?.template?.templateType] ||
          styles.profileSection
        }
      >
        <Image source={{ uri: photoLink }} style={styles.profileImage} />
        <View>
          <Text
            style={[
              styles.nameText,
              { color: cardDetails?.template?.textColor },
            ]}
          >
            {firstName} {lastName}
          </Text>
          <Text
            style={[
              styles.detailText,
              { color: cardDetails?.template?.textColor },
            ]}
          >
            {organization} | {position}
          </Text>
        </View>

        <Image source={require("@/assets/card/biz-card-logo.png")} />
      </View>

      <View
        style={
          cardDetails?.template?.templateType === "classic"
            ? styles.detailSection
            : styles.nonClassicDetailSection
        }
      >
        <View>
          <View style={styles.iconRow}>
            <Image
              source={require("@/assets/card/call-icon.png")}
              style={styles.icon}
            />
            <Text
              style={[
                styles.detailBottom,
                { color: cardDetails?.template?.textColor },
              ]}
            >
              {email}
            </Text>
          </View>

          <View style={styles.iconRow}>
            <Image
              source={require("@/assets/card/email-icon.png")}
              style={styles.icon}
            />
            <Text
              style={[
                styles.detailBottom,
                { color: cardDetails?.template?.textColor },
              ]}
            >
              {phone}
            </Text>
          </View>
        </View>

        <View>
          <Image source={{ uri: logoLink }} style={styles.profileImage} />
        </View>
      </View>
    </TouchableOpacity>
  );

  const router = useRouter();
  const loading = useLoading([isLoading, isFetching]);

  const [deleteModalVisible, setDeleteModalVisible] = useState(false);

  const [deleteTeam, { isLoading: deleting }] = useDeleteTeamMutation();
  const handleDeleteTeam = async () => {
    try {
      if (!teamId) return;
      const response = await deleteTeam(teamId).unwrap();
      renderToastSuccess("Team deleted successfully!");
      router.push("/(main)/team");
    } catch (error) {
      console.error("❌ Delete team failed:", error);
      renderToastError("Failed to delete team");
    } finally {
      setDeleteModalVisible(false);
    }
  };

  return (
    <View style={styles.container}>
      <View style={styles.headerContainer}>
        <CircleButton
          onPress={() => {
            router.push("/(main)/team");
          }}
          iconSource={require("@/assets/main/cross-icon.png")}
        />
        <Text style={styles.centerTitle}>Team Cards</Text>

        <View style={{ flexDirection: "row", gap: 2 }}>
          <CircleButton
            wrapperStyle={{
              backgroundColor: "red",
              opacity: 0.8,
              borderColor: "red",
              borderWidth: 1,
            }}
            onPress={() => {
              setDeleteModalVisible(true);
            }}
            iconSource={require("@/assets/main/delete-icon.png")}
          />
        </View>
      </View>

      <View style={styles.teamListHeader}>
        <Text style={styles.name}>Team Cards</Text>
      </View>

      {loading ? (
        <Loading />
      ) : data?.data?.length === 0 || !data?.data ? (
        <Text
          style={{
            color: "#fff",
            fontSize: 12,
            textAlign: "center",
            marginTop: 20,
            fontStyle: "italic",
          }}
        >
          {`No cards yet!`}
        </Text>
      ) : (
        <FlatList
          data={data?.data}
          keyExtractor={(item) => item._id}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.listContent}
          renderItem={({ item, index }) => (
            <ProfileCard
              id={item._id}
              firstName={item.ContactDetails.firstName}
              lastName={item.ContactDetails.lastName}
              photoLink={item.ContactDetails.photo}
              organization={item.ContactDetails.organization}
              position={item.ContactDetails.position}
              email={item.ContactDetails.email}
              phone={item.ContactDetails.phoneNumber}
              isExpanded={index === data?.data?.length - 1}
              cardDetails={item.cardDetails}
              logoLink={item.ContactDetails.logo}
            />
          )}
        />
      )}
      <ConfirmationModal
        visible={deleteModalVisible}
        title="Delete Team"
        message="Are you sure you want to delete this team?"
        confirmText="Delete"
        cancelText="No"
        onConfirm={handleDeleteTeam}
        onCancel={() => setDeleteModalVisible(false)}
        loading={deleting}
      />
    </View>
  );
};

export default TeamCards;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#0E0E0E",
    justifyContent: "flex-start",
    paddingTop: spacingY._7,
  },
  innerContainer: {
    paddingHorizontal: spacingX._30,
    marginVertical: 30,
  },
  headerContainer: {
    backgroundColor: "#0E0E0E",
    display: "flex",
    alignItems: "center",
    flexDirection: "row",
    justifyContent: "space-between",
    paddingTop: spacingY._7,
    marginBottom: spacingY._12,
    paddingHorizontal: spacingX._12,
  },
  centerTitle: {
    textAlign: "center",
    color: "white",
    fontSize: 24,
    fontWeight: "500",
  },
  formInner: {
    gap: spacingY._10,
    marginBottom: 10,
  },

  name: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 16,
  },
  teamListHeader: {
    paddingHorizontal: spacingX._12,
    paddingVertical: spacingY._15,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },

  iconRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  icon: {
    width: 20,
    height: 20,
    marginRight: 8,
  },
  profileSection: {
    position: "absolute",
    padding: 15,
    justifyContent: "space-between",
    width: "100%",
    gap: 10,
    flexDirection: "row",
    alignItems: "center",
  },
  profileSectionModern: {
    position: "absolute",
    paddingTop: 60,
    paddingHorizontal: 15,
    gap: 10,
    flexDirection: "row",
    alignItems: "center",
  },
  profileSectionSleek: {
    position: "absolute",
    paddingTop: 25,
    gap: 10,
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    width: "100%",
  },
  profileImage: {
    width: 50,
    height: 50,
    borderRadius: 30,
  },
  listContent: {
    paddingBottom: 120,
    display: "flex",
    alignItems: "center",
  },

  cardContainer: {
    width: width - 32,
    height: CARD_HEIGHT,
    marginBottom: -100,
    borderRadius: 30,
    borderColor: "white",
    borderWidth: 1,
    overflow: "hidden",
    elevation: 8,
    backgroundColor: "white",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.15,
    shadowRadius: 10,
  },

  expandedCard: {
    height: EXPANDED_CARD_HEIGHT,
    marginBottom: 0,
  },
  cardBackground: {
    width: "100%",
    height: "100%",
    borderRadius: 30,
  },

  nameText: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#fff",
  },
  detailText: {
    fontSize: 12,
    color: "#fff",
    marginTop: 4,
  },
  nonClassicDetailSection: {
    position: "absolute",
    paddingTop: 120,
    paddingHorizontal: 10,
    gap: 10,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    width: "100%",
  },
  contactsistHeader: {
    paddingBottom: spacingY._10,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },

  detailBottom: {
    fontSize: 12,
    marginTop: 4,
  },
  detailSection: {
    position: "absolute",
    paddingTop: 120,
    paddingHorizontal: 10,
    gap: 10,
    flexDirection: "row",
    alignItems: "center",
    alignContent: "center",
    justifyContent: "space-between",
    width: "100%",
  },
});
