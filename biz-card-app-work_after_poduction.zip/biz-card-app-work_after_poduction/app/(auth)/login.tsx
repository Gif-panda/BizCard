import { Pressable, ScrollView, StyleSheet, View } from "react-native";
import React, { useCallback, useEffect, useState } from "react";
import { colors, radius, spacingX, spacingY } from "@/constants/theme";
import Typo from "@/components/Typo";
import Button from "@/components/Button";
import { useRouter } from "expo-router";
import Input from "@/components/Input";
import SocialAuth from "@/src/components/common/auth/SocialAuth";
import { getCopyright } from "@/utils/common";
import { useBizSigninMutation } from "@/store/api/card/authApis";
import AnimatedStar from "@/src/components/globals/animated-components/AnimatedStar";
import { renderToastError, renderToastSuccess } from "@/src/components/globals/ToastNotification";
import { useSelector } from "react-redux";
import { RootState } from "@/store";
import { MotiView, MotiText } from "moti";

const Login = () => {
  const router = useRouter();
  const jwt = useSelector((state: RootState) => state.card.jwt);

  const [form, setForm] = useState({
    email: "",
    password: "",
  });

  const [bizSignin, { isLoading: loading }] = useBizSigninMutation();

  useEffect(() => {
    if (jwt) {
      router.replace("/(main)/home");
    }
  }, [jwt]);

  const handleChange = useCallback((field: keyof typeof form, value: string) => {
    setForm((prev) => ({ ...prev, [field]: value }));
  }, []);

  const handleSubmit = useCallback(async () => {
    try {
      const res = await bizSignin(form).unwrap();
      renderToastSuccess(res?.message || "Signin Successfully");
      router.push("/(main)/home");
    } catch (error: any) {
      renderToastError(error?.data?.message || error?.data?.error || "Error in signin");
    }
  }, [form, bizSignin, router]);

  const handleMoveToRegister = useCallback(() => {
    router.push("/(auth)/register");
    renderToastSuccess("Fill out the fields to register your account");
  }, [router]);

  const handleMoveToForgotPassword = useCallback(() => {
    router.push("/(auth)/forgotPassword");
    renderToastSuccess("Forgot your account password");
  }, [router]);

  return (
    <ScrollView contentContainerStyle={[styles.container, { flexGrow: 1 }]}>
      <AnimatedStar />

      <MotiView
        from={{ opacity: 0, translateY: 30 }}
        animate={{ opacity: 1, translateY: 0 }}
        transition={{ type: 'timing', duration: 500 }}
        style={styles.form}
      >
        <MotiText
          from={{ opacity: 0, translateY: -20 }}
          animate={{ opacity: 1, translateY: 0 }}
          transition={{ type: 'timing', duration: 500 }}
          style={styles.heading}
        >
          Log in
        </MotiText>

        <View style={styles.formInner}>
          <Typo size={14} color="black">Email Address</Typo>
          <Input
            onChangeText={(val) => handleChange("email", val)}
            placeholder="john@gmail.com"
            value={form.email}
          />
        </View>

        <View style={styles.formInner}>
          <Typo size={14} color="black">Password</Typo>
          <Input
            onChangeText={(val) => handleChange("password", val)}
            value={form.password}
            placeholder="**********"
            secureTextEntry
          />
        </View>

        <View style={{ alignItems: 'flex-end', marginTop: 10 }}>
          <Pressable onPress={handleMoveToForgotPassword}>
            <Typo fontWeight="500" size={14} color={colors.rose}>
              Forgot Password
            </Typo>
          </Pressable>
        </View>


        <Button
          loading={loading}
          disabled={!form.email || !form.password}
          onPress={handleSubmit}
          style={styles.button}
        >
          <Typo fontWeight="700" size={21} color={colors.white}>
            Log in
          </Typo>
        </Button>

        <SocialAuth label="Log in" />
      </MotiView>

      <View style={styles.footer}>
        <Typo size={15} color={colors.black}>Don't have an account?</Typo>
        <Pressable onPress={handleMoveToRegister}>
          <Typo size={15} fontWeight="700" color={colors.black}>Sign up</Typo>
        </Pressable>
      </View>

      <Typo size={12} color="#999" style={styles.copyright}>{getCopyright()}</Typo>
    </ScrollView>
  );
};

export default Login;

const styles = StyleSheet.create({
  container: {
    backgroundColor: "white",
    flex: 1,
    paddingHorizontal: spacingX._20,
    justifyContent: "space-between",
    paddingVertical: spacingY._20,
  },
  heading: {
    fontSize: 30,
    fontWeight: "900",
    color: "black",
    marginBottom: spacingY._10,
  },
  form: {
    gap: spacingY._12,
    marginTop: spacingY._20,
  },
  formInner: {
    gap: spacingY._5,
  },
  button: {
    backgroundColor: "black",
    borderRadius: radius._10,
    marginTop: spacingY._10,
  },
  footer: {
    flexDirection: "row",
    justifyContent: "center",
    alignItems: "center",
    gap: 5,
    marginTop: spacingY._20,
  },
  copyright: {
    textAlign: "center",
    marginTop: spacingY._10,
    marginBottom: spacingY._5,
  },
});
