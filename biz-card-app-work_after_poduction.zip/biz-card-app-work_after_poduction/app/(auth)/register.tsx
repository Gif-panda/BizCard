import { Pressable, StyleSheet, View, ScrollView } from 'react-native';
import React, { useCallback, useState } from 'react';
import { colors, radius, spacingX, spacingY } from '@/constants/theme';
import Typo from '@/components/Typo';
import Input from '@/components/Input';
import Button from '@/components/Button';
import { useRouter } from 'expo-router';
import SocialAuth from '@/src/components/common/auth/SocialAuth';
import { getCopyright } from '@/utils/common';
import { useBizSignupMutation } from '@/store/api/card/authApis';
import AnimatedStar from '@/src/components/globals/animated-components/AnimatedStar';
import { OtpInput } from 'react-native-otp-entry';
import { useVerifyOtpMutation } from '@/store/api/card/mainApis';
import { renderToastError, renderToastSuccess } from '@/src/components/globals/ToastNotification';
import { MotiView, MotiText } from 'moti';

const Register = () => {
    const router = useRouter();

    const [bizSignup, { isLoading }] = useBizSignupMutation();
    const [verifyOtp, { isLoading: otpVerifyLoading }] = useVerifyOtpMutation();

    const [step, setStep] = useState(1);
    const [otp, setOtp] = useState('');
    const [form, setForm] = useState({
        name: '',
        email: '',
        password: '',
        confirmPassword: '',
        phoneNumber: '',
    });

    const handleChange = useCallback((field: keyof typeof form, value: string) => {
        setForm((prev) => ({ ...prev, [field]: value }));
    }, []);

    const handleSubmit = useCallback(async () => {
        try {
            const res = await bizSignup(form).unwrap();
            renderToastSuccess(res?.message || 'Registered Successfully');
            setStep(2);
        } catch (error: any) {
            renderToastError(error?.data?.message || 'Error in registration');
        }
    }, [form, bizSignup]);

    const handleOtpSubmit = useCallback(async (otpCode: string) => {
        try {
            const res = await verifyOtp({ otp: otpCode }).unwrap();
            renderToastSuccess(res?.message || 'Otp Verified Successfully');
            router.push('/(main)/home');
            setOtp('');
        } catch (error: any) {
            renderToastError(error?.data?.message || 'Error verifying OTP');
        }
    }, [verifyOtp, router]);

    const handleMoveToLogin = useCallback(() => {
        router.push('/login');
        renderToastSuccess('Enter credentials to login your account');
    }, [router]);

    return (
        <ScrollView contentContainerStyle={[styles.container, { flexGrow: 1 }]}>
            <AnimatedStar />

            {step === 1 && (
                <MotiView
                    key="signup-form"
                    from={{ opacity: 0, translateY: 30 }}
                    animate={{ opacity: 1, translateY: 0 }}
                    transition={{ type: 'timing', duration: 500 }}
                    style={styles.form}
                >
                    <MotiText
                        from={{ opacity: 0, translateY: -20 }}
                        animate={{ opacity: 1, translateY: 0 }}
                        transition={{ type: 'timing', duration: 500 }}
                        style={styles.heading}
                    >
                        Sign up
                    </MotiText>

                    <View style={styles.formInner}>
                        <Typo size={14} color="black">Full Name</Typo>
                        <Input placeholder="Enter your name" value={form.name} onChangeText={(val) => handleChange('name', val)} />
                    </View>

                    <View style={styles.formInner}>
                        <Typo size={14} color="black">Email</Typo>
                        <Input placeholder="example@gmail.com" value={form.email} onChangeText={(val) => handleChange('email', val)} />
                    </View>

                    <View style={styles.formInner}>
                        <Typo size={14} color="black">Password</Typo>
                        <Input placeholder="must be 8 characters" secureTextEntry value={form.password} onChangeText={(val) => handleChange('password', val)} />
                    </View>

                    <View style={styles.formInner}>
                        <Typo size={14} color="black">Confirm Password</Typo>
                        <Input placeholder="must be 8 characters" secureTextEntry value={form.confirmPassword} onChangeText={(val) => handleChange('confirmPassword', val)} />
                    </View>

                    <View style={styles.formInner}>
                        <Typo size={14} color="black">Phone No</Typo>
                        <Input placeholder="+44xxxxxxxxxxx" value={form.phoneNumber} onChangeText={(val) => handleChange('phoneNumber', val)} />
                    </View>

                    <Button
                        loading={isLoading}
                        disabled={!form.email || !form.name || !form.password || !form.phoneNumber}
                        onPress={handleSubmit}
                        style={styles.button}
                    >
                        <Typo fontWeight="700" size={21} color={colors.white}>Sign Up</Typo>
                    </Button>
                    <SocialAuth label="Register with" />

                </MotiView>
            )}

            {step === 2 && (
                <MotiView
                    key="otp-form"
                    from={{ opacity: 0, translateY: 30 }}
                    animate={{ opacity: 1, translateY: 0 }}
                    transition={{ type: 'timing', duration: 500 }}
                    style={styles.otpForm}
                >
                    <MotiText
                        from={{ opacity: 0, translateY: -20 }}
                        animate={{ opacity: 1, translateY: 0 }}
                        transition={{ type: 'timing', duration: 500 }}
                        style={styles.heading}
                    >
                        Verify OTP
                    </MotiText>

                    <View style={styles.otpFormInner}>
                        <Typo size={14} color="black">Enter the OTP sent to your phone</Typo>
                        <OtpInput
                            numberOfDigits={6}
                            onTextChange={setOtp}
                            onFilled={handleOtpSubmit}
                            theme={{
                                pinCodeContainerStyle: {
                                    borderWidth: 2,
                                    marginHorizontal: 2,
                                    width: 40,
                                    height: 50,
                                    borderRadius: 15,
                                },
                                focusedPinCodeContainerStyle: {
                                    borderColor: '#00FF99',
                                },
                                pinCodeTextStyle: {
                                    fontSize: 18,
                                },
                            }}
                        />
                    </View>

                    <Button
                        loading={otpVerifyLoading}
                        disabled={!otp || otp.length !== 6}
                        onPress={() => handleOtpSubmit(otp)}
                        style={styles.button}
                    >
                        <Typo fontWeight="700" size={21} color={colors.white}>Verify OTP</Typo>
                    </Button>
                </MotiView>
            )}


            <View style={styles.footer}>
                <Typo size={15} color={colors.black}>Already have an account?</Typo>
                <Pressable onPress={handleMoveToLogin}>
                    <Typo size={15} fontWeight="700" color={colors.black}> Log in</Typo>
                </Pressable>
            </View>

            <Typo size={12} color="#999" style={styles.copyright}>{getCopyright()}</Typo>
        </ScrollView>
    );
};

export default Register;

const styles = StyleSheet.create({
    container: {
        backgroundColor: 'white',
        paddingHorizontal: spacingX._20,
        justifyContent: 'space-between',
        paddingVertical: spacingY._20,
    },
    heading: {
        fontSize: 30,
        fontWeight: '900',
        color: 'black',
        marginBottom: spacingY._10,
    },
    form: {
        // gap: spacingY._10,
        marginVertical: spacingY._10,
    },
    formInner: {
        gap: spacingY._5,
    },
    otpForm: {
        gap: spacingY._20,
        marginVertical: spacingY._10,
    },
    otpFormInner: {
        gap: spacingY._10,
    },
    footer: {
        flexDirection: 'row',
        justifyContent: 'center',
        alignItems: 'center',
        gap: 5,
        marginTop: spacingY._20,
    },
    copyright: {
        textAlign: 'center',
        marginTop: spacingY._10,
        marginBottom: spacingY._5,
    },
    button: {
        backgroundColor: 'black',
        borderRadius: radius._10,
        marginTop: spacingY._10,
    },
});
