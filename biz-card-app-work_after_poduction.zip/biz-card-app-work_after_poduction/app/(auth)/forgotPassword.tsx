import { Pressable, ScrollView, StyleSheet, View } from "react-native";
import React, { useCallback, useEffect, useState } from "react";
import { colors, radius, spacingX, spacingY } from "@/constants/theme";
import Typo from "@/components/Typo";
import Button from "@/components/Button";
import { useRouter } from "expo-router";
import Input from "@/components/Input";
import { useBizForgotPasswordMutation, useBizResetPasswordMutation } from "@/store/api/card/authApis";
import AnimatedStar from "@/src/components/globals/animated-components/AnimatedStar";
import { renderToastError, renderToastSuccess } from "@/src/components/globals/ToastNotification";
import { useSelector } from "react-redux";
import { RootState } from "@/store";
import { OtpInput } from "react-native-otp-entry";
import { MotiView, MotiText } from "moti";

const ForgotPassword = () => {
    const router = useRouter();
    const jwt = useSelector((state: RootState) => state.card.jwt);

    useEffect(() => {
        if (jwt) {
            router.replace("/(main)/home");
        }
    }, [jwt]);

    const [forgotPassword, { isLoading: loading }] = useBizForgotPasswordMutation();
    const [resetPassword, { isLoading: resetLoading }] = useBizResetPasswordMutation();
    const [step, setStep] = useState(1);

    const [forgotForm, setForgotForm] = useState({ email: "" });
    const [resetForm, setResetForm] = useState({ otp: "", newPassword: "", confirmPassword: "" });

    const handleChange = useCallback((field: keyof typeof forgotForm, value: string) => {
        setForgotForm((prev) => ({ ...prev, [field]: value }));
    }, []);

    const handleResetFormChange = useCallback((field: keyof typeof resetForm, value: string) => {
        setResetForm((prev) => ({ ...prev, [field]: value }));
    }, []);

    const handleSubmitForgotPassword = useCallback(async () => {
        try {
            const res = await forgotPassword(forgotForm).unwrap();
            renderToastSuccess(res?.message || "OTP sent successfully");
            setStep(2);
        } catch (error: any) {
            renderToastError(error?.data?.message || "Error sending OTP");
        }
    }, [forgotForm, forgotPassword]);

    const handleSubmitResetPassword = useCallback(async () => {
        try {
            const res = await resetPassword({ ...resetForm, ...forgotForm }).unwrap();
            renderToastSuccess(res?.message || "Password reset");
            router.push('/login');
        } catch (error: any) {
            renderToastError(error?.data?.message || "Error resetting password");
        }
    }, [resetForm, forgotForm, resetPassword]);

    const handlemoveToRegister = useCallback(() => {
        router.push("/(auth)/register");
        renderToastSuccess("Fill out the fields to register your account");
    }, []);

    const handleMoveToLogin = useCallback(() => {
        router.push('/login');
        renderToastSuccess("Enter credentials to login");
    }, []);

    return (
        <ScrollView contentContainerStyle={[styles.container, { flexGrow: 1 }]}>
            <AnimatedStar />
            <View style={styles.form}>
                <MotiText
                    from={{ opacity: 0, translateY: -20 }}
                    animate={{ opacity: 1, translateY: 0 }}
                    transition={{ type: 'timing', duration: 500 }}
                    style={styles.heading}
                >
                    Forgot password
                </MotiText>

                <MotiView
                    key={`form-step-${step}`}
                    from={{ opacity: 0, translateY: 30 }}
                    animate={{ opacity: 1, translateY: 0 }}
                    transition={{ type: 'timing', duration: 400 }}
                    style={styles.formInner}
                >
                    {step === 1 && (
                        <>
                            <Typo size={14} color="black">Email Address</Typo>
                            <Input
                                onChangeText={(val) => handleChange("email", val)}
                                placeholder="john@gmail.com"
                                value={forgotForm.email}
                            />
                            <Button
                                loading={loading}
                                disabled={!forgotForm.email}
                                onPress={handleSubmitForgotPassword}
                                style={styles.button}
                            >
                                <Typo fontWeight="700" size={21} color={colors.white}>Submit</Typo>
                            </Button>
                        </>
                    )}

                    {step === 2 && (
                        <>
                            <View style={styles.otpFormInner}>
                                <Typo size={14} color="black">Enter the OTP sent to your phone</Typo>
                                <OtpInput
                                    numberOfDigits={6}
                                    onTextChange={(val) => handleResetFormChange("otp", val)}
                                    theme={{
                                        pinCodeContainerStyle: {
                                            borderWidth: 2,
                                            marginHorizontal: 2,
                                            width: 40,
                                            height: 50,
                                            borderRadius: 15,
                                        },
                                        focusedPinCodeContainerStyle: {
                                            borderColor: '#00FF99',
                                        },
                                        pinCodeTextStyle: {
                                            fontSize: 18,
                                        },
                                    }}
                                />
                            </View>

                            <Typo size={14} color="black">New Password</Typo>
                            <Input
                                onChangeText={(val) => handleResetFormChange("newPassword", val)}
                                value={resetForm.newPassword}
                                placeholder="**********"
                                secureTextEntry
                            />

                            <Typo size={14} color="black">Confirm Password</Typo>
                            <Input
                                onChangeText={(val) => handleResetFormChange("confirmPassword", val)}
                                value={resetForm.confirmPassword}
                                placeholder="**********"
                                secureTextEntry
                            />

                            <Button
                                loading={resetLoading}
                                disabled={!forgotForm.email || !resetForm.otp || !resetForm.newPassword || !resetForm.confirmPassword}
                                onPress={handleSubmitResetPassword}
                                style={styles.button}
                            >
                                <Typo fontWeight="700" size={21} color={colors.white}>Reset Password</Typo>
                            </Button>
                        </>
                    )}
                </MotiView>
            </View>

            <View>
                <View style={styles.footer}>
                    <Typo size={15} color={colors.black}>Don't have an account?</Typo>
                    <Pressable onPress={handlemoveToRegister}>
                        <Typo size={15} fontWeight="700" color={colors.black}>Sign up</Typo>
                    </Pressable>
                </View>
                <View style={styles.footer}>
                    <Typo size={15} color={colors.black}>Already have an account?</Typo>
                    <Pressable onPress={handleMoveToLogin}>
                        <Typo size={15} fontWeight="700" color={colors.black}>Log in</Typo>
                    </Pressable>
                </View>
            </View>
        </ScrollView>
    );
};

export default ForgotPassword;

const styles = StyleSheet.create({
    container: {
        backgroundColor: "white",
        flex: 1,
        paddingHorizontal: spacingX._20,
        justifyContent: "space-between",
        paddingVertical: spacingY._20,
    },
    form: {
        gap: spacingY._20,
        marginTop: spacingY._20,
    },
    heading: {
        fontSize: 25,
        fontWeight: '900',
        color: 'black',
        marginBottom: spacingY._10,
    },
    formInner: {
        gap: spacingY._10,
    },
    otpFormInner: {
        gap: spacingY._10,
        marginBottom: spacingY._10,
    },
    footer: {
        flexDirection: "row",
        justifyContent: "center",
        alignItems: "center",
        gap: 5,
        marginTop: spacingY._20,
    },
    button: {
        backgroundColor: "black",
        borderRadius: radius._10,
    },
});
