import { StyleSheet, View } from "react-native";
import React from "react";
import { colors, spacingY } from "@/constants/theme";
import WelcomeScreen from "@/src/components/welcome/WelcomeScreen";

const Welcome = () => {
  return (
    <View style={styles.container}>
      <WelcomeScreen />
    </View>
  );
};

export default Welcome;

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.neutral900,
    flex: 1,
    justifyContent: "space-between",
    paddingTop: spacingY._7,
  },
});
