import axios from 'axios';

interface LinkedInResult {
  name: string;
  summary: string;
  location: string | null;
  source_link: string;
  platform: string;
}

interface SerpApiOrganicResult {
  position: number;
  title: string;
  link: string;
  snippet: string;
  rich_snippet?: {
    top?: {
      extensions?: string[];
    };
  };
}

const parseLinkedInResults = (items: SerpApiOrganicResult[]): LinkedInResult[] => {
  return items.map((item) => {
    const extensions = item.rich_snippet?.top?.extensions || [];
    const location = extensions[0] || null;

    return {
      name: item.title || '',
      summary: item.snippet || '',
      location,
      source_link: item.link || '',
      platform: 'LinkedIn',
    };
  });
};

export const searchLinkedIn = async (
  query: string,
  serpApiKey: string
): Promise<LinkedInResult[]> => {
  try {
    const linkedInQuery = `site:linkedin.com/in ${query}`;
    const url = new URL('https://serpapi.com/search.json');

    url.searchParams.set('api_key', serpApiKey);
    url.searchParams.set('engine', 'google');
    url.searchParams.set('q', linkedInQuery);
    url.searchParams.set('num', '10');

    const response = await axios.get(url.toString());

    if (!response.data.organic_results || response.data.organic_results.length === 0) {
      return [];
    }

    return parseLinkedInResults(response.data.organic_results);
  } catch (error) {
    console.error('LinkedIn search error:', error);
    throw error;
  }
};
