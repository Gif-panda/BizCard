import { useMemo } from 'react';

const useLoading = (loadings: boolean[] = []): boolean => {
  const isLoading = useMemo(() => {
    if (!Array.isArray(loadings) || loadings.length === 0) {
      return false;
    }
    return loadings.some((loading) => loading);
  }, [loadings]);

  return isLoading;
};

export default useLoading;
