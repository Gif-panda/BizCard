export const welcomeSteps = [
  {
    title: "Welcome to BizCard",
    description: "The smarter way to manage and share business cards"
  },
  {
    title: "Scan, Save, and Share",
    description: "Digitize business cards instantly with AI-powered scanning"
  },
  {
    title: "Stay Organized",
    description: "Sort contacts by industry, export data, and collaborate with your team."
  }
];
