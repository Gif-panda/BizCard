const config = {
  baseURL: process.env.EXPO_PUBLIC_Backend,
 
};

export default config;
