export const teamsData = [
  {
    id: 1,
    name: 'BizNetwork',
    members: 834000,
    date: 'Monday',
    avatars: [
      'https://randomuser.me/api/portraits/men/32.jpg',
      'https://randomuser.me/api/portraits/women/44.jpg',
      'https://randomuser.me/api/portraits/men/12.jpg',
      'https://randomuser.me/api/portraits/women/68.jpg',
    ],
  },

  {
    id: 2,
    name: 'WorkSpaces',
    members: 830,
    date: 'Tuesday',
    avatars: [
      'https://randomuser.me/api/portraits/men/32.jpg',
      'https://randomuser.me/api/portraits/women/44.jpg',
      'https://randomuser.me/api/portraits/men/12.jpg',
      'https://randomuser.me/api/portraits/women/68.jpg',
    ],
  },

  {
    id: 3,
    name: 'cardShare Hub',
    members: 8340,
    date: 'Sunday',
    avatars: [
      'https://randomuser.me/api/portraits/men/32.jpg',
      'https://randomuser.me/api/portraits/women/44.jpg',
      'https://randomuser.me/api/portraits/men/12.jpg',
      'https://randomuser.me/api/portraits/women/68.jpg',
    ],
  },

  {
    id: 4,
    name: 'Family Members',
    members: 212,
    date: '10-april-2025',
    avatars: [
      'https://randomuser.me/api/portraits/men/32.jpg',
      'https://randomuser.me/api/portraits/women/44.jpg',
      'https://randomuser.me/api/portraits/men/12.jpg',
      'https://randomuser.me/api/portraits/women/68.jpg',
    ],
  },
  
];



export const teamsMembers = [
  'https://randomuser.me/api/portraits/men/32.jpg',
  'https://randomuser.me/api/portraits/women/44.jpg',
  'https://randomuser.me/api/portraits/men/12.jpg',
  'https://randomuser.me/api/portraits/women/68.jpg',
]