export const cardTemplates = [
  {
    id: "classic",
    name: "Classic",
    image: require("@/assets/main/templates/classic-template.png"),
    premium: false
  },
  {
    id: "flat",
    name: "Flat",
    image: require("@/assets/main/templates/flat-template.png"),
    premium: true
  },
  {
    id: "modern",
    name: "Modern",
    image: require("@/assets/main/templates/modren-template.png"),
    premium: true
  },
  {
    id: "sleek",
    name: "Sleek",
    image: require("@/assets/main/templates/sleek-template.png"),
    premium: true
  },
];

export const BASIC_COLORS = [
  "#FF00FF",
  "#A187D6",
  "#5B6ECC",
  "#709BFF",
  "#2E8B57",
  "#1C1C1C",
  "#A020F0",
];

export const GRADIENT_COLORS = [
  { colors: ["#FF00FF", "#00FFFF"], premium: true },
  { colors: ["#19835B", "#131B21"], premium: false },
  { colors: ["#FF0000", "#9900FF"], premium: true },
  { colors: ["#6A0DAD", "#FFB6C1"], premium: true },
  { colors: ["#8B4513", "#FFC0CB"], premium: true },
  { colors: ["#FF0000", "#FFFFFF"], premium: true },
];

export const COLORS = [
  { label: "Black", value: "#000000" },
  { label: "White", value: "#FFFFFF" },
  { label: "Gray", value: "#808080" },
  { label: "Purple", value: "#800080" },
  { label: "Pink", value: "#FFC0CB" },
  { label: "Orange", value: "#FFA500" },
  { label: "Yellow", value: "#FFFF00" },
  { label: "Red", value: "#FF0000" },
  { label: "Blue", value: "#0000FF" },
  { label: "Green", value: "#00FF00" },
];

export const FONTS = [
  { label: "Website", value: "Website" },
  { label: "System", value: "System" },
  { label: "Arial", value: "Arial" },
];

export const CATEGORIES = [
  { label: "Favorites", value: "favorites" },
  { label: "Family", value: "family" },
  { label: "Emergency Contacts", value: "emergency_contacts" },
  { label: "Business", value: "business" },
  { label: "Office", value: "office" },
  { label: "Company", value: "company" },
];

export const INDUSTRIES = [
  { label: "Technology", value: "Technology" },
  { label: "Finance", value: "Finance" },
  { label: "Healthcare", value: "Healthcare" },
  { label: "Education", value: "Education" },
  { label: "Retail", value: "Retail" },
  { label: "Manufacturing", value: "Manufacturing" },
  { label: "Real Estate", value: "Real Estate" },
  { label: "Hospitality", value: "Hospitality" },
  { label: "Transportation", value: "Transportation" },
  { label: "Energy", value: "Energy" },
  { label: "Telecommunications", value: "Telecommunications" },
  { label: "Government", value: "Government" },
  { label: "Non-Profit", value: "Non-Profit" },
  { label: "Other", value: "Other" },
];

export const getBasicColor = (templateColor: string | undefined): any => {
  if (!templateColor?.startsWith("basic-")) return [];

  const index = parseInt(templateColor.split("-")[1], 10);
  return !isNaN(index) && BASIC_COLORS[index] ? [BASIC_COLORS[index]] : [];
};

export const getGradientColors = (templateColor: string | undefined): any => {
  if (!templateColor?.startsWith("gradient-")) return [];

  const index = parseInt(templateColor.split("-")[1], 10);
  return !isNaN(index) && GRADIENT_COLORS[index]
    ? GRADIENT_COLORS[index].colors
    : [];
};
