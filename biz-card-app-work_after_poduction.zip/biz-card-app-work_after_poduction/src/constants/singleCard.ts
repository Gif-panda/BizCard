const familyWhiteIcon = require('@/assets/main/filter/family-white-icon.png');
const heartWhiteIcon = require('@/assets/main/filter/heart-white-icon.png');


   
   export const optionsListOne = [
        {
            id: 'copy',
            label: 'Copy Card Link',
            icon: require('@/assets/option-list/copy-icon.png'),
            onPress: () => console.log('Copy Link'),
        },
        {
            id: 'text',
            label: 'Share Card via Text',
            icon: require('@/assets/option-list/chat-icon.png'),
            onPress: () => console.log('Share via Text'),
        },
        {
            id: 'email',
            label: 'Share Card via Email',
            icon: require('@/assets/option-list/mail-icon.png'),
            onPress: () => console.log('Share via Email'),
        },
        {
            id: 'offline',
            label: 'Share Card via Offline',
            icon: require('@/assets/option-list/no-wifi-icon.png'),
            onPress: () => console.log('Share Offline'),
        },
    ];

   export  const optionsListThree = [
        {
            id: 'pdf',
            label: 'Download as PDF',
            icon: require('@/assets/option-list/download-icon.png'),
            onPress: () => console.log('Copy Link'),
        },
        {
            id: 'sharepdf',
            label: 'Share as PDF',
            icon: require('@/assets/option-list/share-icon.png'),
            onPress: () => console.log('Share via Text'),
        },
        {
            id: 'csvfile',
            label: 'Download as CSV File',
            icon: require('@/assets/option-list/download-icon.png'),
            onPress: () => console.log('Share via Email'),
        },
        {
            id: 'excel',
            label: 'Download as Excel File',
            icon: require('@/assets/option-list/download-icon.png'),
            onPress: () => console.log('Share Offline'),
        },
    ];

   export const optionsListTwo = [
        {
            id: 'linkedin',
            label: 'Share Card via LinkedIn',
            icon: require('@/assets/option-list/linkedin-icon.png'),
            onPress: () => console.log('Copy Link'),
        },
        {
            id: 'instagram',
            label: 'Share Card via Instagram',
            icon: require('@/assets/option-list/insta-icon.png'),
            onPress: () => console.log('Share via Text'),
        },
        {
            id: 'whatsapp',
            label: 'Share Card via WhatsApp',
            icon: require('@/assets/option-list/whatsapp-icon.png'),
            onPress: () => console.log('Share via Email'),
        },
        {
            id: 'x',
            label: 'Share Card via X',
            icon: require('@/assets/option-list/twitter-icon.png'),
            onPress: () => console.log('Share Offline'),
        },
    ];

    export const singleTabs = [
    { label: 'Family', icon: familyWhiteIcon, isActive: true },
    { label: 'Favorites', icon: heartWhiteIcon, isActive: false },
];
