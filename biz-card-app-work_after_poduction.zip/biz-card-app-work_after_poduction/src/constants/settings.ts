import { router } from "expo-router";

export const defaultCountry = [
  {
    id: "defaultCountry",
    label: "USA",
    icon: require("@/assets/settings/us-flag-icon.png"),
    icon2: require("@/assets/settings/forward-arrow-icon.png"),
  },
];

export const settingAccount = [
  {
    id: "account",
    label: "Manage account",
    icon: require("@/assets/settings/account-icon.png"),
    icon2: require("@/assets/settings/forward-arrow-icon.png"),
    onPress: () => console.log("Copy Link"),
  },
];
export const settingContacts = [
  {
    id: "contacts",
    label: "All Contacts",
    icon: require("@/assets/settings/contacts-icon.png"),
    icon2: require("@/assets/settings/forward-arrow-icon.png"),
    onPress: () => router.push("/(main)/settings/all-contacts"),
  },
  {
    id: "myContacts",
    label: "My Cards",
    icon: require("@/assets/settings/contacts-icon.png"),
    icon2: require("@/assets/settings/forward-arrow-icon.png"),
    onPress: () => router.push("/(main)/settings/my-contacts"),
  },
];

export const settingsGeneral = [
  {
    id: "integration",
    label: "Integrations",
    icon: require("@/assets/settings/thunder-icon.png"),
    icon2: require("@/assets/settings/forward-arrow-icon.png"),
    onPress: () => console.log("Copy Link"),
  },
  {
    id: "contactSupport",
    label: "Contact Support",
    icon: require("@/assets/settings/help-icon.png"),
    icon2: require("@/assets/settings/forward-arrow-icon.png"),
    onPress: () => console.log("Copy Link"),
  },
];

export const settingsSubscription = [
  {
    id: "mySubscription",
    label: "My Subscription",
    icon: require("@/assets/settings/wallet-icon.png"),
    icon2: require("@/assets/settings/forward-arrow-icon.png"),
    onPress: () => router.push("/(main)/settings/subscription"),
  },
  //  {
  //   id: 'restoreSubscription',
  //   label: 'Resort Subscription',
  //   icon: require('@/assets/settings/restore-icon.png'),
  //   icon2: require('@/assets/settings/forward-arrow-icon.png'),
  //   onPress: () => console.log('Copy Link'),
  // },
];

export const settingsHelp = [
  {
    id: "privacyPolicy",
    label: "Terms & Conditions",
    icon: require("@/assets/settings/privacy-icon.png"),
    icon2: require("@/assets/settings/forward-arrow-icon.png"),
    onPress: () => router.push("/(main)/settings/privacy-policy"),
  },
  //  {
  //   id: 'Faqs',
  //   label: 'FAQs',
  //   icon: require('@/assets/settings/privacy-icon.png'),
  //   icon2: require('@/assets/settings/forward-arrow-icon.png'),
  //   onPress: () => router.push('/(main)/settings/faqs'),
  // },
];
