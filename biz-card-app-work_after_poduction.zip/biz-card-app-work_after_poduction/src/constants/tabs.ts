const allWhiteIcon = require('@/assets/main/filter/all-white-icon.png');
const familyWhiteIcon = require('@/assets/main/filter/family-white-icon.png');
const heartWhiteIcon = require('@/assets/main/filter/heart-white-icon.png');
const callWhiteIcon = require('@/assets/main/filter/call-white-icon.png');


export const filterTabs = [
  { label: "All", value: "", icon: allWhiteIcon },
  { label: "Family", value: "family", icon: familyWhiteIcon },
  { label: "Favorites", value: "favorites", icon: heartWhiteIcon },
  { label: "Office", value: "office", icon: callWhiteIcon },
  { label: "Emergency Contacts", value: "emergency_contacts", icon: callWhiteIcon },
];


export const filterOptions = ['By Industry', 'By Category'];


export const industryFilterTabs = [
  { label: "Technology", value: "Technology", icon: allWhiteIcon },
  { label: "Finance", value: "Finance", icon: allWhiteIcon },
  { label: "Healthcare", value: "Healthcare", icon: allWhiteIcon },
  { label: "Education", value: "Education", icon: allWhiteIcon },
  { label: "Retail", value: "Retail", icon: allWhiteIcon },
  { label: "Manufacturing", value: "Manufacturing", icon: allWhiteIcon },
  { label: "Real Estate", value: "Real Estate", icon: allWhiteIcon },
  { label: "Hospitality", value: "Hospitality", icon: allWhiteIcon },
  { label: "Transportation", value: "Transportation", icon: allWhiteIcon },
  { label: "Energy", value: "Energy", icon: allWhiteIcon },
  { label: "Telecommunications", value: "Telecommunications", icon: allWhiteIcon },
  { label: "Government", value: "Government", icon: allWhiteIcon },
  { label: "Non-Profit", value: "Non-Profit", icon: allWhiteIcon },
  { label: "Other", value: "Other", icon: allWhiteIcon },
];



