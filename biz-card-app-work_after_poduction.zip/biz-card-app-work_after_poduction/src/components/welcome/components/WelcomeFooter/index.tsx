import Button from '@/components/Button';
import Typo from '@/components/Typo';
import { colors, spacingX, spacingY } from '@/constants/theme';
import { welcomeSteps } from '@/src/constants/welcomeHeading';
import { verticalScale } from '@/utils/styling';
import React from 'react';
import { View, StyleSheet } from 'react-native';
import Animated, { FadeInDown } from 'react-native-reanimated';
import { WelcomeFooterProps } from '../types';
import { useRouter } from 'expo-router';



const WelcomeFooter: React.FC<WelcomeFooterProps> = ({ step }) => {
    const router = useRouter();
    return (
        <View style={styles.footer}>
            <Animated.View
                entering={FadeInDown.duration(1000).delay(100).springify().damping(12)}
                style={{ alignItems: 'center', gap: 2 }}
            >
                <Typo size={25} color={'#fff'}>
                    {welcomeSteps[step - 1]?.title}
                </Typo>
                <Typo size={14} style={{ paddingHorizontal: 40, textAlign: 'center' }} color={'#fff'}>
                    {welcomeSteps[step - 1]?.description}
                </Typo>

                <View style={styles.stepperContainer}>
                    {[1, 2, 3].map((item) => (
                        <View
                            key={item}
                            style={[
                                styles.bullet,
                                { backgroundColor: step === item ? '#1FFA9E' : '#FFFFFF' }
                            ]}
                        />
                    ))}
                </View>
            </Animated.View>

            <Animated.View
                entering={FadeInDown.duration(1000).delay(200).springify().damping(12)}
                style={styles.buttonContainer}
            >
                <Button onPress={() => {
                    router.push('/(auth)/register')
                }} disabled={step < 3}>
                    <Typo size={22} color={'black'} fontWeight={'600'}>
                        Get Started
                    </Typo>
                </Button>
            </Animated.View>
        </View>
    );
};

const styles = StyleSheet.create({

    footer: {
        backgroundColor: colors.neutral900,
        alignItems: 'center',
        paddingTop: verticalScale(30),
        paddingBottom: verticalScale(45),
        gap: spacingY._20,

    },
    buttonContainer: {
        width: '100%',
        paddingHorizontal: spacingX._25,
    },

    stepperContainer: {
        flexDirection: 'row',
        marginTop: 8,
        gap: 8,
    },

    bullet: {
        width: 8,
        height: 8,
        borderRadius: 5,
    },

});

export default WelcomeFooter;
