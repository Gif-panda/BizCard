import React, { useState } from "react";
import { View, StyleSheet, TouchableOpacity } from "react-native";

import Typo from "@/components/Typo";
import { colors } from "@/constants/theme";
import { useRouter } from "expo-router";
import Welcome_StepTwo from "../../auth/welcome/steps/Welcome_StepTwo";
import Welcome_StepOne from "../../auth/welcome/steps/Welcome_StepOne";
import Welcome_StepThree from "../../auth/welcome/steps/Welcome_StepThree";
import WelcomeFooter from "../../auth/welcome/components/WelcomeFooter";
import { onBoardingComplete } from "@/store/slices/card/cardSlice";
import { useDispatch } from "react-redux";

const WelcomeScreen = () => {
  const router = useRouter();
  const [step, setStep] = useState(1);
  const dispatch = useDispatch();

  const handleNext = () => setStep((prev) => prev + 1);
  const handleSkip = () => {
    dispatch(onBoardingComplete());
    router.push("/(auth)/register");
  };

  return (
    <View style={styles.container}>
      {step < 3 && (
        <TouchableOpacity
          style={styles.skipButton}
          onPress={() => {
            handleSkip();
          }}
        >
          <Typo color={colors.white}>Skip</Typo>
        </TouchableOpacity>
      )}

      {step === 1 && <Welcome_StepOne handleNext={handleNext} />}
      {step === 2 && <Welcome_StepTwo handleNext={handleNext} />}
      {step === 3 && <Welcome_StepThree />}

      <WelcomeFooter step={step} handleNext={handleNext} />
    </View>
  );
};

export default WelcomeScreen;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#000",
  },

  skipButton: {
    position: "absolute",
    top: 50,
    right: 20,
    zIndex: 1,
    padding: 10,
  },
});
