import { Image, StyleSheet, View } from 'react-native';
import React, { useEffect } from 'react';
import { colors, spacingY } from '@/constants/theme';
import Animated, {
    useSharedValue,
    useAnimatedStyle,
    withRepeat,
    withTiming,
    runOnJS,
} from 'react-native-reanimated';

const Welcome_StepTwo = ({ handleNext }: { handleNext: () => void }) => {
    const scanX = useSharedValue(0);

    useEffect(() => {
        const start = 0;
        const end = -250 + 130; // card width - scanner width

        scanX.value = withRepeat(
            withTiming(end, { duration: 2000 }),
            3,
            true,
            () => {
                'worklet';
                runOnJS(handleNext)();
            }
        );
    }, []);


    const scanStyle = useAnimatedStyle(() => ({
        transform: [{ translateX: scanX.value }],
    }));

    return (
        <View style={styles.container}>
            <View style={styles.cardWrapper}>
                <Image
                    source={require('../../../../../assets/welcome/circle-background.png')}
                    style={styles.circleBackground}
                    resizeMode="contain"
                />
                <Image
                    source={require('../../../../../assets/welcome/first-card.png')}
                    style={styles.card}
                    resizeMode="contain"
                />

                <Animated.Image
                    source={require('../../../../../assets/welcome/scan-bar.png')}
                    style={[styles.scannerImage, scanStyle]}
                    resizeMode="stretch"
                />
            </View>
        </View>
    );
};

export default Welcome_StepTwo;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: colors.neutral900,
        justifyContent: 'space-between',
        paddingTop: spacingY._7,
    },
    cardWrapper: {
        alignItems: 'center',
        justifyContent: 'center',
        flex: 1,
    },
    card: {
        width: 250,
        height: 250,
    },
    scannerImage: {
        position: 'absolute',
        width: 150, // Match your original scanner bar width or adjust to fit your image
        height: 650, // Match your original scanner bar height or adjust as needed
    },

    circleBackground: {
        width: 320,
        height: 320,
        position: 'absolute',
        alignSelf: 'center',
    },
});
