import React, { useEffect, ReactNode } from 'react';
import Animated, { useSharedValue, useAnimatedStyle, withTiming } from 'react-native-reanimated';
import { ViewStyle, StyleProp } from 'react-native';

interface SlideInViewProps {
  children: ReactNode;
  duration?: number;
  offset?: number;
  style?: StyleProp<ViewStyle>;
}

export const SlideInView: React.FC<SlideInViewProps> = ({ children, duration = 500, offset = 50, style }) => {
  const translateY = useSharedValue(offset);

  useEffect(() => {
    translateY.value = withTiming(0, { duration });
  }, []);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ translateY: translateY.value }],
  }));

  return <Animated.View style={[animatedStyle, style]}>{children}</Animated.View>;
};
