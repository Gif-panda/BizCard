// components/animations/index.ts
export { FadeInView } from './FadeInView';
export { SlideInView } from './SlideInView';
export { ScaleInView } from './ScaleInView';
