import React, { useEffect, ReactNode } from 'react';
import Animated, { useSharedValue, useAnimatedStyle, withTiming } from 'react-native-reanimated';
import { ViewStyle, StyleProp } from 'react-native';

interface ScaleInViewProps {
  children: ReactNode;
  duration?: number;
  style?: StyleProp<ViewStyle>;
}

export const ScaleInView: React.FC<ScaleInViewProps> = ({ children, duration = 1000, style }) => {
  const scale = useSharedValue(0);

  useEffect(() => {
    scale.value = withTiming(1, { duration });
  }, []);

  const animatedStyle = useAnimatedStyle(() => ({
    transform: [{ scale: scale.value }],
  }));

  return <Animated.View style={[animatedStyle, style]}>{children}</Animated.View>;
};
