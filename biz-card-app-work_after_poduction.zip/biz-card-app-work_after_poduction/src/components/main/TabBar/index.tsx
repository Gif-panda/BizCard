import { colors, spacingX, spacingY } from "@/constants/theme";
import { useRouter, usePathname } from "expo-router";
import React, { useEffect, useState } from "react";
import { View, TouchableOpacity, Image, Text, StyleSheet, Keyboard } from "react-native";

const TabBar = () => {
  const router = useRouter();
  const pathname = usePathname();
  const [isKeyboardVisible, setIsKeyboardVisible] = useState(false);

  useEffect(() => {
    const keyboardDidShowListener = Keyboard.addListener(
      'keyboardDidShow',
      () => setIsKeyboardVisible(true)
    );
    const keyboardDidHideListener = Keyboard.addListener(
      'keyboardDidHide',
      () => setIsKeyboardVisible(false)
    );

    return () => {
      keyboardDidShowListener.remove();
      keyboardDidHideListener.remove();
    };
  }, []);

  const getTintColor = (path: string) => {
    return pathname === path ? "#00FFAA" : "white";
  };

  const hiddenRoutes = ["/scan", "/(main)/scan", "/share", "/(main)/share"];

  // Hide tab bar if keyboard is visible or if on hidden routes
  if (isKeyboardVisible || hiddenRoutes.some((route) => pathname.toLowerCase().includes(route)))
    return null;

  return (
    <View style={styles.container}>
      <View style={styles.tabContainer}>
        <TouchableOpacity
          style={styles.tabItem}
          onPress={() => router.push("/(main)/home")}
        >
          <Image
            source={require("../../../../assets/tab/home.png")}
            style={[styles.icon, { tintColor: getTintColor("/home") }]}
          />
          <Text style={[styles.label, { color: getTintColor("/home") }]}>
            Home
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.tabItem}
          onPress={() => router.push("/(main)/team")}
        >
          <Image
            source={require("../../../../assets/tab/team.png")}
            style={[styles.icon, { tintColor: getTintColor("/team") }]}
          />
          <Text style={[styles.label, { color: getTintColor("/team") }]}>
            Team
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.centerButton}
          onPress={() => router.push("/(main)/scan")}
        >
          <View style={styles.glowEffect} />
          <Image
            source={require("../../../../assets/tab/menu-scan.png")}
            style={styles.centerIcon}
          />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.tabItem}
          onPress={() => router.push("/(main)/cards")}
        >
          <Image
            source={require("../../../../assets/tab/cards.png")}
            style={[styles.icon, { tintColor: getTintColor("/cards") }]}
          />
          <Text style={[styles.label, { color: getTintColor("/cards") }]}>
            Cards
          </Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.tabItem}
        onPress={() => router.push("/(main)/share")}
        >
          <Image
            source={require("../../../../assets/tab/share.png")}
            style={[styles.icon, { tintColor: getTintColor("/share") }]}
          />
          <Text style={[styles.label, { color: getTintColor("/share") }]}>
            Share
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: "#0E0E0E",
  },
  tabContainer: {
    flexDirection: "row",
    justifyContent: "space-around",
    alignItems: "center",
    backgroundColor: "#0E0E0E",
    borderRadius: 40,
    borderColor: "#65736C",
    borderWidth: 0.5,
    padding: 15,
    marginHorizontal: spacingX._12,
    marginVertical: spacingY._12,
  },
  tabItem: {
    alignItems: "center",
  },
  icon: {
    width: 24,
    height: 24,
    resizeMode: "contain",
  },
  label: {
    fontSize: 12,
    marginTop: 4,
  },
  centerButton: {
    width: 70,
    height: 70,
    alignItems: "center",
    justifyContent: "center",
    marginTop: -50,
  },
  glowEffect: {
    position: "absolute",
    width: 78,
    height: 70,
    borderRadius: 35,
  },
  centerIcon: {
    width: 150,
    height: 150,
    resizeMode: "contain",
  },
});

export default TabBar;
