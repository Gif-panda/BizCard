import { teamsMembers } from "@/src/constants/mockData";
import React, { useState } from "react";
import { View, Text, Image, StyleSheet, TouchableOpacity } from "react-native";
import { useRouter } from "expo-router";
import UserDropdown from "../UserDropdown";
import { useGetAllUsersQuery } from "@/store/api/card/mainApis";

const TeamCard = ({ team, refetch }: any) => {
  const router = useRouter();
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);

  const handleOpenDetails = (teamId: string) => {
    router.push(`/team/team-cards/${teamId}`);
  };

  const {
    data,
    isLoading: getAllUsersLoading,
    isFetching: getAllUsersFetching,
  } = useGetAllUsersQuery({});

  return (
    <View style={styles.card}>
      <TouchableOpacity
        style={styles.leftSection}
        onPress={() => handleOpenDetails(team?._id)}
      >
        {team?.logo ? (
          <View style={styles.avatarGroup}>
            <Image
              source={{ uri: team?.logo }}
              style={styles.logoImage}
              resizeMode="cover"
            />
          </View>
        ) : (
          <View style={styles.avatarGroup}>
            {teamsMembers.map((avatar: any, index: number) => (
              <Image
                key={index}
                source={{ uri: avatar }}
                style={styles.avatar}
                resizeMode="cover"
              />
            ))}
          </View>
        )}

        <View style={styles.info}>
          <Text style={styles.name}>{team.teamName}</Text>
          <Text style={styles.members}>
            {team.totalMembers >= 1000
              ? `${(team.totalMembers / 1000).toFixed(1)}k`
              : team.totalMembers || 0}{" "}
            Members
          </Text>
        </View>
      </TouchableOpacity>

      <View style={styles.rightSection}>
        <Text style={styles.date}>{team.createdAt}</Text>
        <View style={{ flexDirection: "row", alignItems: "center"}}>
          <UserDropdown
            teamData={team}
            users={data?.users || []}
            selectedUserId={selectedUserId}
            setSelectedUserId={setSelectedUserId}
          />
        </View>
      </View>
    </View>
  );
};

export default TeamCard;

const styles = StyleSheet.create({
  card: {
    backgroundColor: "#1C1C1E",
    borderRadius: 12,
    borderColor: "#383637",
    borderWidth: 1,
    padding: 16,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    marginBottom: 12,
  },
  leftSection: {
    flexDirection: "row",
    alignItems: "center",
  },
  avatarGroup: {
    flexDirection: "row",
    flexWrap: "wrap",
    gap: 4,
    width: 80,
    marginRight: 12,
  },
  logoImage: {
    width: 70,
    height: 70,
    borderColor: "#383637",
    borderWidth: 2,
    borderRadius: 6,
    backgroundColor: "#333",
  },
  avatar: {
    width: 34,
    height: 34,
    borderColor: "#383637",
    borderWidth: 2,
    borderRadius: 6,
    backgroundColor: "#333",
  },
  info: {
    justifyContent: "center",
  },
  name: {
    textTransform: "capitalize",
    color: "#fff",
    fontSize: 16,
    fontWeight: "bold",
  },
  members: {
    color: "#A0A0A0",
    fontSize: 12,
    marginTop: 4,
  },
  rightSection: {
    alignItems: "flex-end",
    justifyContent: "space-between",
    height: 70,
  },
  date: {
    color: "#A0A0A0",
    fontSize: 12,
  },
  deleteIcon: {
    opacity: 0.8,padding: 4,
    marginBottom: 2,
    borderRadius: 20,
    justifyContent: "center",
    alignItems: "center",
  },
});
