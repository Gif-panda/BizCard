import { colors, radius, spacingX, spacingY } from '@/constants/theme';
import { verticalScale } from '@/utils/styling';
import React, { useState } from 'react';
import {
    View,
    Text,
    TouchableOpacity,
    Modal,
    FlatList,
    StyleSheet,
} from 'react-native';
import { RadioButton } from 'react-native-paper';
import AntDesign from '@expo/vector-icons/AntDesign';
import SingleButton from '@/src/components/globals/single-card/SingleButton';
import { useAddUserToTeamMutation } from '@/store/api/card/mainApis';
import { renderAlertError, renderAlertSuccess } from '@/src/components/globals/ToastNotification';
import { FontAwesome } from '@expo/vector-icons';

const UserDropdown = ({ users, selectedUserId, setSelectedUserId, teamData }: any) => {
    const [dropdownVisible, setDropdownVisible] = useState(false);
    const [addUserToTeam, { isLoading: joinTeamIsLoading }] = useAddUserToTeamMutation();

    const handleAddUserToTeam = async () => {
        try {
            const res = await addUserToTeam({
                teamId: teamData?._id,
                userId: selectedUserId,
            }).unwrap();
            renderAlertSuccess(res?.message || "User added to team successfully");
            setSelectedUserId("");
            setDropdownVisible(false);
        } catch (error: any) {
            renderAlertError(error?.data?.message || "Failed to add user to team");
        }

    }
    return (
        <View style={{ marginVertical: 20 }}>
            <TouchableOpacity
                style={{
                    alignItems: 'center',
                    justifyContent: 'center',
                    flexDirection: 'column',
                }}
                onPress={() => setDropdownVisible(true)}
            >
                <FontAwesome name="plus-square-o" size={20} color="white" />
                {/* <Text style={{
                    color: 'white',
                    fontSize: 10,
                    fontWeight: 'bold',
                }} >Add User</Text> */}

            </TouchableOpacity>

            <Modal visible={dropdownVisible} animationType="slide" transparent>
                <View
                    style={{
                        flex: 1,
                        justifyContent: 'center',
                        backgroundColor: '#000000aa',

                    }}
                >
                    <View
                        style={{
                            marginHorizontal: 20,
                            height: '70%',
                            borderRadius: radius._10,
                            borderWidth: 1,
                            backgroundColor: 'black',
                            padding: 20,

                        }}
                    >
                        <View style={styles.teamListHeader}>
                            <Text style={styles.name}>Add User</Text>

                            <AntDesign name="close" size={20} color="white" onPress={() => {
                                setDropdownVisible(false)
                                setSelectedUserId("");
                            }} />
                        </View>

                        <View style={{ paddingVertical: spacingY._10, alignItems: 'center', justifyContent: 'center', borderBottomWidth: 2, borderColor: '#00FFAA' }}>
                            <Text style={styles.name}>{teamData?.teamName}</Text>

                        </View>

                        <FlatList
                            data={users}
                            keyExtractor={(item) => item._id.toString()}
                            renderItem={({ item }) => (
                                <TouchableOpacity
                                    onPress={() => {
                                        setSelectedUserId(item._id);
                                    }}
                                    style={{
                                        flexDirection: 'row',
                                        alignItems: 'center',
                                        paddingVertical: 8,
                                    }}
                                >
                                    <RadioButton
                                        value={item._id}
                                        status={
                                            selectedUserId === item._id ? 'checked' : 'unchecked'
                                        }
                                        onPress={() => {
                                            setSelectedUserId(item._id);
                                        }}
                                    />
                                    <Text style={{ color: 'white' }}>{item.name}</Text>
                                </TouchableOpacity>
                            )}
                        />


                        <SingleButton
                            disabled={!selectedUserId}
                            loading={joinTeamIsLoading}
                            onPress={handleAddUserToTeam}
                            title="Add User"
                        />

                    </View>
                </View>
            </Modal>
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flexDirection: 'row',
        height: verticalScale(54),
        alignItems: 'center',
        justifyContent: 'center',
        borderWidth: 1,
        borderColor: colors.neutral400,
        borderRadius: 30,
        borderCurve: 'continuous',
        paddingHorizontal: spacingX._15,
        gap: spacingX._10,
    },
    name: {
        color: '#fff',
        fontWeight: 'bold',
        fontSize: 16,
    },
    teamListHeader: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
    },
});
export default UserDropdown;
