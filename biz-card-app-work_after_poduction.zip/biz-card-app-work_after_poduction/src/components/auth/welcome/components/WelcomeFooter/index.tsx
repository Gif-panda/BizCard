import Button from "@/components/Button";
import Typo from "@/components/Typo";
import { colors, spacingX, spacingY } from "@/constants/theme";
import { welcomeSteps } from "@/src/constants/welcomeHeading";
import { verticalScale } from "@/utils/styling";
import React from "react";
import { View, StyleSheet } from "react-native";
import Animated, {
  FadeInDown,
  SlideInLeft,
  SlideInRight,
  SlideOutLeft,
  SlideOutRight,
} from "react-native-reanimated";
import { WelcomeFooterProps } from "../types";
import { useRouter } from "expo-router";
import { useDispatch } from "react-redux";
import { onBoardingComplete } from "@/store/slices/card/cardSlice";

const WelcomeFooter: React.FC<WelcomeFooterProps> = ({ step }) => {
  const router = useRouter();
  const dispatch = useDispatch();

  const handleGetStarted = () => {
    dispatch(onBoardingComplete());
    router.push("/(auth)/register");
  };
  return (
    <View style={styles.footer}>
      <Animated.View
        entering={FadeInDown.duration(1000).delay(100).springify().damping(12)}
        style={{ alignItems: "center", gap: 2 }}
      >
        <Animated.View
          key={`title-${step}`}
          entering={SlideInRight.duration(300)}
          exiting={SlideOutLeft.duration(400)}
        >
          <Typo size={25} color={"#fff"}>
            {welcomeSteps[step - 1]?.title}
          </Typo>
        </Animated.View>

        <Animated.View
          key={`desc-${step}`}
          entering={SlideInRight.duration(300).delay(50)}
          exiting={SlideOutLeft.duration(400)}
        >
          <Typo
            size={14}
            style={{ paddingHorizontal: 40, textAlign: "center" }}
            color={"#fff"}
          >
            {welcomeSteps[step - 1]?.description}
          </Typo>
        </Animated.View>

        <View style={styles.stepperContainer}>
          {[1, 2, 3].map((item) => (
            <View
              key={item}
              style={[
                styles.bullet,
                { backgroundColor: step === item ? "#1FFA9E" : "#FFFFFF" },
              ]}
            />
          ))}
        </View>
      </Animated.View>

      <Animated.View
        entering={FadeInDown.duration(1000).delay(200).springify().damping(12)}
        style={styles.buttonContainer}
      >
        <Button
          onPress={handleGetStarted}
          disabled={step < 3}
        >
          <Typo size={22} color={"black"} fontWeight={"600"}>
            Get Started
          </Typo>
        </Button>
      </Animated.View>
    </View>
  );
};

const styles = StyleSheet.create({
  footer: {
    backgroundColor: colors.neutral900,
    alignItems: "center",
    paddingTop: verticalScale(30),
    paddingBottom: verticalScale(45),
    gap: spacingY._20,
  },
  buttonContainer: {
    width: "100%",
    paddingHorizontal: spacingX._25,
  },

  stepperContainer: {
    flexDirection: "row",
    marginTop: 8,
    gap: 8,
  },

  bullet: {
    width: 8,
    height: 8,
    borderRadius: 5,
  },
});

export default WelcomeFooter;
