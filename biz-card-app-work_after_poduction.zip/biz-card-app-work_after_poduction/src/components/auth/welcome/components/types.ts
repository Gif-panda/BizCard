export interface WelcomeFooterProps {
    step: number;
    handleNext: () => void;
}