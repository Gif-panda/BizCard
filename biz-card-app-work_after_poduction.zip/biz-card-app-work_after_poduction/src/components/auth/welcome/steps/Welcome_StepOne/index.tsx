import { Image, StyleSheet, View } from 'react-native';
import React, { useEffect } from 'react';
import { colors, spacingX, spacingY } from '@/constants/theme';
import Animated, { runOnJS, useAnimatedStyle, useSharedValue, withDelay, withTiming } from 'react-native-reanimated';



const Welcome_StepOne = ({ handleNext }: {
    handleNext: () => void
}) => {
    const firstCardY = useSharedValue(20);
    const firstOpacity = useSharedValue(0);
    const secondCardX = useSharedValue(0);
    const secondCardY = useSharedValue(0);
    const secondOpacity = useSharedValue(0);
    const thirdCardX = useSharedValue(0);
    const thirdCardY = useSharedValue(0);
    const thirdOpacity = useSharedValue(0);

    useEffect(() => {
        firstCardY.value = withTiming(0, { duration: 1000 });
        firstOpacity.value = withTiming(1, { duration: 1000 });
        secondCardX.value = withDelay(500, withTiming(-20, { duration: 1000 }));
        secondCardY.value = withDelay(500, withTiming(-20, { duration: 1000 }));
        secondOpacity.value = withDelay(500, withTiming(1, { duration: 1000 }));
        thirdCardX.value = withDelay(800, withTiming(-30, { duration: 1000 }));
        thirdCardY.value = withDelay(800, withTiming(-40, { duration: 1000 }));
        thirdOpacity.value = withDelay(800, withTiming(1, { duration: 1000 }, (finished) => {
            if (finished) {
                runOnJS(handleNext)();
            }
        }));

    }, []);

    const animatedFirst = useAnimatedStyle(() => ({
        transform: [{ translateY: firstCardY.value }],
        opacity: firstOpacity.value,
    }));

    const animatedSecond = useAnimatedStyle(() => ({
        transform: [{ translateX: secondCardX.value }, { translateY: secondCardY.value }, { scale: 0.95 }],
        opacity: secondOpacity.value,
    }));

    const animatedThird = useAnimatedStyle(() => ({
        transform: [{ translateX: thirdCardX.value }, { translateY: thirdCardY.value }, { scale: 0.9 }],
        opacity: thirdOpacity.value,
    }));



    return (
        <View style={styles.container}>
            <View style={styles.cardStackWrapper}>
                <Image source={require('../../../../../../assets/welcome/circle-background.png')} style={styles.circleBackground} resizeMode="contain" />
                <Animated.Image source={require('../../../../../../assets/welcome/third-card.png')} style={[styles.card, animatedThird]} resizeMode="contain" />
                <Animated.Image source={require('../../../../../../assets/welcome/second-card.png')} style={[styles.card, animatedSecond]} resizeMode="contain" />
                <Animated.Image source={require('../../../../../../assets/welcome/first-card.png')} style={[styles.card, animatedFirst]} resizeMode="contain" />
            </View>


        </View>
    );
};

export default Welcome_StepOne;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: colors.neutral900,
        justifyContent: 'space-between',
        paddingTop: spacingY._7,
    },
    cardStackWrapper: {
        alignItems: 'center',
        justifyContent: 'center',
        flex: 1,
    },
    circleBackground: {
        width: 320,
        height: 320,
        position: 'absolute',
        alignSelf: 'center',
    },
    card: {
        width: 230,
        height: 230,
        position: 'absolute',
    },
    footer: {
        backgroundColor: colors.neutral900,
        alignItems: 'center',
        paddingTop: 30,
        paddingBottom: 45,
        gap: spacingY._20,
        shadowColor: 'white',
        shadowOffset: { width: 0, height: -10 },
        elevation: 10,
        shadowRadius: 25,
        shadowOpacity: 0.15,
    },
    buttonContainer: {
        width: '100%',
        paddingHorizontal: spacingX._25,
    },
});
