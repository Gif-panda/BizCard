import React, { useEffect } from 'react';
import { Image, StyleSheet, Text, View } from 'react-native';
import Animated, {
    useSharedValue,
    useAnimatedStyle,
    withTiming,
    withDelay,
    Easing,
} from 'react-native-reanimated';
import { MaterialIcons, Feather, Entypo } from '@expo/vector-icons';
import { colors, spacingY } from '@/constants/theme';

const LABELS = [
    {
        id: 'company',
        source: require('../../../../../../assets/welcome/company-icon.png'),
        text: 'Company',
        target: { x: -100, y: -80 },
        bgColor: colors.neutral700,
        delay: 300,
    },
    {
        id: 'email',
        source: require('../../../../../../assets/welcome/email-icon.png'),
        text: 'Email',
        target: { x: 100, y: -80 },
        bgColor: '#079057',
        delay: 450,
    },
    {
        id: 'number',
        source: require('../../../../../../assets/welcome/call-icon.png'),
        text: 'Number',
        target: { x: -100, y: 80 },
        bgColor: '#079057',
        delay: 600,
    },
    {
        id: 'name',
        source: require('../../../../../../assets/welcome/name-icon.png'),
        text: 'Name',
        target: { x: 100, y: 80 },
        bgColor: colors.neutral700,
        delay: 750,
    },
];

const Welcome_StepThree = () => {
    const scaleCard = useSharedValue(1);

    const labelAnims = LABELS.map(() => ({
        x: useSharedValue(0),
        y: useSharedValue(0),
        opacity: useSharedValue(0),
        scale: useSharedValue(0.3),
    }));

    useEffect(() => {
        // Shrink card first
        scaleCard.value = withTiming(0.9, { duration: 300, easing: Easing.out(Easing.exp) });

        // Animate labels
        labelAnims.forEach((anim, idx) => {
            const { x, y, opacity, scale } = anim;
            const { target, delay } = LABELS[idx];
            x.value = withDelay(
                delay,
                withTiming(target.x, { duration: 600, easing: Easing.out(Easing.exp) })
            );
            y.value = withDelay(
                delay,
                withTiming(target.y, { duration: 600, easing: Easing.out(Easing.exp) })
            );
            opacity.value = withDelay(
                delay,
                withTiming(1, { duration: 400 })
            );
            scale.value = withDelay(
                delay,
                withTiming(1, { duration: 400 })
            );
        });

        // Scale card back
        setTimeout(() => {
            scaleCard.value = withTiming(1, { duration: 300, easing: Easing.out(Easing.exp) });
        }, 1000);
    }, []);

    const animatedCardStyle = useAnimatedStyle(() => ({
        transform: [{ scale: scaleCard.value }],
    }));

    return (
        <View style={styles.container}>
            <View style={styles.cardWrapper}>
                <Image
                    source={require('../../../../../../assets/welcome/circle-background.png')}
                    style={styles.circleBackground}
                    resizeMode="contain"
                />

                <Animated.Image
                    source={require('../../../../../../assets/welcome/first-card.png')}
                    style={[styles.card, animatedCardStyle]}
                    resizeMode="contain"
                />

                {LABELS.map((label, idx) => {
                    const anim = labelAnims[idx];
                    const animatedStyle = useAnimatedStyle(() => ({
                        transform: [
                            { translateX: anim.x.value },
                            { translateY: anim.y.value },
                            { scale: anim.scale.value },
                        ],
                        opacity: anim.opacity.value,
                    }));

                    return (
                        <Animated.View key={label.id} style={[styles.label, animatedStyle, { backgroundColor: label.bgColor }]}>
                            <Image source={label.source} style={styles.labelImage} />
                            <Text style={styles.labelText}>{label.text}</Text>
                        </Animated.View>
                    );
                })}
            </View>
        </View>
    );
};

export default Welcome_StepThree;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: colors.neutral900,
        justifyContent: 'space-between',
        paddingTop: spacingY._7,
    },
    cardWrapper: {
        alignItems: 'center',
        justifyContent: 'center',
        flex: 1,
    },
    card: {
        width: 170,
        height: 200,
        zIndex: 2,
    },
    circleBackground: {
        width: 320,
        height: 320,
        position: 'absolute',
        alignSelf: 'center',
    },
    label: {
        position: 'absolute',
        flexDirection: 'row',
        alignItems: 'center',
        paddingVertical: 12,
        paddingHorizontal: 14,
        borderRadius: 18,
        zIndex: 3,
        borderWidth: 1,
        borderColor: '#51586A',
    },
    labelText: {
        color: '#fff',
        marginLeft: 6,
        fontWeight: '600',
    },
    labelImage: {
        width: 18,
        height: 18,
    },
});
