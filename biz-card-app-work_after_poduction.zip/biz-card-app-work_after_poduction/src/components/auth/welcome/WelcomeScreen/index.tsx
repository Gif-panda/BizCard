import React, { useState } from 'react';
import { View, StyleSheet, TouchableOpacity } from 'react-native';

import Typo from '@/components/Typo';
import { colors, } from '@/constants/theme';
import Welcome_StepOne from '../steps/Welcome_StepOne';
import Welcome_StepTwo from '../steps/Welcome_StepTwo';
import Welcome_StepThree from '../steps/Welcome_StepThree';
import WelcomeFooter from '../components/WelcomeFooter';
import { useRouter } from 'expo-router';


const WelcomeScreen = () => {
    const router = useRouter();
    const [step, setStep] = useState(1);

    const handleNext = () => setStep(prev => prev + 1);
    const handleSkip = () => {

        router.push('/(main)/home');

    }


    return (
        <View style={styles.container}>

            {step < 3 && (
                <TouchableOpacity style={styles.skipButton} onPress={() => { handleSkip(); }}>
                    <Typo color={colors.white}>Skip</Typo>
                </TouchableOpacity>
            )}

            {step === 1 && <Welcome_StepOne handleNext={handleNext} />}
            {step === 2 && <Welcome_StepTwo handleNext={handleNext} />}
            {step === 3 && <Welcome_StepThree />}

            <WelcomeFooter step={step} handleNext={handleNext} />
        </View>
    );
};

export default WelcomeScreen;

const styles = StyleSheet.create({
    container: {
        flex: 1,
        backgroundColor: '#000',
    },

    skipButton: {
        position: 'absolute',
        top: 50,
        right: 20,
        zIndex: 1,
        padding: 10,
    },
});
