import React from 'react';
import { TouchableOpacity, Image, StyleSheet, ViewStyle, ImageStyle, GestureResponderEvent, ImageSourcePropType } from 'react-native';

interface CircleButtonProps {
    onPress?: (event: GestureResponderEvent) => void;
    iconSource: ImageSourcePropType;
    wrapperStyle?: ViewStyle;
    iconStyle?: ImageStyle;
}

const CircleButton: React.FC<CircleButtonProps> = ({
    onPress,
    iconSource,
    wrapperStyle,
    iconStyle,
}) => {
    return (
        <TouchableOpacity
            onPress={onPress}
            style={[styles.iconWrapper, wrapperStyle]}
        >
            <Image
                source={iconSource}
                style={[styles.icon, iconStyle]}
                resizeMode="contain"
            />
        </TouchableOpacity>
    );
};

const styles = StyleSheet.create({
    iconWrapper: {
        width: 40,
        height: 40,
        marginRight: 5,
        backgroundColor: '#1A1B1D',
        borderRadius: 20,
        justifyContent: 'center',
        alignItems: 'center',
        borderWidth: 1,
        borderColor: '#3B3839',
    },

    icon: {
        width: 14,
        height: 14,
    },
});

export default CircleButton;
