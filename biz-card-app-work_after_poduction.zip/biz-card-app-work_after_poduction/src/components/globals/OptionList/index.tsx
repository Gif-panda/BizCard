import { spacingY } from '@/constants/theme';
import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet, FlatList, Image, ViewStyle } from 'react-native';

interface Option {
    id: string;
    label: string;
    icon: any;
    onPress: () => void;
}

interface OptionsListProps {
    options: Option[];
    containerStyle?: ViewStyle;
}

const OptionsList: React.FC<OptionsListProps> = ({ options, containerStyle }) => {
    return (
        <View style={[styles.container, containerStyle]}>
            <FlatList
                data={options}
                keyExtractor={(item) => item.id}
                renderItem={({ item, index }) => (
                    <TouchableOpacity onPress={item.onPress} style={[
                        styles.optionButton,
                        index === 0 && styles.firstItem,
                        index === options.length - 1 && styles.lastItem
                    ]}>
                        <Image source={item.icon} style={styles.icon} resizeMode="contain" />
                        <Text style={styles.label}>{item.label}</Text>
                    </TouchableOpacity>
                )}
                ItemSeparatorComponent={() => <View style={styles.separator} />}
            />
        </View>
    );
};

export default OptionsList;

const styles = StyleSheet.create({
    container: {
        backgroundColor: '#1A1A1A', // Dark background
        borderRadius: 16,
        paddingVertical: spacingY._10,
    },
    optionButton: {
        flexDirection: 'row',
        alignItems: 'center',
        paddingVertical: 16,
        paddingHorizontal: 20,
    },
    icon: {
        width: 24,
        height: 24,
        marginRight: 16,
    },
    label: {
        color: '#FFFFFF',
        fontSize: 16,
    },
    separator: {
        height: 3,
        backgroundColor: '#0E0E0E',
    },
    firstItem: {
        borderTopLeftRadius: 16,
        borderTopRightRadius: 16,
    },
    lastItem: {
        borderBottomLeftRadius: 16,
        borderBottomRightRadius: 16,
    },
});
