import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

const DividerWithText = ({ text = 'Or' }) => {
    return (
        <View style={styles.container}>
            <View style={styles.line} />
            <Text style={styles.text}>{text}</Text>
            <View style={styles.line} />
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flexDirection: 'row',
        alignItems: 'center',
        marginVertical: 16,
    },
    line: {
        flex: 1,
        height: 1,
        backgroundColor: '#ccc',
    },
    text: {
        marginHorizontal: 10,
        color: '#888',
        fontWeight: '500',
    },
});

export default DividerWithText;
