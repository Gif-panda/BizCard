import React, { memo, useEffect, useRef } from "react";
import {
  StyleSheet,
  ActivityIndicator,
  Modal,
  Animated,
  Easing,
  StyleProp,
  ViewStyle,
  View,
  Text,
} from "react-native";

interface GlobalLoaderProps {
  loading: boolean;
  color?: string;
  overlayStyle?: StyleProp<ViewStyle>;
}

const GlobalLoader: React.FC<GlobalLoaderProps> = memo(
  ({ loading, color = "#00FFAA", overlayStyle }) => {
    const opacity = useRef(new Animated.Value(0)).current;
    useEffect(() => {
      Animated.timing(opacity, {
        toValue: loading ? 1 : 0,
        duration: 200,
        easing: Easing.out(Easing.ease),
        useNativeDriver: true,
      }).start();
    }, [loading, opacity]);
    return (
      <Modal
        transparent
        animationType="none"
        visible={loading}
        onRequestClose={() => {}}
      >
        <Animated.View style={[styles.overlay, overlayStyle, { opacity }]}>
          {loading && <View style={styles.container}> <Text><ActivityIndicator size="large" color={color} /></Text> </View>}
        </Animated.View>
      </Modal>
    );
  }
);

const styles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.5)",
    justifyContent: "center",
    alignItems: "center",
  },
  container:{
    backgroundColor: "#1E1E1E",
    borderRadius: 16,
    padding: 24,
    shadowColor: "#000",
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
    justifyContent: 'center',
    alignItems: 'center',
  }
});

export default GlobalLoader;
