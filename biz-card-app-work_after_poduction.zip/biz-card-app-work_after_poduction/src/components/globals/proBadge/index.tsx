import React from "react";
import { View, Text, StyleSheet } from "react-native";
import { FontAwesome6, MaterialCommunityIcons } from "@expo/vector-icons";


const ProBadge: React.FC<any> = () => {
  return (
    <View style={styles.wrapper}>
        <View style={styles.badgeContainer}>
          <View style={styles.badge}>
            <Text style={styles.badgeText}>PRO</Text>
            <MaterialCommunityIcons
              name="crown"
              size={14}
              color="gold"
              style={{ marginLeft: 3 }}
            />
          </View>
        </View>
    </View>
  );
};

const styles = StyleSheet.create({
  wrapper: {
    position: "relative",
  },
  badgeContainer: {
    position: "absolute",
    top: 6,
    right: 6,
    backgroundColor: "rgba(0,0,0,1)",
    borderRadius: 12,
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  badge: {
    flexDirection: "row",
    alignItems: "center",
  },
  badgeText: {
    color: "white",
    fontWeight: "600",
    fontSize: 10,
  },
});

export default ProBadge;
