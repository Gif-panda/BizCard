import React from 'react';
import { View, TextInput, StyleSheet, Text, Image } from 'react-native';
import { InputFieldProps } from '../types';

const SingleInputField: React.FC<InputFieldProps> = (props) => {
    return (
        <View style={styles.inputContainer}>
            <Text style={styles.name}>{props.placeholder}</Text>

            <View style={styles.inputWrapper}>
                <TextInput
                    editable={props.isEditable}
                    style={styles.input}
                    placeholderTextColor="white"
                    {...props}
                />
                <Image
                    source={require('@/assets/main/edit-icon.png')}
                    resizeMode="contain"
                    style={[
                        styles.icon,
                        { tintColor: props.isEditable ? 'white' : 'gray' },
                    ]}
                />
            </View>
        </View>
    );
};

const styles = StyleSheet.create({
    name: {
        fontSize: 18,
        color: 'white',
        fontWeight: 'bold',
    },
    inputContainer: {
        marginVertical: 5,
        gap: 10,
    },
    inputWrapper: {
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#2E2E2E',
        borderRadius: 30,
        paddingHorizontal: 15,
    },
    input: {
        flex: 1,
        color: '#fff',
        paddingVertical: 15,
    },
    icon: {
        width: 16,
        height: 16,
    },
});

export default SingleInputField;
