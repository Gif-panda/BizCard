import React from 'react';
import { TouchableOpacity, Text, StyleSheet, ActivityIndicator } from 'react-native';
import { SingleButtonProps } from '../types';

interface Props extends SingleButtonProps {
    disabled?: boolean;
    loading?: boolean;
}

const SingleButton: React.FC<Props> = ({ title, onPress, disabled = false, loading = false }) => {
    // Disable button if disabled or loading
    const isDisabled = disabled || loading;

    return (
        <TouchableOpacity
            style={[styles.button, isDisabled && styles.buttonDisabled]}
            onPress={onPress}
            disabled={isDisabled}
            activeOpacity={0.7}
        >
            {loading ? (
                <ActivityIndicator size="small" color="white" />
            ) : (
                <Text style={[styles.buttonText, isDisabled && styles.textDisabled]}>{title}</Text>
            )}
        </TouchableOpacity>
    );
};

const styles = StyleSheet.create({
    button: {
        backgroundColor: '#00FFAA',
        padding: 15,
        borderRadius: 30,
        alignItems: 'center',
        marginTop: 20,
    },
    buttonDisabled: {
        backgroundColor: 'gray',
    },
    buttonText: {
        color: '#000',
        fontWeight: 'bold',
        fontSize: 16,
    },
    textDisabled: {
        color: 'white',
    },
});

export default SingleButton;
