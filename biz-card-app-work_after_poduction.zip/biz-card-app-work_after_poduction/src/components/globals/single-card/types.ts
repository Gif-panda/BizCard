import { TextInputProps } from 'react-native';

export interface SingleButtonProps {
  title: string;
  onPress?: () => void;
}

export interface InputFieldProps extends TextInputProps {
  placeholder?: string;
  isEditable?: boolean;
}
