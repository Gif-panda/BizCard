import React, { useMemo } from 'react';
import { View, Text, Image, StyleSheet } from 'react-native';
import { spacingY } from '@/constants/theme';
import WaveSvg from '@/constants/waveSvg';
import { getBasicColor, getGradientColors } from '@/src/constants/createCard';

interface CardProps {
  cardDetails: any;
  isProUser?: boolean;
}

const SingleBizCard: React.FC<CardProps> = ({ cardDetails,isProUser }) => {
  const shouldShowWatermark = Boolean(cardDetails?.cardDetails?.waterMark);
  const isProAccess = Boolean(isProUser);
  const cardType = useMemo(
    () => cardDetails?.cardDetails?.template?.templateType,
    [cardDetails?.cardDetails?.template?.templateType]
  );
  const useGradient = useMemo(
    () => cardDetails?.cardDetails?.template?.useGradient,
    [cardDetails?.cardDetails?.template?.useGradient]
  );
  const textColor = useMemo(
    () => cardDetails?.cardDetails?.template?.textColor,
    [cardDetails?.cardDetails?.template?.textColor]
  );

  const gradientColors = useMemo(
    () => getGradientColors(cardDetails?.cardDetails?.template?.templateColor),
    [cardDetails?.cardDetails?.template?.templateColor]
  );
  const solidColor = useMemo(
    () => getBasicColor(cardDetails?.cardDetails?.template?.templateColor),
    [cardDetails?.cardDetails?.template?.templateColor]
  );

  const profileStyles: any = {
    modern: styles.profileSectionModern,
    classic: styles.profileSection,
    sleek: styles.profileSectionSleek,
  };

  /** ---------- Dynamic text + font sizes ---------- */
  const nameText = `${cardDetails?.ContactDetails?.firstName || 'First Name'} ${
    cardDetails?.ContactDetails?.lastName || 'Last Name'
  }`;
  const nameFontSize = useMemo(() => {
    if (nameText.length <= 10) return 16;
    if (nameText.length <= 20) return 14;
    if (nameText.length <= 30) return 12;
    return 10;
  }, [nameText]);

  const orgPosText = `${
    cardDetails?.ContactDetails?.organization || 'Agency Name'
  } | ${cardDetails?.ContactDetails?.position || 'Position'}`;
  const orgPosFontSize = useMemo(() => {
    if (orgPosText.length <= 20) return 12;
    if (orgPosText.length <= 30) return 11;
    return 10;
  }, [orgPosText]);

  const emailText = cardDetails?.ContactDetails?.email || 'Email';
  const emailFontSize = useMemo(() => {
    if (emailText.length <= 25) return 12;
    if (emailText.length <= 35) return 11;
    return 10;
  }, [emailText]);

  const phoneText = cardDetails?.ContactDetails?.phoneNumber || 'Phone no';
  const phoneFontSize = useMemo(() => {
    if (phoneText.length <= 20) return 12;
    if (phoneText.length <= 30) return 11;
    return 10;
  }, [phoneText]);
  /** ---------------------------------------------- */

  return (
    <View>
      <View style={styles.cardContainer}>
        <WaveSvg
          cardType={cardType}
          useGradient={useGradient}
          gradientColors={gradientColors}
          solidColor={solidColor}
        />

        <View style={profileStyles[cardType] || styles.profileSection}>
          <Image
            source={
              cardDetails?.ContactDetails?.photo
                ? { uri: cardDetails.ContactDetails.photo }
                : require('@/assets/card/dummy-image.jpg')
            }
            style={styles.profileImage}
          />

          <View style={cardType === 'Sleek' ? styles.detailSleek : styles.detailNonSleek}>
            <Text style={[styles.nameText, { color: textColor, fontSize: nameFontSize }]}>
              {nameText}
            </Text>
            <Text style={[styles.detailText, { color: textColor, fontSize: orgPosFontSize }]}>
              {orgPosText}
            </Text>
          </View>
{shouldShowWatermark && !isProAccess ? (
  <Image source={require('@/assets/card/biz-card-logo.png')} />
): <View></View>}
          
        </View>

        <View
          style={cardType === 'classic' ? styles.detailSection : styles.nonClassicDetailSection}
        >
          <View>
            <View style={styles.iconRow}>
              <Image source={require('@/assets/card/call-icon.png')} style={styles.icon} />
              <Text style={[styles.detailBottom, { color: textColor, fontSize: emailFontSize }]}>
                {emailText}
              </Text>
            </View>
            <View style={styles.iconRow}>
              <Image source={require('@/assets/card/email-icon.png')} style={styles.icon} />
              <Text style={[styles.detailBottom, { color: textColor, fontSize: phoneFontSize }]}>
                {phoneText}
              </Text>
            </View>
          </View>

          <View>
            <Image
              source={
                cardDetails?.ContactDetails?.logo
                  ? { uri: cardDetails.ContactDetails.logo }
                  : require('@/assets/card/dummy-logo.png')
              }
              style={styles.profileImage}
            />
          </View>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  detailSleek: { flexDirection: 'column', alignItems: 'flex-start' },
  detailNonSleek: { flexDirection: 'column', alignItems: 'center' },
  iconRow: { flexDirection: 'row', alignItems: 'center' },
  icon: { width: 20, height: 20, marginRight: 8 },
  profileSection: {
    position: 'absolute',
    padding: 15,
    justifyContent: 'space-between',
    width: '100%',
    gap: 10,
    flexDirection: 'row',
    alignItems: 'center',
  },
  profileSectionModern: {
    position: 'absolute',
    paddingTop: 60,
    paddingHorizontal: 15,
    gap: 10,
    flexDirection: 'row',
    alignItems: 'center',
  },
  profileSectionSleek: {
    position: 'absolute',
    paddingTop: 25,
    gap: 10,
    flexDirection: 'column',
    alignItems: 'center',
    justifyContent: 'center',
    width: '100%',
  },
  detailSection: {
    position: 'absolute',
    paddingTop: 120,
    paddingHorizontal: 10,
    gap: 10,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '100%',
  },
  nonClassicDetailSection: {
    position: 'absolute',
    paddingTop: 120,
    paddingHorizontal: 10,
    gap: 10,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    width: '100%',
  },
  profileImage: { width: 50, height: 50, borderRadius: 30 },
  cardContainer: {
    width: '100%',
    height: 180,
    borderRadius: 30,
    borderColor: 'white',
    borderWidth: 1,
    overflow: 'hidden',
    elevation: 8,
    backgroundColor: 'white',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.15,
    shadowRadius: 10,
  },
  nameText: { fontWeight: 'bold' },
  detailText: { marginTop: 4 },
  detailBottom: { marginTop: 4 },
});

export default SingleBizCard;
