import React, { PropsWithChildren, useCallback, useEffect, useState } from "react";
import {
  ActivityIndicator,
  AppState,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from "react-native";

const CHECK_URLS = [
  "https://clients3.google.com/generate_204",
  "https://www.gstatic.com/generate_204",
];

const TIMEOUT_MS = 5000;
const POLL_MS = 12000;

const fetchWithTimeout = async (url: string, timeoutMs: number) => {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(url, {
      method: "GET",
      cache: "no-store",
      signal: controller.signal,
    });
    return response.ok;
  } catch {
    return false;
  } finally {
    clearTimeout(timeoutId);
  }
};

const NetworkGuard: React.FC<PropsWithChildren> = ({ children }) => {
  const [isOffline, setIsOffline] = useState(false);
  const [isChecking, setIsChecking] = useState(true);

  const checkConnectivity = useCallback(async () => {
    setIsChecking(true);

    let connected = false;
    for (const url of CHECK_URLS) {
      // eslint-disable-next-line no-await-in-loop
      const result = await fetchWithTimeout(url, TIMEOUT_MS);
      if (result) {
        connected = true;
        break;
      }
    }

    setIsOffline(!connected);
    setIsChecking(false);
  }, []);

  useEffect(() => {
    checkConnectivity();

    const poller = setInterval(() => {
      checkConnectivity();
    }, POLL_MS);

    const appStateSub = AppState.addEventListener("change", state => {
      if (state === "active") {
        checkConnectivity();
      }
    });

    return () => {
      clearInterval(poller);
      appStateSub.remove();
    };
  }, [checkConnectivity]);

  return (
    <View style={styles.root}>
      {children}

      {isOffline ? (
        <View style={styles.overlay}>
          <Text style={styles.title}>No Internet Connection</Text>
          <Text style={styles.subtitle}>
            Please check your mobile data or Wi-Fi and try again.
          </Text>

          <TouchableOpacity
            style={styles.button}
            onPress={checkConnectivity}
            disabled={isChecking}
          >
            {isChecking ? (
              <ActivityIndicator color="#000" size="small" />
            ) : (
              <Text style={styles.buttonText}>Retry</Text>
            )}
          </TouchableOpacity>
        </View>
      ) : null}
    </View>
  );
};

export default NetworkGuard;

const styles = StyleSheet.create({
  root: {
    flex: 1,
  },
  overlay: {
    ...StyleSheet.absoluteFillObject,
    backgroundColor: "#000",
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 24,
    zIndex: 9999,
  },
  title: {
    color: "#fff",
    fontSize: 22,
    fontWeight: "700",
    marginBottom: 10,
  },
  subtitle: {
    color: "#A9A9A9",
    textAlign: "center",
    fontSize: 14,
    lineHeight: 20,
    marginBottom: 24,
  },
  button: {
    minWidth: 120,
    height: 44,
    borderRadius: 24,
    backgroundColor: "#00FFAA",
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 20,
  },
  buttonText: {
    color: "#000",
    fontSize: 14,
    fontWeight: "700",
  },
});
