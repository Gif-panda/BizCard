import React from "react";
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  LayoutAnimation,
  Platform,
  UIManager,
} from "react-native";
import Animated, {
  useAnimatedStyle,
  useSharedValue,
  withTiming,
} from "react-native-reanimated";
import { SlideInView } from "../../animations";

// if (
//   Platform.OS === "android" &&
//   UIManager.setLayoutAnimationEnabledExperimental
// ) {
//   UIManager.setLayoutAnimationEnabledExperimental(true);
// }

interface AccordionProps {
  id: string;
  title: string;
  content: string;
  expanded: boolean;
  onPress: () => void;
  isFirst?: boolean;
  isLast?: boolean;
}

const Accordion: React.FC<AccordionProps> = ({
  title,
  content,
  expanded,
  onPress,
  isFirst = false,
  isLast = false,
}) => {
  const height = useSharedValue(0);
  const opacity = useSharedValue(0);

  React.useEffect(() => {
    if (expanded) {
      height.value = withTiming(1, { duration: 300 });
      opacity.value = withTiming(1, { duration: 300 });
    } else {
      height.value = withTiming(0, { duration: 300 });
      opacity.value = withTiming(0, { duration: 300 });
    }
  }, [expanded]);

  const animatedStyle = useAnimatedStyle(() => {
    return {
      height: height.value === 0 ? 0 : undefined,
      opacity: opacity.value,
    };
  });

  return (
    <SlideInView>
    <View
      style={[
        styles.container,
        isFirst && styles.firstItem,
        isLast && !expanded && styles.lastItem,
      ]}
    >
      <TouchableOpacity
        activeOpacity={0.8}
        onPress={() => {
          LayoutAnimation.configureNext(LayoutAnimation.Presets.easeInEaseOut);
          onPress();
        }}
        style={styles.header}
      >
        <Text style={styles.title}>{title}</Text>
        <Text style={styles.iconText}>{expanded ? "–" : "+"}</Text>
      </TouchableOpacity>

      {expanded && (
        <Animated.View style={[styles.contentContainer, animatedStyle]}>
          <Text style={styles.content}>{content}</Text>
        </Animated.View>
      )}
    </View>
    </SlideInView>
  );
};

const styles = StyleSheet.create({
  container: {
    backgroundColor: "#1A1A1A",
    borderBottomWidth: 1,
    borderBottomColor: "#333",
  },
  firstItem: {
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
  },
  lastItem: {
    borderBottomLeftRadius: 16,
    borderBottomRightRadius: 16,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    paddingVertical: 18,
    paddingHorizontal: 20,
  },
  title: {
    flex: 1,
    fontSize: 16,
    fontWeight: "500",
    color: "#FFFFFF",
    paddingRight: 12,
  },
  iconText: {
    color: "#888",
    fontSize: 18,
  },
  contentContainer: {
    paddingHorizontal: 20,
    paddingBottom: 20,
    overflow: "hidden",
  },
  content: {
    fontSize: 14,
    lineHeight: 22,
    color: "#CCCCCC",
  },
});

export default Accordion;
