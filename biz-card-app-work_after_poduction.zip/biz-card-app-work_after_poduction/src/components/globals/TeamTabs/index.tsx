import { FC, useEffect, useState } from 'react';
import {
  LayoutChangeEvent,
  Pressable,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import Animated, {
  runOnJS,
  useAnimatedStyle,
  useSharedValue,
  withTiming,
} from 'react-native-reanimated';
import { TeamTabsProps } from './types';
import { colors, spacingX } from '@/constants/theme';

const TeamTabs: FC<TeamTabsProps> = ({
  disableRadious,
  hideMarginLeft,
  hideMarginRight,
  buttons,
  selectedTab,
  setSelectedTab,
  currentActive,
  isWhite,
  onPress,
}) => {
  const [dimensions, setDimensions] = useState({ height: 20, width: 100 });
  const buttonWidth = dimensions.width / buttons.length;

  const tabPositionX = useSharedValue(0);

  useEffect(() => {
    if (currentActive !== undefined) {
      tabPositionX.value = withTiming(buttonWidth * currentActive);
      setSelectedTab(currentActive);
    }
  }, [currentActive, buttonWidth]);

  const onTabbarLayout = (e: LayoutChangeEvent) => {
    setDimensions({
      width: e.nativeEvent.layout.width,
      height: e.nativeEvent.layout.height,
    });
  };

  const handlePressCb = (index: number) => {
    setSelectedTab(index);
  };

  const onTabPress = (index: number) => {
    tabPositionX.value = withTiming(buttonWidth * index, {}, () => {
      runOnJS(handlePressCb)(index);
    });
  };

  const animatedStyle = useAnimatedStyle(() => {
    return {
      transform: [{ translateX: tabPositionX.value }],
    };
  });

  return (
    <View
      style={[
        styles.container,
        {
          backgroundColor: isWhite ? 'white' : '#2C2C2C',
          marginLeft: hideMarginLeft ? 0 : spacingX._12,
          marginRight: hideMarginRight ? 0 : spacingX._12,
          borderRadius: disableRadious ? 0 : 25,
        },
      ]}
    >
      <Animated.View
        style={[
          animatedStyle,
          {
            height: dimensions.height,
            width: buttonWidth,
            backgroundColor: '#6495ED',
            position: 'absolute',
            borderRadius: 25,
          },
        ]}
      />
      <View onLayout={onTabbarLayout} style={styles.tabRow}>
        {buttons.map((button, index) => {
          const color = selectedTab === index ? 'black' : 'white';
          const colorWhite = selectedTab === index ? 'white' : 'gray';

          return (
            <Pressable
              key={button.title}
              style={styles.tabButton}
              accessibilityRole="tab"
              accessibilityLabel={button.accessibilityLabel}
              onPress={() => {
                onTabPress(index);
                onPress && onPress();
              }}
            >
              <Text
                style={{
                  color: isWhite ? colorWhite : color,
                  fontFamily: 'poppins-medium',
                  alignSelf: 'center',
                  fontWeight: '700',
                  fontSize: 14,
                }}
              >
                {button.title}
              </Text>
            </Pressable>
          );
        })}
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    justifyContent: 'center',
    marginVertical: 4,
    borderWidth: 1,
    borderColor: '#3B3839',
    padding: 1,
  },
  tabRow: {
    flexDirection: 'row',
  },
  tabButton: {
    flex: 1,
    justifyContent: 'center',
    paddingVertical: 16,
  },
});

export default TeamTabs;
