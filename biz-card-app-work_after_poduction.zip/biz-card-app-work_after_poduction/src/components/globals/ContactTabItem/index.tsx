import React from 'react';
import { TouchableOpacity, View, Image, Text, StyleSheet, ImageSourcePropType } from 'react-native';

interface ContactTabItemProps {
    label: string;
    icon: any;
    isActive: boolean;
    onPress?: () => void;
    isIcon: boolean;
}

const ContactTabItem: React.FC<ContactTabItemProps> = ({ label, icon, isIcon, isActive, onPress }) => {
    return (
        <TouchableOpacity style={[styles.tab]} onPress={onPress}>
            <View style={[styles.iconWrapper, isActive && styles.activeTab]}>
                {
                    isIcon &&
                    <Text>
                        {
                            icon
                        }</Text>
                }


                {
                    !isIcon && <Image
                        source={icon}
                        style={[
                            styles.icon,
                            isActive ? { tintColor: 'black' } : { tintColor: 'white' },
                        ]}
                        resizeMode="contain"
                    />
                }

            </View>
            <Text style={[styles.tabLabel, isActive && styles.activeTabLabel]}>
                {label}
            </Text>
        </TouchableOpacity>
    );
};

export default ContactTabItem;

const styles = StyleSheet.create({
    tab: {
        height: 35,
        flexDirection: 'row',
        alignItems: 'center',
        backgroundColor: '#2C2C2C',
        borderRadius: 20,
        paddingVertical: 4,
        paddingHorizontal: 8,
        marginRight: 10,
    },
    activeTab: {
        backgroundColor: '#00E676',
    },
    iconWrapper: {
        width: 26,
        height: 26,
        marginRight: 5,
        backgroundColor: 'black',
        borderRadius: 13,
        justifyContent: 'center',
        alignItems: 'center',
        borderWidth: 1,
        borderColor: '#3B3839',
    },
    icon: {
        width: 14,
        height: 14,
    },
    tabLabel: {
        color: 'white',
        fontSize: 11,
        fontWeight: '500',
    },
    activeTabLabel: {
        color: 'white',
        fontWeight: 'bold',
    },
});
