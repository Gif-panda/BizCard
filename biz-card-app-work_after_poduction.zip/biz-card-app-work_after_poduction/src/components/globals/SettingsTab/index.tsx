import { colors, spacingX, spacingY } from "@/constants/theme";
import React from "react";
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  FlatList,
  Image,
  ViewStyle,
} from "react-native";

interface Option {
  id: string;
  label: string;
  icon: any;
  icon2?: any;
  onPress: () => void;
}

interface SettingsTabProps {
  options: Option[];
  containerStyle?: ViewStyle;
}

const SettingsTab: React.FC<SettingsTabProps> = ({
  options,
  containerStyle,
}) => {
  return (
    <View style={[styles.container, containerStyle]}>
      <FlatList
        scrollEnabled={false}
        data={options}
        keyExtractor={(item) => item.id}
        renderItem={({ item, index }) => (
          <TouchableOpacity
            onPress={item.onPress}
            style={[
              styles.optionButton,
              index === 0 && styles.firstItem,
              index === options.length - 1 && styles.lastItem,
            ]}
          >
            <View style={styles.leftSection}>
              <Image
                source={item.icon}
                style={styles.icon}
                resizeMode="contain"
              />
              <Text style={styles.label}>{item.label}</Text>
            </View>
            {item.icon2 && (
              <Image
                source={item.icon2}
                style={styles.icon2}
                resizeMode="contain"
              />
            )}
          </TouchableOpacity>
        )}
        ItemSeparatorComponent={() => <View style={styles.separator} />}
      />
    </View>
  );
};

export default SettingsTab;

const styles = StyleSheet.create({
  container: {
    backgroundColor: colors.black, // Dark background
    borderRadius: 30,
    paddingVertical: spacingY._5,
  },
  optionButton: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between", // <-- Add this!
    paddingVertical: spacingY._10,
    paddingHorizontal: spacingX._20,
  },
  leftSection: {
    flexDirection: "row",
    alignItems: "center",
  },
  icon2: {
    width: 14,
    height: 14,
    marginLeft: 16, // <-- Use marginLeft instead of marginRight for spacing from text
  },
  icon: {
    width: 20,
    height: 20,
    marginRight: 16,
  },

  label: {
    color: "#FFFFFF",
    fontSize: 14,
  },
  separator: {
    height: 3,
    backgroundColor: "#0E0E0E",
  },
  firstItem: {
    borderTopLeftRadius: 16,
    borderTopRightRadius: 16,
  },
  lastItem: {
    borderBottomLeftRadius: 16,
    borderBottomRightRadius: 16,
  },
});
