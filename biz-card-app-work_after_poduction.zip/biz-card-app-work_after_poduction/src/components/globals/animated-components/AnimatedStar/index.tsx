import React from 'react';
import { View, Image, StyleSheet, ViewStyle, ImageStyle } from 'react-native';
import { MotiView } from 'moti';

interface AnimatedStarProps {
    containerStyle?: ViewStyle;
    starStyle?: ImageStyle;
    source?: any;
}

const AnimatedStar: React.FC<AnimatedStarProps> = ({
    containerStyle,
    starStyle,
    source = require('@/assets/auth/auth-star.png'),
}) => {
    return (
        <View style={[styles.starContainer, containerStyle]}>
            <MotiView
                from={{ translateX: -100, scale: 0.5, opacity: 0 }}
                animate={{ translateX: 0, scale: 1, opacity: 1 }}
                transition={{
                    type: 'timing',
                    duration: 600,
                }}
            >
                <Image source={source} style={[styles.star, starStyle]} resizeMode="contain" />
            </MotiView>
        </View>
    );
};

const styles = StyleSheet.create({
    starContainer: {
        display: 'flex',
        justifyContent: 'flex-end',
        alignItems: 'flex-end',
    },
    star: {
        width: 60,
        height: 60,
    },
});

export default AnimatedStar;
