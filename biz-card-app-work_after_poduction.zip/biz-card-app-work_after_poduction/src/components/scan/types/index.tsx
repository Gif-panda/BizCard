export interface ExtractedCardData {
  firstName: string;
  lastName: string;
  email: string;
  phoneNumber: string;
  organization: string;
  position: string;
  subCategory: string;
  website: string;
  completeAddress: string;
}