import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import * as ImageManipulator from "expo-image-manipulator";
import DocumentScanner from "react-native-document-scanner-plugin";
import React, { useCallback, useState } from "react";
import {
  ActivityIndicator,
  Alert,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
  SafeAreaView,
  StatusBar,
  Dimensions,
  Platform,
  PermissionsAndroid,
  Image,
} from "react-native";
import { useRouter } from "expo-router";
import { useFocusEffect } from "@react-navigation/native";
import { showError } from "@/components/Toast";
import { ExtractedCardData } from "../scan/types";
import CameraHead from "../scan/cameraHead";

const screenWidth = Dimensions.get("window").width;
const screenHeight = Dimensions.get("window").height;

export default function CardScan() {
  const [uri, setUri] = useState<string | null>(null);
  const [extractingText, setExtractingText] = useState(false);
  const [processingAI, setProcessingAI] = useState(false);
  const [base64, setBase64] = useState<string | null>(null);
  const router = useRouter();

  useFocusEffect(
    useCallback(() => {
      setUri(null);
      setExtractingText(false);
      setProcessingAI(false);
      setBase64(null);
      return () => {};
    }, [])
  );

  // Gemini API key
  const GEMINI_API_KEY = "AIzaSyD_mm8jcV_FI47HXSV-l6yAX-hZdWEmDyc";

  const scanDocument = async () => {
    try {
      setBase64(null);
      // Request camera permissions on Android if needed
      if (Platform.OS === "android") {
        const granted = await PermissionsAndroid.request(
          PermissionsAndroid.PERMISSIONS.CAMERA
        );
        if (granted !== PermissionsAndroid.RESULTS.GRANTED) {
          Alert.alert(
            "Permission Denied",
            "Camera permission is required to scan documents."
          );
          return;
        }
      }

      // Start the document scanner
      const { scannedImages, status } = await DocumentScanner.scanDocument({
        maxNumDocuments: 1,
        croppedImageQuality: 100,
        responseType: "imageFilePath",
      });

      // Check if scan was successful
      if (status === "cancel") {
        return;
      }

      // Get back an array with scanned image file paths
      if (scannedImages && scannedImages.length > 0) {
        const scannedImagePath = scannedImages[0];
        setUri(scannedImagePath);
        await extractTextFromImage(scannedImagePath);
      } else {
        Alert.alert("No Image", "No document was scanned. Please try again.");
      }
    } catch (error) {
      console.error("Document scanner error:", error);
      Alert.alert(
        "Scanner Error",
        "Failed to open document scanner. Please try again."
      );
    }
  };

  const extractTextFromImage = async (imageUri: string) => {
    setExtractingText(true);

    try {
      // Always generate base64 for the current image to avoid stale data.
      const manipulatedImage = await ImageManipulator.manipulateAsync(
        imageUri,
        [{ resize: { width: 1024 } }],
        {
          compress: 1,
          format: ImageManipulator.SaveFormat.JPEG,
          base64: true,
        }
      );
      const imageBase64 = manipulatedImage.base64 || null;
      setBase64(imageBase64);

      if (!imageBase64) {
        throw new Error("Failed to generate base64 image");
      }

      const textExtractionPrompt = `
        Please extract ALL visible text from this business card image.
        Return only the raw text as it appears on the card, preserving line breaks and formatting as much as possible.
        Do not interpret or structure the information - just return the exact text you can see.
      `;

      const textExtractionPayload = {
        contents: [
          {
            role: "user",
            parts: [
              { text: textExtractionPrompt },
              {
                inline_data: {
                  mime_type: "image/jpeg",
                  data: imageBase64,
                },
              },
            ],
          },
        ],
        generationConfig: {
          temperature: 0.1,
          maxOutputTokens: 1000,
        },
      };

      const textResponse = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${GEMINI_API_KEY}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(textExtractionPayload),
        }
      );

      if (!textResponse.ok) {
        const errorData = await textResponse.json();
        throw new Error(
          `Text extraction error: ${textResponse.status} - ${JSON.stringify(
            errorData
          )}`
        );
      }

      const textResult = await textResponse.json();

      if (!textResult.candidates?.[0]?.content?.parts?.[0]?.text) {
        throw new Error("No text found in image");
      }

      const extractedRawText =
        textResult.candidates[0].content.parts[0].text.trim();

      if (!extractedRawText) {
        throw new Error("No readable text detected in the image");
      }
      await processExtractedText(extractedRawText, imageBase64);
    } catch (error) {
      console.error("Gemini Text Recognition Error:", error);
      Alert.alert(
        "Text Recognition Error",
        "Failed to extract text from image. Please try again."
      );
    } finally {
      setExtractingText(false);
    }
  };

  const navigateToCreateCard = (
    parsedJson: ExtractedCardData,
    imageBase64: string | null
  ) => {
    if (parsedJson && imageBase64) {
      router.push({
        pathname: "/(main)/cards/CreateCards",
        params: {
          scannedData: JSON.stringify(parsedJson),
          manyImage: imageBase64,
        },
      });
    } else {
      Alert.alert(
        "No Data",
        "Please scan a business card first to extract data."
      );
      showError("Please scan a business card first to extract data.");
      router.push("/home");
    }
  };

  const processExtractedText = async (
    rawText: string,
    imageBase64: string
  ) => {
    setProcessingAI(true);

    const structurePrompt = `
      Analyze the following business card text and extract structured information.
      Return the information as a JSON object with the specified fields.
      If a piece of information is not found, use an empty string for its value.
      Be flexible with field matching - look for similar information even if wording is different.

      Fields to extract:
      - firstName: First name of the person
      - lastName: Last name of the person
      - email: Email address
      - phoneNumber: Phone number (any format)
      - organization: Company/organization name
      - position: Job title/position
      - subCategory: Department, division, or subcategory
      - website: Website URL
      - completeAddress: Full address including street, city, state, zip

      Business Card Text:
      "${rawText}"
    `;

    const structurePayload = {
      contents: [{ role: "user", parts: [{ text: structurePrompt }] }],
      generationConfig: {
        responseMimeType: "application/json",
        responseSchema: {
          type: "OBJECT",
          properties: {
            firstName: { type: "STRING", description: "First name" },
            lastName: { type: "STRING", description: "Last name" },
            email: { type: "STRING", description: "Email address" },
            phoneNumber: { type: "STRING", description: "Phone number" },
            organization: {
              type: "STRING",
              description: "Company/organization",
            },
            position: { type: "STRING", description: "Job title/position" },
            subCategory: {
              type: "STRING",
              description: "Department/division",
            },
            website: { type: "STRING", description: "Website URL" },
            completeAddress: {
              type: "STRING",
              description: "Complete address",
            },
          },
          propertyOrdering: [
            "firstName",
            "lastName",
            "email",
            "phoneNumber",
            "organization",
            "position",
            "subCategory",
            "website",
            "completeAddress",
          ],
        },
      },
    };

    try {
      const response = await fetch(
        `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${GEMINI_API_KEY}`,
        {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(structurePayload),
        }
      );

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(
          `Structure processing error: ${response.status} - ${JSON.stringify(
            errorData
          )}`
        );
      }

      const result = await response.json();

      if (result.candidates?.[0]?.content?.parts?.[0]?.text) {
        const jsonString = result.candidates[0].content.parts[0].text;
        try {
          const parsedJson = JSON.parse(jsonString);
          navigateToCreateCard(parsedJson, imageBase64);
        } catch (parseError) {
          console.error("Failed to parse structured JSON:", parseError);
          Alert.alert(
            "Processing Error",
            "Failed to structure extracted information"
          );
        }
      } else {
        throw new Error("No valid response from AI");
      }
    } catch (error) {
      console.error("Error structuring text with Gemini:", error);
      Alert.alert(
        "AI Processing Error",
        "Failed to structure text with AI. Please try again."
      );
    } finally {
      setProcessingAI(false);
    }
  };

  const retakePhoto = () => {
    setUri(null);
    setBase64(null);
    setExtractingText(false);
    setProcessingAI(false);
  };

  const renderPictureView = () => {
    return (
      <ScrollView style={styles.pictureScrollView}>
        <SafeAreaView style={styles.pictureContainer}>
          {uri && (
            <Image
              source={{ uri }}
              style={styles.previewImage}
              resizeMode="contain"
            />
          )}
          {(extractingText || processingAI) && (
            <View style={styles.loadingContainer}>
              <ActivityIndicator size="large" color="#16a34a" />
              <Text style={styles.loadingText}>
                {extractingText ? "Extracting text..." : "Processing with AI..."}
              </Text>
            </View>
          )}
          <View style={styles.buttonContainer}>
            <Pressable
              style={[styles.actionButton, styles.secondaryButton]}
              onPress={retakePhoto}
              disabled={extractingText || processingAI}
            >
              <Text style={styles.secondaryButtonText}>Retake Photo</Text>
            </Pressable>
          </View>
        </SafeAreaView>
      </ScrollView>
    );
  };

  const renderInitialView = () => {
    return (
      <View style={styles.initialContainer}>
        <CameraHead />
        <View style={styles.contentContainer}>
          <MaterialIcons name="document-scanner" size={100} color="#16a34a" />
          <Text style={styles.title}>Business Card Scanner</Text>
          <Text style={styles.description}>
            Scan business cards with automatic text recognition
          </Text>
          <Text style={styles.instructionText}>
            • Position the card in good lighting{"\n"}
            • Ensure all text is visible{"\n"}
            • Keep the card flat and steady
          </Text>
          <Pressable
            style={styles.scanButton}
            onPress={scanDocument}
          >
            <MaterialIcons name="camera-alt" size={24} color="white" />
            <Text style={styles.scanButtonText}>Start Scanning</Text>
          </Pressable>
        </View>
      </View>
    );
  };

  return (
    <View style={styles.container}>
      <StatusBar barStyle="light-content" />
      {uri ? renderPictureView() : renderInitialView()}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#000",
  },
  initialContainer: {
    flex: 1,
    backgroundColor: "#000",
  },
  contentContainer: {
    flex: 1,
    justifyContent: "center",
    alignItems: "center",
    padding: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: "bold",
    color: "white",
    marginTop: 24,
    marginBottom: 12,
    textAlign: "center",
  },
  description: {
    fontSize: 16,
    color: "#999",
    textAlign: "center",
    marginBottom: 32,
    lineHeight: 22,
  },
  instructionText: {
    fontSize: 14,
    color: "#ccc",
    textAlign: "left",
    marginBottom: 40,
    lineHeight: 24,
  },
  scanButton: {
    flexDirection: "row",
    alignItems: "center",
    backgroundColor: "#16a34a",
    paddingHorizontal: 32,
    paddingVertical: 16,
    borderRadius: 12,
    gap: 12,
    elevation: 4,
    shadowColor: "#16a34a",
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
  },
  scanButtonText: {
    color: "white",
    fontSize: 18,
    fontWeight: "600",
  },
  pictureScrollView: {
    flex: 1,
    backgroundColor: "#000000",
  },
  pictureContainer: {
    padding: 20,
    paddingTop: 60,
  },
  previewImage: {
    width: "100%",
    height: screenHeight * 0.5,
    borderRadius: 12,
    marginBottom: 20,
  },
  loadingContainer: {
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "rgba(0,0,0,0.8)",
    padding: 20,
    borderRadius: 12,
    marginBottom: 20,
  },
  loadingText: {
    fontSize: 16,
    fontWeight: "600",
    color: "#fff",
    marginTop: 10,
  },
  buttonContainer: {
    gap: 12,
    marginTop: 10,
  },
  actionButton: {
    padding: 16,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  secondaryButton: {
    backgroundColor: "transparent",
    borderWidth: 2,
    borderColor: "#16a34a",
  },
  secondaryButtonText: {
    color: "#16a34a",
    fontSize: 16,
    fontWeight: "600",
  },
});
