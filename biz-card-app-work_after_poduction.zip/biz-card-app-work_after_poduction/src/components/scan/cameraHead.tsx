import { AntDesign, EvilIcons } from "@expo/vector-icons";
import { useRouter } from "expo-router";
import React, { useEffect } from "react";
import { Dimensions } from "react-native";
import { View, Text, TouchableOpacity, StyleSheet } from "react-native";
import Animated, {
  Easing,
  useSharedValue,
  useAnimatedStyle,
  withTiming,
} from "react-native-reanimated";

const screenWidth = Dimensions.get("window").width;
const screenHeight = Dimensions.get("window").height;
const CameraHead = () => {
  const router = useRouter();
  const translateY = useSharedValue(-100);

  useEffect(() => {
    translateY.value = withTiming(0, {
      duration: 500,
      easing: Easing.out(Easing.ease),
    });
  }, [translateY]);

  const animatedStyle = useAnimatedStyle(() => {
    return {
      transform: [{ translateY: translateY.value }],
    };
  });

  return (
    <Animated.View style={[styles.banner, animatedStyle]}>
      <TouchableOpacity
        onPress={() => router.push("/(main)/home")}
        style={styles.closeButton}
      >
       <AntDesign name="close" size={24} color="black" />
      </TouchableOpacity>
      <View style={{ flex: 1, alignItems: "center" }}>
        <Text style={styles.text}>Auto-Detect with BizCard AI</Text>
      <Text style={styles.subtitle}>
        Smart scan. Zero typing. Just tap & capture
      </Text>
      </View>
      <View
        style={styles.closeButton}
      >
       <EvilIcons name="star" size={24} color="blue" />
      </View>
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  banner: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    backgroundColor: "#fff",
    padding: 10,
    borderRadius: 40,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 5,
    position: "absolute",
    top: screenHeight * 0.02,
    left: screenWidth * 0.02,
    right: screenWidth * 0.02,

  },
  closeButton: {
    backgroundColor: "#f0f0f0",
    padding: 10,
    borderRadius: 40,
  },
  text: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#000",
  },
  subtitle: {
    fontSize: 12,
    color: "#666",
  },
  starContainer: {
    backgroundColor: "#e0f7fa",
    borderRadius: 15,
    padding: 5,
  },
  starText: {
    fontSize: 14,
    color: "#00bcd4",
  },
});

export default CameraHead;
