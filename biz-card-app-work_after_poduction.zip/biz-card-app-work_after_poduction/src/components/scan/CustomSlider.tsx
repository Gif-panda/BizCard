// CustomSlider.tsx
import React from 'react';
import {
  View,
  PanResponder,
  StyleSheet,
  Dimensions,
  GestureResponderEvent,
  PanResponderGestureState,
} from 'react-native';

const { width: screenWidth } = Dimensions.get('window');

interface CustomSliderProps {
  value: number;
  minimumValue: number;
  maximumValue: number;
  step?: number;
  onValueChange: (value: number) => void;
  minimumTrackTintColor?: string;
  maximumTrackTintColor?: string;
  thumbTintColor?: string;
  style?: any;
}

const CustomSlider: React.FC<CustomSliderProps> = ({
  value,
  minimumValue,
  maximumValue,
  step = 0.1,
  onValueChange,
  minimumTrackTintColor = '#007AFF',
  maximumTrackTintColor = '#ccc',
  thumbTintColor = '#007AFF',
  style,
}) => {
  const sliderWidth = style?.width || screenWidth - 80;
  const range = maximumValue - minimumValue;

  const calculateValue = (positionX: number) => {
    const percentage = Math.max(0, Math.min(1, positionX / sliderWidth));
    let newValue = minimumValue + percentage * range;
    
    // Apply step if provided
    if (step > 0) {
      newValue = Math.round(newValue / step) * step;
    }
    
    return Math.max(minimumValue, Math.min(maximumValue, newValue));
  };

  const handleMove = (gestureState: PanResponderGestureState) => {
    const newValue = calculateValue(gestureState.moveX);
    onValueChange(newValue);
  };

  const panResponder = PanResponder.create({
    onStartShouldSetPanResponder: () => true,
    onMoveShouldSetPanResponder: () => true,
    onPanResponderMove: (_, gestureState) => {
      handleMove(gestureState);
    },
    onPanResponderRelease: (_, gestureState) => {
      handleMove(gestureState);
    },
  });

  const percentage = ((value - minimumValue) / range) * 100;

  return (
    <View style={[styles.container, { width: sliderWidth }, style]}>
      {/* Track */}
      <View style={styles.track}>
        <View 
          style={[
            styles.minimumTrack,
            { 
              width: `${percentage}%`,
              backgroundColor: minimumTrackTintColor,
            }
          ]} 
        />
        <View 
          style={[
            styles.maximumTrack,
            { 
              width: `${100 - percentage}%`,
              backgroundColor: maximumTrackTintColor,
            }
          ]} 
        />
      </View>
      
      {/* Thumb */}
      <View
        {...panResponder.panHandlers}
        style={[
          styles.thumb,
          {
            backgroundColor: thumbTintColor,
            left: `${percentage}%`,
            marginLeft: -10, // Half of thumb width
          }
        ]}
      />
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    height: 40,
    justifyContent: 'center',
  },
  track: {
    height: 4,
    borderRadius: 2,
    flexDirection: 'row',
    backgroundColor: 'transparent',
  },
  minimumTrack: {
    height: '100%',
    borderRadius: 2,
  },
  maximumTrack: {
    height: '100%',
    borderRadius: 2,
  },
  thumb: {
    position: 'absolute',
    width: 20,
    height: 20,
    borderRadius: 10,
    backgroundColor: '#007AFF',
    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
    elevation: 5,
  },
});

export default CustomSlider;