import React, { useRef } from "react";
import {
  View,
  Text,
  TouchableOpacity,
  ScrollView,
  StyleSheet,
  Alert,
  Linking,
  Platform,
} from "react-native";
import * as FileSystem from "expo-file-system";
import * as Sharing from "expo-sharing";
import { captureRef } from "react-native-view-shot";
import Share from "react-native-share";
import AsyncStorage from "@react-native-async-storage/async-storage";

import ShareTabs from "./shareTabs";
import { ScaleInView, SlideInView } from "../animations";
import SingleBizCard from "../globals/single-card/SingleBizCard";
import { getCopyright } from "@/utils/common";

interface ShareProps {
  cardDetails: any;
}

const V_CARD_DOWNLOADS_URI_KEY = "vcard_downloads_directory_uri";

const ShareComponent: React.FC<ShareProps> = ({ cardDetails }) => {
  const contactDetails = cardDetails?.ContactDetails || {};
  const cardLink =
    cardDetails?.cardDetails?.url ||
    "https://dev.support.bizz-card-app.com/welcome";
  const cardId = cardDetails?._id || cardDetails?.cardDetails?._id;
  const deepLink = cardId ? `myapp://home/single/${cardId}` : cardLink;
  const cardRef = useRef<View>(null);

  // --- Format social links as text
  const formatSocialLinksData = () => {
    if (
      !contactDetails.socialLinks ||
      contactDetails.socialLinks.length === 0
    ) {
      return "";
    }

    return contactDetails.socialLinks
      .map((link: any) => `${link.platform || "Social"}: ${link.url || ""}`)
      .join("\n");
  };

  // --- Build complete vCard string
  const buildVCard = (): string => {
    const firstName = contactDetails.firstName || "";
    const lastName = contactDetails.lastName || "";
    const fullName = `${firstName} ${lastName}`.trim();

    const socialLines: string[] = (contactDetails.socialLinks || [])
      .filter((link: any) => link.url)
      .map((link: any) => {
        const p = (link.platform || "").toLowerCase();
        const type =
          p.includes("linkedin") ? "linkedin" :
          p.includes("twitter") || p.includes("x-twitter") ? "twitter" :
          p.includes("facebook") ? "facebook" :
          p.includes("instagram") ? "instagram" :
          p.includes("youtube") ? "youtube" :
          p.includes("tiktok") ? "tiktok" :
          p.includes("github") ? "github" :
          p.includes("whatsapp") ? "whatsapp" :
          p.includes("telegram") ? "telegram" :
          p.includes("snapchat") ? "snapchat" :
          p.includes("pinterest") ? "pinterest" :
          p.includes("reddit") ? "reddit" :
          p.includes("discord") ? "discord" :
          "other";
        return `X-SOCIALPROFILE;TYPE=${type}:${link.url}`;
      });

    const lines = [
      "BEGIN:VCARD",
      "VERSION:3.0",
      `FN:${fullName || "Contact"}`,
      `N:${lastName};${firstName};;;`,
      contactDetails.organization ? `ORG:${contactDetails.organization}` : "",
      contactDetails.position    ? `TITLE:${contactDetails.position}` : "",
      contactDetails.phoneNumber ? `TEL;TYPE=CELL,VOICE:${contactDetails.phoneNumber}` : "",
      contactDetails.email       ? `EMAIL;TYPE=INTERNET,PREF:${contactDetails.email}` : "",
      contactDetails.website     ? `URL:${contactDetails.website}` : "",
      contactDetails.address     ? `ADR;TYPE=WORK:;;${contactDetails.address};;;;` : "",
      contactDetails.note        ? `NOTE:${contactDetails.note}` : "",
      cardLink                   ? `X-BIZCARD-URL:${cardLink}` : "",
      ...socialLines,
      `REV:${new Date().toISOString()}`,
      "END:VCARD",
    ].filter((l) => l !== "");

    return lines.join("\r\n");
  };

  const getVCardFileName = (): string => {
    const firstName = contactDetails.firstName || "";
    const lastName = contactDetails.lastName || "";
    const slug = `${firstName}_${lastName}`.replace(/\s+/g, "_") || "contact";
    return `${slug}_${Date.now()}.vcf`;
  };

  // --- Write vCard to app storage for sharing
  const writeVCardFile = async (
    fileName: string,
    vCardContent: string
  ): Promise<string> => {
    const baseDir = FileSystem.cacheDirectory || FileSystem.documentDirectory;
    if (!baseDir) throw new Error("No writable directory is available");

    const filename = `${baseDir}${fileName}`;
    await FileSystem.writeAsStringAsync(filename, vCardContent, {
      encoding: FileSystem.EncodingType.UTF8,
    });
    return filename;
  };

  // --- Save a copy to real Android Downloads (user-visible in Files app)
  const saveVCardToAndroidDownloads = async (
    fileName: string,
    vCardContent: string
  ): Promise<boolean> => {
    if (Platform.OS !== "android") return false;

    const { StorageAccessFramework } = FileSystem;
    const writeToSafDirectory = async (directoryUri: string) => {
      const safFileUri = await StorageAccessFramework.createFileAsync(
        directoryUri,
        fileName,
        "text/vcard"
      );
      await FileSystem.writeAsStringAsync(safFileUri, vCardContent, {
        encoding: FileSystem.EncodingType.UTF8,
      });
    };

    try {
      const savedDirectoryUri = await AsyncStorage.getItem(
        V_CARD_DOWNLOADS_URI_KEY
      );

      if (savedDirectoryUri) {
        try {
          await writeToSafDirectory(savedDirectoryUri);
          return true;
        } catch {
          await AsyncStorage.removeItem(V_CARD_DOWNLOADS_URI_KEY);
        }
      }

      const downloadsRootUri =
        StorageAccessFramework.getUriForDirectoryInRoot("Download");
      const permissions =
        await StorageAccessFramework.requestDirectoryPermissionsAsync(
          downloadsRootUri
        );

      if (!permissions.granted || !permissions.directoryUri) {
        return false;
      }

      await AsyncStorage.setItem(
        V_CARD_DOWNLOADS_URI_KEY,
        permissions.directoryUri
      );
      await writeToSafDirectory(permissions.directoryUri);
      return true;
    } catch (error) {
      console.error("Failed to save vCard to Downloads:", error);
      return false;
    }
  };

  // --- Capture card image
  const captureCardImage = async (): Promise<string | null> => {
    try {
      if (!cardRef.current) return null;
      const imageUri = await captureRef(cardRef, {
        format: "png",
        quality: 0.9,
      });
      const newPath = `${FileSystem.cacheDirectory}card_${Date.now()}.png`;
      await FileSystem.moveAsync({ from: imageUri, to: newPath });
      return newPath;
    } catch (error) {
      console.error("Image capture failed:", error);
      return null;
    }
  };

  // --- Download original card
  const downloadOriginalImage = async (): Promise<string | null> => {
    try {
      const url = contactDetails.originalCard;
      if (!url) return null;
      const localPath = `${
        FileSystem.cacheDirectory
      }original_${Date.now()}.png`;
      const result = await FileSystem.downloadAsync(url, localPath);
      return result.uri;
    } catch (error) {
      console.error("Download failed:", error);
      return null;
    }
  };

  // --- Share Button: image + link
  const handleMainShare = async () => {
    try {
      const screenshot = await captureCardImage();
      if (!screenshot) {
        Alert.alert("Error", "Card capture failed");
        return;
      }

      await Share.open({
        title: "Share Card",
        message: `Check out this card: ${deepLink}`,
        urls: [screenshot],
      });
    } catch (error) {
      console.error("Main Share failed:", error);
    }
  };

  // --- Share Original card with Social Links
  const handleShareOriginalWithLinks = async () => {
    try {
      const originalImage = await downloadOriginalImage();
      if (!originalImage) {
        Alert.alert("Error", "No original card found");
        return;
      }
      const message = formatSocialLinksData();

      await Share.open({
        title: "Original Card with Social Links",
        message,
        urls: [originalImage],
      });
    } catch (error) {
      console.error("Share Original with Links failed:", error);
    }
  };

  // --- Share Simple Original Card (image only)
  const handleShareOriginalSimple = async () => {
    try {
      const originalImage = await downloadOriginalImage();
      if (!originalImage) {
        Alert.alert("Error", "No original card found");
        return;
      }
      await Share.open({
        title: "Original Card",
        urls: [originalImage],
      });
    } catch (error) {
      console.error("Share Simple Original failed:", error);
    }
  };

  // --- Share Virtual Card (links only)
  const handleShareVirtualCard = async () => {
    try {
      const message = `Virtual Card:\n${deepLink}\n\n${formatSocialLinksData()}`;
      await Share.open({
        title: "Virtual Card",
        message,
      });
    } catch (error) {
      console.error("Share Virtual Card failed:", error);
    }
  };

  // --- Share + Download vCard
  const handleShareAsVCard = async () => {
    try {
      const fileName = getVCardFileName();
      const vCardContent = buildVCard();
      const path = await writeVCardFile(fileName, vCardContent);
      const downloadedToPublicFolder = await saveVCardToAndroidDownloads(
        fileName,
        vCardContent
      );

      const canShare = await Sharing.isAvailableAsync();
      if (canShare) {
        await Sharing.shareAsync(path, {
          mimeType: "text/vcard",
          dialogTitle: "Share / Save vCard",
          UTI: "public.vcard",
        });
      } else {
        // Fallback for rare cases where expo-sharing is unavailable
        await Share.open({
          title: "Share Contact",
          url: path,
          type: "text/vcard",
        });
      }

      if (Platform.OS === "android" && !downloadedToPublicFolder) {
        Alert.alert(
          "vCard Shared",
          "To save the .vcf in phone Downloads, allow folder access and select the Downloads folder when prompted."
        );
      }
    } catch (error) {
      console.error("vCard error:", error);
      Alert.alert("Error", "Failed to share vCard");
    }
  };

  // --- Social Media Share: virtual card + URL
  const handleSocialShare = async (platform: string) => {
    try {
      const message = `Virtual Card:\n${deepLink}\n\n${formatSocialLinksData()}`;

      switch (platform) {
        case "whatsapp":
          await Share.shareSingle({
            message,
            social: Share.Social.WHATSAPP,
          });
          break;

        case "linkedin":
          await Linking.openURL(
            `https://www.linkedin.com/sharing/share-offsite/?url=${encodeURIComponent(
              deepLink
            )}&summary=${encodeURIComponent(formatSocialLinksData())}`
          );
          break;

        case "twitter":
          await Share.shareSingle({
            message,
            social: Share.Social.TWITTER,
          });
          break;

        case "facebook":
          await Share.shareSingle({
            message,
            social: Share.Social.FACEBOOK,
          });
          break;
      }
    } catch (error) {
      console.error(`${platform} Share Error:`, error);
    }
  };

  // --- Share Everything: both cards, socials, and URL
  const handleShareEverything = async () => {
    try {
      const screenshot = await captureCardImage();
      const originalImage = await downloadOriginalImage();
      const files: string[] = [];
      if (screenshot) files.push(screenshot);
      if (originalImage) files.push(originalImage);

      if (files.length === 0) {
        Alert.alert("Error", "No card images available to share");
        return;
      }

      // Prepare virtual card message
      const message = `Virtual Card Links:\n${deepLink}\n\nSocial Links:\n${formatSocialLinksData()}`;

      await Share.open({
        title: "Share Everything",
        message,
        urls: files, // includes both original and screenshot
      });
    } catch (error) {
      console.error("Share Everything failed:", error);
      Alert.alert("Error", "Failed to share everything");
    }
  };

  // --- Options
  const basicOptions = [
    {
      id: "shareOriginalWithLinks",
      label: "Share Original Card + Social Links",
      icon: "share-social-outline",
      onPress: handleShareOriginalWithLinks,
    },
    {
      id: "shareOriginalSimple",
      label: "Share Original Card (Image Only)",
      icon: "image-outline",
      onPress: handleShareOriginalSimple,
    },
    {
      id: "shareVirtualCard",
      label: "Share Virtual Card (Links Only)",
      icon: "link-outline",
      onPress: handleShareVirtualCard,
    },
    {
      id: "shareVcard",
      label: "Share as vCard",
      icon: "person-circle-outline",
      onPress: handleShareAsVCard,
    },
    {
      id: "shareAll",
      label: "Share All (Card + Socials + URL)",
      icon: "globe-outline",
      onPress: handleShareEverything,
    },
  ];

  const socialMediaOptions = [
    {
      id: "whatsapp",
      label: "WhatsApp",
      icon: "logo-whatsapp",
      onPress: () => handleSocialShare("whatsapp"),
    },
    {
      id: "linkedin",
      label: "LinkedIn",
      icon: "logo-linkedin",
      onPress: () => handleSocialShare("linkedin"),
    },
    {
      id: "twitter",
      label: "X (Twitter)",
      icon: "logo-twitter",
      onPress: () => handleSocialShare("twitter"),
    },
    {
      id: "facebook",
      label: "Facebook",
      icon: "logo-facebook",
      onPress: () => handleSocialShare("facebook"),
    },
  ];

  return (
    <ScrollView style={styles.container}>
      {/* Card Preview */}
      <View style={styles.cardPreview} ref={cardRef} collapsable={false}>
        <SingleBizCard cardDetails={cardDetails} />
      </View>

      {/* Main Share */}
      <View style={styles.shareContainer}>
        <ScaleInView>
          <TouchableOpacity style={styles.shareBtn} onPress={handleMainShare}>
            <Text style={styles.shareBtnText}>Share Card</Text>
          </TouchableOpacity>
        </ScaleInView>
      </View>

      {/* Options */}
      <SlideInView>
        <View style={styles.optionsContainer}>
          <Text style={styles.sectionTitle}>Basic Options</Text>
          <ShareTabs options={basicOptions} />
          <Text style={styles.sectionTitle}>Social Media</Text>
          <ShareTabs options={socialMediaOptions} />
        </View>
      </SlideInView>

      {/* Footer */}
      <Text style={styles.footer}>{getCopyright()}</Text>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#0E0E0E",
    padding: 16,
  },
  cardPreview: {
    width: "100%",
    marginBottom: 20,
  },
  shareContainer: {
    alignItems: "center",
    paddingVertical: 8,
  },
  shareBtn: {
    width: "70%",
    backgroundColor: "white",
    paddingHorizontal: 40,
    paddingVertical: 12,
    borderRadius: 25,
    elevation: 3,
    alignItems: "center",
  },
  shareBtnText: {
    color: "black",
    fontWeight: "600",
    fontSize: 16,
  },
  optionsContainer: {
    marginVertical: 10,
  },
  sectionTitle: {
    color: "#fff",
    fontSize: 18,
    fontWeight: "600",
    marginBottom: 10,
    marginTop: 20,
  },
  footer: {
    color: "#666",
    fontSize: 12,
    textAlign: "center",
    paddingVertical: 20,
  },
});

export default ShareComponent;
