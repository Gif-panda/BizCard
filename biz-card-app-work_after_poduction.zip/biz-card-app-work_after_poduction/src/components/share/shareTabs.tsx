import { colors, spacingX, spacingY } from "@/constants/theme";
import { Ionicons } from "@expo/vector-icons";
import React from "react";
import {
  View,
  Text,
  TouchableOpacity,
  StyleSheet,
  FlatList,
  ViewStyle,
} from "react-native";

interface Option {
  id: string;
  label: string;
  icon: any;
  onPress: () => void;
}

interface ShareTabsProps {
  options: Option[];
  containerStyle?: ViewStyle;
}

const ShareTabs: React.FC<ShareTabsProps> = ({ options, containerStyle }) => {
  return (
    <View style={[styles.container, containerStyle]}>
      <FlatList
        scrollEnabled={false}
        data={options}
        keyExtractor={(item) => item.id}
        renderItem={({ item, index }) => (
          <TouchableOpacity
            onPress={item.onPress}
            style={[
              styles.optionButton,
              index === 0 && styles.firstItem,
              index === options.length - 1 && styles.lastItem,
            ]}
          >
            <View style={styles.leftSection}>
              <Ionicons
                name={item.icon as any}
                size={20}
                color="#fff"
                style={styles.icon}
              />
              <Text style={styles.label}>{item.label}</Text>
            </View>
          </TouchableOpacity>
        )}
        ItemSeparatorComponent={() => <View style={styles.separator} />}
      />
    </View>
  );
};

export default ShareTabs;

const styles = StyleSheet.create({
  container: {
    paddingBottom: spacingY._20,
  },
  optionButton: {
    flexDirection: "row",
    backgroundColor: '#1a1a1a',
    alignItems: "center",
    justifyContent: "space-between",
    paddingVertical: spacingY._15,
    paddingHorizontal: spacingX._20,
  },
  leftSection: {
    flexDirection: "row",
    alignItems: "center",
  },
  icon: {
    width: 20,
    height: 20,
    marginRight: 16,
  },

  label: {
    color: "#FFFFFF",
    fontSize: 14,
  },
  separator: {
    height: 5,
    backgroundColor: "#0E0E0E",
  },
  firstItem: {
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
  },
  lastItem: {
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
  },
});
