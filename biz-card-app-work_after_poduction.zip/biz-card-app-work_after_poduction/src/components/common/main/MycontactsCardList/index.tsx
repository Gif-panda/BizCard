import { spacingY } from "@/constants/theme";
import { useRouter } from "expo-router";
import { TouchableRipple } from "react-native-paper";
import React, { useCallback, useRef, useState } from "react";
import {
  View,
  Text,
  Image,
  FlatList,
  StyleSheet,
  Dimensions,
  RefreshControl,
} from "react-native";
import ViewShot from "react-native-view-shot";
import Loading from "@/components/Loading";
import { SlideInView } from "@/src/components/animations";
import SingleBizCard from "@/src/components/globals/single-card/SingleBizCard";

const { width } = Dimensions.get("window");
const CARD_HEIGHT = 170;
const EXPANDED_CARD_HEIGHT = 180;

const MycontactsCardList = ({ cardData, loading, category, refetch }: any) => {
  const router = useRouter();
  console.log("cardData", JSON.stringify(cardData, null,2));
  const [refreshing, setRefreshing] = useState(false);
  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    try {
      await refetch?.();
    } catch (error) {
    } finally {
      setRefreshing(false);
    }
  }, [refetch]);
  const ProfileCard = ({ singleCardData, isExpanded }: any) => {

    return (
      <TouchableRipple
        style={[styles.cardContainer, isExpanded && styles.expandedCard]}
        onPress={() => {
          router.push(`/home/single/${singleCardData?._id}`);
        }}
      >
        <View style={{ borderRadius: 20, overflow: "hidden", width: "100%", height: "100%" }}>
          {singleCardData?.ContactDetails?.originalCard ? (
            <Image
              source={{ uri: singleCardData?.ContactDetails?.originalCard }}
              style={{
                width: "100%",
                height: 200,
                objectFit: "fill",
              }}
              resizeMode="contain"
            />
          ) : (
            <SingleBizCard cardDetails={singleCardData} isProUser={true} />
          )}
        </View>
      </TouchableRipple>
    );
  };

  return (
    <View style={styles.container}>
      {loading ? (
        <Loading />
      ) : cardData?.length === 0 || !cardData ? (
        <Text
          style={{
            color: "#fff",
            fontSize: 12,
            textAlign: "center",
            marginTop: 20,
            flexDirection: "row",
            flex:1,
            fontStyle: "italic",
            justifyContent: "center",
            alignItems: "center",
            height: "100%",
          }}
        >
          {`No ${category} Contacts yet.\nCreate your first Contact and start sharing cards instantly!`}
        </Text>
      ) : (
        <FlatList
          data={cardData}
          keyExtractor={(item) => item._id}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.listContent}
          renderItem={({ item, index }) => (
            <SlideInView duration={250 * (index + 1)}>
              <ProfileCard
                isExpanded={index === cardData.length - 1}
                singleCardData={item}
              />
            </SlideInView>
          )}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={onRefresh}
              colors={["#00FF99"]}
              tintColor="#00FF99"
              progressBackgroundColor={"#222"}
            />
          }
        />
      )}
    </View>
  );
};

export default MycontactsCardList;

const styles = StyleSheet.create({
  bottomSheetheading: {
    color: "white",
    fontSize: 16,
    fontWeight: "500",
    marginBottom: 12,
  },

  containerBottomSheet: {
    flex: 1,
    paddingHorizontal: 20,
    backgroundColor: "#000",
  },

  container: {
    flex: 15,
    backgroundColor: "#0E0E0E",
    paddingHorizontal: 15,
  },
  editIcon: {
    position: "absolute",
    top: 10,
    left: 10,
    zIndex: 10,
    backgroundColor: "transparent",
    borderRadius: 20,
    padding: 5,
    elevation: 5,
    shadowColor: "#fff",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
  },

  exportIcon: {
    position: "absolute",
    top: 10,
    left: 40,
    zIndex: 10,
    backgroundColor: "transparent",
    borderRadius: 20,
    padding: 5,
    elevation: 5,
    shadowColor: "#fff",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
  },
  deleteIcon: {
    position: "absolute",
    top: 6,
    right: 6,
    zIndex: 100,
    backgroundColor: "#FF4444",
    opacity: 0.7,
    height: 30,
    width: 30,
    borderRadius: 18,
    justifyContent: "center",
    alignItems: "center",
    elevation: 5,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
  },
  shareIcon: {
    position: "absolute",
    top: 8,
    right: 20,
    zIndex: 10,
    backgroundColor: "transparent",
    borderRadius: 20,
    padding: 5,
    elevation: 5,
    shadowColor: "#fff",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
  },

  iconRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  icon: {
    width: 20,
    height: 20,
    marginRight: 8,
  },
  profileSection: {
    position: "absolute",
    padding: 15,
    justifyContent: "space-between",
    width: "100%",
    gap: 10,
    flexDirection: "row",
    alignItems: "center",
  },
  profileSectionModern: {
    position: "absolute",
    paddingTop: 60,
    paddingHorizontal: 15,
    gap: 10,
    flexDirection: "row",
    alignItems: "center",
  },
  profileSectionSleek: {
    position: "absolute",
    paddingTop: 25,
    gap: 10,
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    width: "100%",
  },
  profileImage: {
    width: 50,
    height: 50,
    borderRadius: 30,
  },
  listContent: {
    paddingBottom: 40,
    alignItems: "center",
    paddingVertical: 10,
  },
  cardContainer: {
    width: width - 34,
    height: CARD_HEIGHT,
    marginBottom: -100,
    borderRadius: 20,
    overflow: "hidden",
    backgroundColor: "white",
    elevation: 15,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 20 },
    shadowOpacity: 0.9,
    shadowRadius: 15,
  },
  expandedCard: {
    height: EXPANDED_CARD_HEIGHT,
    marginBottom: 0,
  },
  cardBackground: {
    width: "100%",
    height: "100%",
    borderRadius: 30,
  },

  nameText: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#fff",
  },
  detailText: {
    fontSize: 12,
    color: "#fff",
    marginTop: 4,
  },
  nonClassicDetailSection: {
    position: "absolute",
    paddingTop: 120,
    paddingHorizontal: 10,
    gap: 10,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    width: "100%",
  },
  contactsistHeader: {
    paddingBottom: spacingY._10,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  name: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 16,
  },

  detailBottom: {
    fontSize: 12,
    marginTop: 4,
  },
  detailSection: {
    position: "absolute",
    paddingTop: 120,
    paddingHorizontal: 10,
    gap: 10,
    flexDirection: "row",
    alignItems: "center",
    alignContent: "center",
    justifyContent: "space-between",
    width: "100%",
  },
});
