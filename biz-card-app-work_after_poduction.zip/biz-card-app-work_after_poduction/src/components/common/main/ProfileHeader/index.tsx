import { spacingX } from "@/constants/theme";
import { useCardDetails } from "@/store/selectors/card/card";
import { useSubscriptionDetails } from "@/store/selectors/subscription/subscription";
import { useRouter } from "expo-router";
import React from "react";
import { View, Text, Image, TouchableOpacity, StyleSheet } from "react-native";
import { useSelector } from "react-redux";
import { FontAwesome6 } from "@expo/vector-icons";

const ProfileHeader = () => {
  const { userData } = useSelector(useCardDetails);
  const { isBought } = useSelector(useSubscriptionDetails);
  const isCouponVerified = Boolean(userData?.couponVerfied);
  const isProUser = isBought || isCouponVerified;
  const accountTypeLabel = isProUser ? "Pro Account" : "Free Account";
  const diamondColor = isProUser ? "#F2C94C" : "#7A7A7A";
  const diamondOpacity = isProUser ? 1 : 0.45;

  const router = useRouter();
  return (
    <View style={styles.wrapper}>
      <View style={styles.info}>
        <TouchableOpacity
          style={styles.optionOuters}
          onPress={() => {
            router.push("/(main)/settings");
          }}
        >
          <View
            // source={require("@/assets/main/mock-user.png")}
            style={styles.avatar}
          >
            <Text style={{color: 'white'}}>{userData?.name?.substring(0, 1)}</Text>
          </View>
        </TouchableOpacity>
        <View>
          <Text style={styles.name}>{userData?.name}</Text>
          <Text style={styles.subtext}>{accountTypeLabel}</Text>

          {/* <TouchableOpacity style={styles.freeAccountOptions}>
                        <Text style={styles.subtext}>Free Account</Text>

                        <Image source={require('@/assets/main/down-icon.png')} style={styles.downArrow} />

                    </TouchableOpacity> */}
        </View>
      </View>

      <View style={styles.options}>
        <TouchableOpacity
          style={styles.optionOuters}
          onPress={() => {
            router.push("/(main)/scan");
          }}
        >
          <Image
            source={require("@/assets/main/scan-icon.png")}
            style={styles.scanner}
          />
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.optionOuters}
          onPress={() => {
            router.push("/(main)/settings/subscription");
          }}
        >
          <FontAwesome6
            name="gem"
            size={16}
            color={diamondColor}
            style={{ opacity: diamondOpacity }}
          />
        </TouchableOpacity>
      </View>
    </View>
  );
};

export default ProfileHeader;

const styles = StyleSheet.create({
  wrapper: {
    flexDirection: "row",
    justifyContent: "space-between",
    paddingHorizontal: spacingX._12,
    paddingVertical: 10,
    alignItems: "center",
  },
  info: {
    flexDirection: "row",
    alignItems: "center",
    gap: 10,
  },
  optionOuters: {
    width: 40,
    height: 40,
    justifyContent: "center",
    alignItems: "center",
    backgroundColor: "#1A1B1D",
    borderWidth: 1,
    borderColor: "#3B3839",
    padding: 8,
    borderRadius: 20,
  },
  freeAccountOptions: {
    flexDirection: "row",
    alignItems: "flex-start",
    gap: 5,
  },
  options: {
    flexDirection: "row",
    alignItems: "center",
    gap: 5,
  },
  avatar: {
    width: 25,
    height: 25,
    borderRadius: 20,
    backgroundColor: "#3B3839",
    textAlign: "center",
    alignItems: "center",
    justifyContent: "center",
    fontWeight: "bold",
    color: "#fff",
  },
  downArrow: {
    width: 10,
    height: 10,
    tintColor: "#fff",
  },

  scanner: {
    width: 17,
    height: 17,
    // borderRadius: 20,
  },

  name: {
    color: "#fff",
    fontWeight: "bold",
  },
  subtext: {
    color: "#888",
    fontSize: 12,
  },
  settingsIcon: {
    fontSize: 18,
    color: "#fff",
  },
});
