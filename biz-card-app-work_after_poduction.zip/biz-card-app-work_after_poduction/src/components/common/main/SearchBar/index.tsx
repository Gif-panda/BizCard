import { colors, spacingX } from '@/constants/theme';
import React, { useState } from 'react';
import { View, TextInput, StyleSheet, Image, TouchableOpacity } from 'react-native';

const SearchBar = ({ setModalVisible, name, setName }: any) => {


    return (
        <View style={styles.wrapper}>
            <View style={styles.inputContainer}>
                <Image
                    source={require('@/assets/main/search-icon.png')}
                    style={styles.iconLeft}
                />
                <TextInput
                    placeholder="Search by first and last name"
                    placeholderTextColor="#888"
                    style={styles.input}
                    value={name}
                    onChangeText={(text) => {
                        setName(text);
                    }}

                />

                <TouchableOpacity onPress={() => setModalVisible(true)}  >
                    <Image
                        source={require('@/assets/main/filter-icon.png')}
                        style={styles.iconRight}
                    />
                </TouchableOpacity>

            </View>
        </View>
    );
};

export default SearchBar;

const styles = StyleSheet.create({
    wrapper: {
        marginHorizontal: spacingX._12,
        marginVertical: 8,
    },
    inputContainer: {
        backgroundColor: '#1A1B1D',
        borderRadius: 24,
        flexDirection: 'row',
        alignItems: 'center',
        paddingHorizontal: 12,
        paddingVertical: 5,
        borderWidth: 1,
        borderColor: '#3B3839',
    },
    input: {
        flex: 1,
        color: '#fff',
        paddingHorizontal: 8,
    },
    iconLeft: {
        width: 20,
        height: 20,
        tintColor: colors.white,
        marginRight: 8,
    },
    iconRight: {
        width: 20,
        height: 20,
        tintColor: colors.white,
        marginLeft: 8,
    },
});
