// AiOrganization.tsx
import React, { useState } from "react";
import {
  View,
  Text,
  StyleSheet,
  ActivityIndicator,
  TouchableOpacity,
  FlatList,
  Modal,
  TextInput,
} from "react-native";
import axios from "axios";
import { colors } from "@/constants/theme";
import SingleButton from "@/src/components/globals/single-card/SingleButton";
import { searchLinkedIn } from "@/src/services/linkedinSearch";

type AiOrganizationProps = {
  name: string;
  onDataFetched: (data: { dataFromAi: string }) => void;
};

const AiOrganization: React.FC<AiOrganizationProps> = ({
  name,
  onDataFetched,
}) => {
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<any[]>([]);
  const [modalVisible, setModalVisible] = useState(false);
  const [selectedData, setSelectedData] = useState("");

  const SERP_API_KEY = process.env.EXPO_PUBLIC_SERP_API_KEY || "57d06b8a5281108861d79d0c410fae383a13e48ef71aee9443fae1a9822adc12";
  const GEMINI_API_KEY = process.env.EXPO_PUBLIC_GEMINI_API_KEY || "AIzaSyD_mm8jcV_FI47HXSV-l6yAX-hZdWEmDyc";

  const fetchOrganizationData = async () => {
    if (!SERP_API_KEY || !GEMINI_API_KEY) {
      return;
    }

    setLoading(true);
    setResults([]);
    setModalVisible(true);

    try {
      // Step 1: LinkedIn Search via SerpAPI
      let linkedInResults: any[] = [];
      try {
        linkedInResults = await searchLinkedIn(name, SERP_API_KEY);
      } catch (serpErr: any) {
        const status = serpErr?.response?.status;
        const errorMsg = serpErr?.response?.data?.error || serpErr.message;
        console.log("SerpAPI Error:", {
          status,
          statusText: serpErr?.response?.statusText,
          data: serpErr?.response?.data,
          message: serpErr?.message,
        });
        const errorDisplay = `SerpAPI Error (${status}): ${errorMsg}`;
        setResults([{ name: "Error", summary: errorDisplay, location: null, source_link: "", platform: "Error" }]);
        setLoading(false);
        return;
      }

      if (linkedInResults.length === 0) {
        setLoading(false);
        return;
      }

      // Step 2: Gemini formatting (optional enhancement)
      try {
        const geminiRes = await axios.post(
          "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent",
          {
            contents: [
              {
                parts: [
                  {
                    text: `Enhance and format the following LinkedIn profiles data. Improve summaries if needed but keep all fields accurate. Return as JSON array.

Data:
${JSON.stringify(linkedInResults, null, 2)}`,
                  },
                ],
              },
            ],
          },
          {
            headers: {
              "Content-Type": "application/json",
              "x-goog-api-key": GEMINI_API_KEY,
            },
          }
        );

        const textResponse =
          geminiRes.data.candidates?.[0]?.content?.parts?.[0]?.text || "[]";

        let parsedJson: any[] = [];
        try {
          const cleaned = textResponse
            .replace(/```json/gi, "")
            .replace(/```/g, "")
            .trim();
          parsedJson = JSON.parse(cleaned);
        } catch {
          parsedJson = linkedInResults;
        }

        setResults(Array.isArray(parsedJson) ? parsedJson : linkedInResults);
      } catch (geminiErr: any) {
        console.error("Gemini error:", geminiErr.message);
        setResults(linkedInResults);
      }
  } catch (err: any) {
    console.error("Unexpected error:", err);
  } finally {
    setLoading(false);
  }
};

  const handleSelect = (item: any) => {
    const paragraph = `${item.name}\n${item.summary}\n${
      item.location ? item.location + "\n" : ""
    }${item.source_link}\n(${item.platform})`;
    setSelectedData(paragraph);
    onDataFetched({ dataFromAi: paragraph });
    setModalVisible(false);
  };

  return (
    <View style={styles.container}>
      {/* Button */}
      <SingleButton
        loading={loading}
        disabled={loading}
        onPress={fetchOrganizationData}
        title="Get Data with AI"
      />

      {/* Selected data */}
      {/* {selectedData ? (
        <TextInput
          style={styles.input}
          value={selectedData}
          editable={false}
          multiline
        />
      ) : null} */}

      {/* Modal */}
      <Modal
        visible={modalVisible}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalOverlay}>
          <View style={styles.modalContainer}>
            <Text style={styles.modalTitle}>AI Search Results</Text>

            {loading && (
              <ActivityIndicator size="large" color={colors.primary} />
            )}


            <FlatList
              data={results}
              keyExtractor={(item, index) => index.toString()}
              renderItem={({ item }) => (
                <TouchableOpacity
                  style={styles.card}
                  onPress={() => handleSelect(item)}
                >
                  <Text style={styles.name}>{item.name}</Text>
                  <Text style={styles.summary}>{item.summary}</Text>
                  {item.location && (
                    <Text style={styles.location}>{item.location}</Text>
                  )}
                  <Text style={styles.link}>{item.source_link}</Text>
                  <Text style={styles.platform}>{item.platform}</Text>
                </TouchableOpacity>
              )}
              ListEmptyComponent={
                !loading ? (
                  <Text style={styles.empty}>No results yet</Text>
                ) : null
              }
            />

            <TouchableOpacity
              style={styles.closeBtn}
              onPress={() => setModalVisible(false)}
            >
              <Text style={styles.closeBtnText}>Close</Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginBottom: 20,
    flex: 1,
  },
  input: {
    borderWidth: 1,
    borderColor: "#444",
    borderRadius: 8,
    padding: 10,
    marginTop: 10,
    color: "#fff",
    backgroundColor: "#1E1E1E",
    minHeight: 80,
  },
  modalOverlay: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.6)",
    justifyContent: "center",
    padding: 20,
  },
  modalContainer: {
    backgroundColor: "#1E1E1E",
    borderRadius: 12,
    padding: 16,
    flex: 1,
  },
  modalTitle: {
    fontSize: 18,
    fontWeight: "bold",
    marginBottom: 12,
    color: "#fff",
    textAlign: "center",
  },
  card: {
    backgroundColor: "#2A2A2A",
    padding: 12,
    marginVertical: 6,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: "#333",
  },
  name: {
    fontWeight: "bold",
    fontSize: 16,
    color: "#fff",
  },
  summary: {
    fontSize: 14,
    color: "#ccc",
    marginVertical: 4,
  },
  location: {
    fontSize: 13,
    color: "#aaa",
    marginBottom: 4,
  },
  link: {
    fontSize: 13,
    color: "#4EA8DE",
  },
  platform: {
    fontSize: 12,
    color: "#888",
    marginTop: 4,
  },
  error: {
    color: "#ea4335",
    textAlign: "center",
    marginVertical: 10,
    fontSize: 16,
  },
  empty: {
    textAlign: "center",
    marginTop: 20,
    fontSize: 14,
    color: "#aaa",
  },
  closeBtn: {
    marginTop: 12,
    backgroundColor: "#333",
    padding: 12,
    borderRadius: 8,
    alignItems: "center",
  },
  closeBtnText: {
    color: "#fff",
    fontSize: 16,
  },
});

export default AiOrganization;
