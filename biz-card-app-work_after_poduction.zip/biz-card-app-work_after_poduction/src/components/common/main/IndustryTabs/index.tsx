import { spacingX } from '@/constants/theme';
import ContactTabItem from '@/src/components/globals/ContactTabItem';
import { filterTabs, industryFilterTabs } from '@/src/constants/tabs';
import React, { useState } from 'react';
import { ScrollView, StyleSheet } from 'react-native';



const IndustryTabs = ({
    industry,
    setIndustry,
}: any) => {

    return (
        <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.scrollContainer}
        >
            {industryFilterTabs.map((tab) => (
                <ContactTabItem
                    isIcon={false}
                    label={tab.label}
                    icon={tab.icon}
                    isActive={industry
                        === tab.value}
                    onPress={() => setIndustry(tab.value)}
                />
            ))}
        </ScrollView>
    );
};

export default IndustryTabs;

const styles = StyleSheet.create({
    scrollContainer: {
        paddingVertical: 5,
        paddingHorizontal: spacingX._12,
        backgroundColor: '#0E0E0E',
    },
});
