import { spacingX, spacingY } from "@/constants/theme";
import CircleButton from "@/src/components/globals/CircleButton";
import { useRouter } from "expo-router";
import { TouchableRipple } from "react-native-paper";
import React, { useCallback, useMemo, useRef, useState } from "react";
import {
  View,
  Text,
  Image,
  FlatList,
  StyleSheet,
  TouchableOpacity,
  Dimensions,
  RefreshControl,
} from "react-native";
import AntDesign from "@expo/vector-icons/AntDesign";
import * as FileSystem from "expo-file-system";
import XLSX from "xlsx";
import * as Sharing from "expo-sharing";
import ViewShot from "react-native-view-shot";
import * as Linking from "expo-linking";
import Loading from "@/components/Loading";
import { SlideInView } from "@/src/components/animations";
import SingleBizCard from "@/src/components/globals/single-card/SingleBizCard";

const { width } = Dimensions.get("window");
const CARD_HEIGHT = 170;
const EXPANDED_CARD_HEIGHT = 180;

const CardList = ({ cardData, loading, category, refetch }: any) => {
  const router = useRouter();
  const [selectedCardData, setSelectedCardData] = useState({});
  console.log("cardData", JSON.stringify(cardData, null,2));

  const bottomSheetRef: any = useRef(null);
  const snapPoints = useMemo(() => ["25%", "40%"], []);
  const handleOpen = () => {
    bottomSheetRef.current?.expand();
  };

  const exportToExcel = async (cardData: any[]) => {
    try {
      const formattedData = cardData.map((item) => ({
        FirstName: item.ContactDetails.firstName,
        LastName: item.ContactDetails.lastName,
        Email: item.ContactDetails.email,
        PhoneNumber: item.ContactDetails.phoneNumber,
        Organization: item.ContactDetails.organization,
        Position: item.ContactDetails.position,
        Website: item.ContactDetails.website,
        Note: item.ContactDetails.note,
        Address: item.ContactDetails.address,
        Category: item.ContactDetails.category,
        SubCategory: item.ContactDetails.subCategory,
        CreatedAt: item.createdAt,
      }));

      const worksheet = XLSX.utils.json_to_sheet(formattedData);

      const workbook = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(workbook, worksheet, "Cards");

      const excelBinary = XLSX.write(workbook, {
        type: "base64",
        bookType: "xlsx",
      });

      const fileUri = FileSystem.documentDirectory + "card_list.xlsx";
      await FileSystem.writeAsStringAsync(fileUri, excelBinary, {
        encoding: FileSystem.EncodingType.Base64,
      });

      await Sharing.shareAsync(fileUri, {
        mimeType:
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        dialogTitle: "Exported Card List",
      });
    } catch (error) {
      console.error("❌ Export to Excel failed:", error);
    }
  };

  const exportCardImage = async (imageUri: string) => {
    try {
      if (!imageUri) {
        console.warn("No image URI to export");
        return;
      }
      const fileName = `exported-card-${Date.now()}.jpg`;
      const newFileUri = FileSystem.documentDirectory + fileName;

      await FileSystem.copyAsync({
        from: imageUri,
        to: newFileUri,
      });

      await Sharing.shareAsync(newFileUri, {
        mimeType: "image/jpeg",
        dialogTitle: "Exported Card Image",
      });
    } catch (error) {
      console.error("❌ Export image failed:", error);
    }
  };

  const shareToWhatsApp = async () => {
    const message = `Check this out: https://dev.support.marketaspex.com/welcome`;
    const url = `whatsapp://send?text=${encodeURIComponent(message)}`;
    const supported = await Linking.canOpenURL(url);

    if (supported) {
      await Linking.openURL(url);
    } else {
    }
  };

  const profileStyles: any = {
    modern: styles.profileSectionModern,
    classic: styles.profileSection,
    sleek: styles.profileSectionSleek,
  };

  const [refreshing, setRefreshing] = useState(false);
  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    try {
      await refetch?.();
    } catch (error) {
    } finally {
      setRefreshing(false);
    }
  }, [refetch]);

  const viewShotRef = useRef<ViewShot>(null);
  const captureAndExport = async () => {
    bottomSheetRef.current?.close();
    const uri = await viewShotRef.current?.capture?.();
    if (uri) {
      await exportCardImage(uri);
    }
  };
  const ProfileCard = ({ singleCardData, isExpanded }: any) => {
    const handleOpenBottom = async (data: any) => {
      setSelectedCardData(data);
      handleOpen();
    };

    return (
      <TouchableRipple
        style={[styles.cardContainer, isExpanded && styles.expandedCard]}
        onPress={() => {
          router.push(`/home/single/${singleCardData?._id}`);
        }}
      >
        <View style={{ borderRadius: 20, overflow: "hidden", width: "100%", height: "100%" }}>
          {singleCardData?.ContactDetails?.originalCard ? (
            <Image
              source={{ uri: singleCardData?.ContactDetails?.originalCard }}
              style={{
                width: "100%",
                height: 200,
                objectFit: "fill",
              }}
              resizeMode="contain"
            />
          ) : (
            <SingleBizCard cardDetails={singleCardData} isProUser={true} />
          )}
        </View>
      </TouchableRipple>
    );
  };

  return (
    <View style={styles.container}>
      <View style={styles.contactsistHeader}>
        <Text style={styles.name}>Your Contacts</Text>
        <View
          style={{
            flexDirection: "row",
            alignItems: "center",
            gap: spacingX._7,
          }}
        >
          {cardData?.length > 0 && (
            <TouchableOpacity onPress={() => exportToExcel(cardData)}>
              <AntDesign name="export" size={24} color="white" />
            </TouchableOpacity>
          )}

          <CircleButton
            iconSource={require("@/assets/main/menu-dot-icon.png")}
          />
        </View>
      </View>
      {loading ? (
        <Loading />
      ) : cardData?.length === 0 || !cardData ? (
        <Text
          style={{
            color: "#fff",
            fontSize: 12,
            textAlign: "center",
            marginTop: 20,
            fontStyle: "italic",
          }}
        >
          {`No ${category} Contacts yet.\nCreate your first Contact and start sharing cards instantly!`}
        </Text>
      ) : (
        <FlatList
          data={cardData}
          keyExtractor={(item) => item._id}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.listContent}
          renderItem={({ item, index }) => (
            <SlideInView duration={250 * (index + 1)}>
              <ProfileCard
                isExpanded={index === cardData.length - 1}
                singleCardData={item}
              />
            </SlideInView>
          )}
          refreshControl={
            <RefreshControl
              refreshing={refreshing}
              onRefresh={onRefresh}
              colors={["#00FF99"]}
              tintColor="#00FF99"
              progressBackgroundColor={"#222"}
            />
          }
        />
      )}
    </View>
  );
};

export default CardList;

const styles = StyleSheet.create({
  bottomSheetheading: {
    color: "white",
    fontSize: 16,
    fontWeight: "500",
    marginBottom: 12,
  },

  containerBottomSheet: {
    flex: 1,
    paddingHorizontal: 20,
    backgroundColor: "#000",
  },

  container: {
    flex: 15,
    backgroundColor: "#0E0E0E",
    paddingHorizontal: 15,
  },
  editIcon: {
    position: "absolute",
    top: 10,
    left: 10,
    zIndex: 10,
    backgroundColor: "transparent",
    borderRadius: 20,
    padding: 5,
    elevation: 5,
    shadowColor: "#fff",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
  },

  exportIcon: {
    position: "absolute",
    top: 10,
    left: 40,
    zIndex: 10,
    backgroundColor: "transparent",
    borderRadius: 20,
    padding: 5,
    elevation: 5,
    shadowColor: "#fff",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
  },
  deleteIcon: {
    position: "absolute",
    top: 6,
    right: 6,
    zIndex: 100,
    backgroundColor: "#FF4444",
    opacity: 0.7,
    height: 30,
    width: 30,
    borderRadius: 18,
    justifyContent: "center",
    alignItems: "center",
    elevation: 5,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
  },
  shareIcon: {
    position: "absolute",
    top: 8,
    right: 20,
    zIndex: 10,
    backgroundColor: "transparent",
    borderRadius: 20,
    padding: 5,
    elevation: 5,
    shadowColor: "#fff",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
  },

  iconRow: {
    flexDirection: "row",
    alignItems: "center",
  },
  icon: {
    width: 20,
    height: 20,
    marginRight: 8,
  },
  profileSection: {
    position: "absolute",
    padding: 15,
    justifyContent: "space-between",
    width: "100%",
    gap: 10,
    flexDirection: "row",
    alignItems: "center",
  },
  profileSectionModern: {
    position: "absolute",
    paddingTop: 60,
    paddingHorizontal: 15,
    gap: 10,
    flexDirection: "row",
    alignItems: "center",
  },
  profileSectionSleek: {
    position: "absolute",
    paddingTop: 25,
    gap: 10,
    flexDirection: "column",
    alignItems: "center",
    justifyContent: "center",
    width: "100%",
  },
  profileImage: {
    width: 50,
    height: 50,
    borderRadius: 30,
  },
  listContent: {
    paddingBottom: 40,
    alignItems: "center",
    paddingVertical: 10,
  },
  cardContainer: {
    width: width - 34,
    height: CARD_HEIGHT,
    marginBottom: -100,
    borderRadius: 20,
    overflow: "hidden",
    backgroundColor: "white",
    elevation: 15,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 20 },
    shadowOpacity: 0.9,
    shadowRadius: 15,
  },
  expandedCard: {
    height: EXPANDED_CARD_HEIGHT,
    marginBottom: 0,
  },
  cardBackground: {
    width: "100%",
    height: "100%",
    borderRadius: 30,
  },

  nameText: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#fff",
  },
  detailText: {
    fontSize: 12,
    color: "#fff",
    marginTop: 4,
  },
  nonClassicDetailSection: {
    position: "absolute",
    paddingTop: 120,
    paddingHorizontal: 10,
    gap: 10,
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "space-between",
    width: "100%",
  },
  contactsistHeader: {
    paddingBottom: spacingY._10,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
  },
  name: {
    color: "#fff",
    fontWeight: "bold",
    fontSize: 16,
  },

  detailBottom: {
    fontSize: 12,
    marginTop: 4,
  },
  detailSection: {
    position: "absolute",
    paddingTop: 120,
    paddingHorizontal: 10,
    gap: 10,
    flexDirection: "row",
    alignItems: "center",
    alignContent: "center",
    justifyContent: "space-between",
    width: "100%",
  },
});
