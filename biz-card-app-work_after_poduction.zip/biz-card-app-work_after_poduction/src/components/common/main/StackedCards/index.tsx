import React from 'react';
import { View, StyleSheet } from 'react-native';

const cards = [
    { id: '1', backgroundColor: 'lightblue' },
    { id: '2', backgroundColor: 'lightcoral' },
    { id: '3', backgroundColor: 'lightgreen' },
];

const StackedCards = () => {
    return (
        <View style={styles.container}>
            {cards.map((card, index) => (
                <View
                    key={card.id}
                    style={[
                        styles.card,
                        {
                            // Adjust position based on index for stacking effect
                            top: index * 20,
                            zIndex: cards.length - index, // Ensure correct stacking order
                            backgroundColor: card.backgroundColor
                        }
                    ]}
                >
                </View>
            ))}
        </View>
    );
};

const styles = StyleSheet.create({
    container: {
        flex: 1,
        justifyContent: 'center',
        alignItems: 'center',
    },
    card: {
        position: 'absolute',
        width: 200,
        height: 150,
        borderRadius: 10,
        shadowColor: '#000',
        shadowOffset: {
            width: 0,
            height: 2,
        },
        shadowOpacity: 0.25,
        shadowRadius: 3.84,
        elevation: 5,
        justifyContent: 'center',
        alignItems: 'center',
    },
});

export default StackedCards;