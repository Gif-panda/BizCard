import { spacingX } from '@/constants/theme';
import ContactTabItem from '@/src/components/globals/ContactTabItem';
import { filterTabs } from '@/src/constants/tabs';
import React, { useState } from 'react';
import { ScrollView, StyleSheet } from 'react-native';



const ContactTabs = ({
    subCategory,
    setSubCategory,
}: any) => {

    return (
        <ScrollView
            horizontal
            showsHorizontalScrollIndicator={false}
            contentContainerStyle={styles.scrollContainer}
        >
            {filterTabs.map((tab) => (
                <ContactTabItem
                    isIcon={false}
                    key={tab.label}
                    label={tab.label}
                    icon={tab.icon}
                    isActive={subCategory
                        === tab.value}
                    onPress={() => setSubCategory(tab.value)}
                />
            ))}
        </ScrollView>
    );
};

export default ContactTabs;

const styles = StyleSheet.create({
    scrollContainer: {
        paddingVertical: 5,
        paddingHorizontal: spacingX._12,
        backgroundColor: '#0E0E0E',
    },
});
