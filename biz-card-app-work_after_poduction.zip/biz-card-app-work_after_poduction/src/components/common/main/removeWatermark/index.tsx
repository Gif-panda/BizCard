import React from "react";
import { Text, View, StyleSheet } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import { MaterialCommunityIcons } from "@expo/vector-icons";

const RemoveWatermark = () => {
  return (
    <View style={styles.button}>
      <View style={styles.leftContainer}>
        <Text style={styles.text}>REMOVE WATERMARK</Text>
        <Ionicons name="information-circle-outline" size={14} color="#fff" style={{ marginLeft: 4 }} />
      </View>
      <View style={styles.proBadge}>
        <Text style={styles.proText}>PRO</Text>
        <MaterialCommunityIcons name="crown" size={14} color="#fbbf24" style={{ marginLeft: 4 }} />
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  button: {
    flexDirection: "row",
    backgroundColor: "#1f1f1f",
    paddingVertical: 16,
    paddingHorizontal: 16,
    borderRadius: 32,
    alignItems: "center",
    justifyContent: "space-between",
  },
  leftContainer: {
    flexDirection: "row",
    alignItems: "center",
  },
  text: {
    color: "#fff",
    fontSize: 12,
    fontWeight: "600",
    letterSpacing: 0.5,
  },
  proBadge: {
    flexDirection: "row",
    backgroundColor: "#2a2a2a",
    paddingHorizontal: 8,
    paddingVertical: 2,
    borderRadius: 12,
    alignItems: "center",
  },
  proText: {
    color: "#fff",
    fontSize: 10,
    fontWeight: "700",
  },
});

export default RemoveWatermark;
