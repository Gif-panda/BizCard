import Input from "@/components/Input";
import Typo from "@/components/Typo";
import { spacingY } from "@/constants/theme";
import { StyleSheet, View } from "react-native";
import { FormFieldProps } from "../types";

export const FormField = ({
  label,
  placeholder,
  onChangeText,
  value,
}: FormFieldProps) => (
  <View style={styles.formInner}>
    <Typo size={12} color="white">
      {label}
    </Typo>
    <Input
      containerStyle={{ borderRadius: 40, width: "100%" }}
      inputStyle={{ color: "white" }}
      onChangeText={onChangeText}
      placeholder={placeholder}
      value={value}
    />
  </View>
);

const styles = StyleSheet.create({
  formInner: {
    gap: spacingY._10,
    marginBottom: 10,
  },
});
