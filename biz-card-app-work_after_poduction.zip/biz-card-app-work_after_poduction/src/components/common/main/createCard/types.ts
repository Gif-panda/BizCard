export interface FormFieldProps {
    label: string;
    placeholder?: string;
    onChangeText: (text: string) => void;
    value?:string
  }
  