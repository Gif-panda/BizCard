import Typo from '@/components/Typo';
import { colors, spacingX, spacingY } from '@/constants/theme';
import React from 'react';
import { View, Pressable, Image, StyleSheet } from 'react-native';
import GoogleSigninComponent from './googleSigninComponent';


interface SocialAuthProps {
    label?: string;
}

const SocialAuth: React.FC<SocialAuthProps> = ({ label = 'Login with' }) => {
    return (
        <View style={styles.socialContainer}>
            <View style={styles.dividerContainer}>
                <View style={styles.line} />
                <Typo size={14} color={colors.black}>Or {label}</Typo>
                <View style={styles.line} />
            </View>

            <View style={styles.socialButtons}>
                {/* <Pressable style={styles.socialBtn}>
                    <Image
                        source={require('@/assets/social-media/facebook-icon.png')}
                        style={styles.icon}
                        resizeMode="contain"
                    />
                </Pressable> */}
                <GoogleSigninComponent />
                {/* <Pressable style={styles.socialBtn}>
                    <Image
                        source={require('@/assets/social-media/apple-icon.png')}
                        style={styles.icon}
                        resizeMode="contain"
                    />
                </Pressable> */}
            </View>
        </View>
    );
};

export default SocialAuth;

const styles = StyleSheet.create({
    socialContainer: {
        alignItems: 'center',
        gap: spacingY._15,
        marginVertical: 5
    },

    dividerContainer: {
        flexDirection: 'row',
        alignItems: 'center',
        gap: spacingX._10,
    },

    line: {
        flex: 1,
        height: 1,
        backgroundColor: colors.neutral400,
    },

    socialButtons: {
        flexDirection: 'row',
        gap: spacingX._20,
        paddingHorizontal: spacingX._20,
    },

    socialBtn: {

        borderWidth: 1,
        borderColor: colors.neutral400,
        borderRadius: 10,
        padding: spacingX._15,
        width: '33%',
        height: 60,
        justifyContent: 'center',
        alignItems: 'center',
    },

    icon: {
        width: 20,
        height: 20,
    },
});
