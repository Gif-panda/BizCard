import React from "react";
import {
  GoogleSignin,
  isErrorWithCode,
  isSuccessResponse,
  statusCodes,
} from "@react-native-google-signin/google-signin";
import {
  renderToastError,
  renderToastSuccess,
} from "@/src/components/globals/ToastNotification";
import { useBizGoogleSigninMutation } from "@/store/api/card/authApis";
import { useRouter } from "expo-router";
import { ActivityIndicator, Image, Pressable, StyleSheet } from "react-native";
import { colors, spacingX } from "@/constants/theme";

const GoogleSigninComponent = () => {
  const router = useRouter();
  const [bizGoogleSignIn, { isLoading: loading }] =
    useBizGoogleSigninMutation();

  const hanndleGoogleSignin = async () => {
    try {
      await GoogleSignin.hasPlayServices();
      const res = await GoogleSignin.signIn();
      if (isSuccessResponse(res)) {
        const { user } = res.data;
        const userData = {
          email: user?.email,
          name: user?.name,
          googleId: user?.id,
          idToken: res.data?.idToken,
        };
        const response = await bizGoogleSignIn(userData).unwrap();
        if (response?.status === "success") {
          renderToastSuccess("Signin Successfully");
          router.push("/(main)/home");
        } else {
          renderToastError(response?.message || "Error in Google Sign-In");
        }
      } else {
        renderToastError(res?.type);
      }
    } catch (error: unknown) {
      if (isErrorWithCode(error)) {
        console.log(error)
        const debugMessage = `Google error: ${error.code}${error.message ? ` - ${error.message}` : ""}`;
        
        if (error.code === statusCodes.SIGN_IN_CANCELLED) {
          renderToastError(`${debugMessage} (cancelled)`);
        } else if (error.code === statusCodes.IN_PROGRESS) {
          renderToastError(`${debugMessage} (in progress)`);
        } else if (error.code === statusCodes.PLAY_SERVICES_NOT_AVAILABLE) {
          renderToastError(`${debugMessage} (play services unavailable)`);
        } else {
          renderToastError(debugMessage);
        }
      } else {
        renderToastError("Google Sign-In failed");
      }
    }
  };

  return (
    <Pressable style={styles.socialBtn} onPress={hanndleGoogleSignin}>
      {loading ? (
        <ActivityIndicator size="small" color={colors.black} />
      ) : (
        <Image
          source={require("@/assets/social-media/google-icon.png")}
          style={styles.icon}
          resizeMode="contain"
        />
      )}
    </Pressable>
  );
};

export default GoogleSigninComponent;
const styles = StyleSheet.create({
  socialBtn: {
    borderWidth: 1,
    borderColor: colors.neutral400,
    borderRadius: 10,
    padding: spacingX._15,
    width: "33%",
    height: 60,
    justifyContent: "center",
    alignItems: "center",
  },
  icon: {
    width: 20,
    height: 20,
  },
});
