import React, { useState } from "react";
import {
  View,
  Text,
  ScrollView,
  StyleSheet,
  Image,
  TouchableOpacity,
  Animated,
  Dimensions,
} from "react-native";
import { spacingY } from "@/constants/theme";
import SettingsTab from "../globals/SettingsTab";
import {
  settingContacts,
  settingsHelp,
  settingsSubscription,
} from "@/src/constants/settings";
import { useFocusEffect, useRouter } from "expo-router";
import { Easing } from "react-native-reanimated";
import ConfirmationModal from "../globals/confirmationModal";
import { useDispatch, useSelector } from "react-redux";
import { logout } from "@/store/slices/card/cardSlice";
import { useCardDetails } from "@/store/selectors/card/card";
import { clearSubscription } from "@/store/slices/subscription/subscriptionSlice";
import { cardMainApi } from "@/store/api/card/mainApis";
import { cardAuthApi } from "@/store/api/card/authApis";
import {
  useLazyImportContactFromHubQuery,
  useLazyImportContactsFromSalesforceQuery,
  useUploadAllContactsToSalesforceMutation,
  useUploadContactToHubspotMutation,
  useSaveSalesforceCredentialsMutation,
  useSaveHubspotCredentialsMutation,
} from "@/store/api/card/mainApis";
import {
  renderToastError,
  renderToastSuccess,
} from "../globals/ToastNotification";
import HubspotConnectModal from "./components/connectModals/hubspotConnectModal";
import SalesforceConnectModal from "./components/connectModals/salesforceConnectModal";
import GlobalLoader from "../globals/loader";
import { getCopyright } from "@/utils/common";

const { width, height } = Dimensions.get("window");

const UserSettings = () => {
  const router = useRouter();
  const fadeAnim = React.useRef(new Animated.Value(0)).current;
  const slideAnim = React.useRef(new Animated.Value(0)).current;
  const animation = React.useRef<Animated.CompositeAnimation | null>(null);
  const [logoutModalVisible, setLogoutModalVisible] = useState(false);
  const { userData } = useSelector(useCardDetails);
  const dispatch = useDispatch();

  const [salesforceModalVisible, setSalesforceModalVisible] = useState(false);
  const [hubspotModalVisible, setHubspotModalVisible] = useState(false);

  useFocusEffect(
    React.useCallback(() => {
      fadeAnim.setValue(0);
      slideAnim.setValue(300);
      animation.current = Animated.parallel([
        Animated.timing(fadeAnim, {
          toValue: 1,
          duration: 500,
          useNativeDriver: true,
        }),
        Animated.timing(slideAnim, {
          toValue: 0,
          duration: 500,
          easing: Easing.out(Easing.quad),
          useNativeDriver: true,
        }),
      ]);

      animation.current.start();
      return () => {
        if (animation.current) {
          animation.current.stop();
          animation.current = null;
        }
      };
    }, [fadeAnim, slideAnim])
  );

  const settingLogout = [
    {
      id: "logout",
      label: "Log out",
      icon: require("@/assets/settings/logout-icon.png"),
      onPress: () => setLogoutModalVisible(true),
    },
  ];

  const [UploadContactToHubspot, { isLoading: uploadLoadng }] =
    useUploadContactToHubspotMutation();
  const [LazyImportContactFromHub, { isLoading: importLoading }] =
    useLazyImportContactFromHubQuery();
  const [
    UploadAllContactsToSalesforce,
    { isLoading: salesforceUploadLoading },
  ] = useUploadAllContactsToSalesforceMutation();
  const [
    LazyImportContactsFromSalesforce,
    { isLoading: salesforceImportLoading },
  ] = useLazyImportContactsFromSalesforceQuery();

  const handleUploadToHubspot = async () => {
    try {
      const response = await UploadContactToHubspot({}).unwrap();
      renderToastSuccess(response?.message || "Card Export successful");
    } catch (error: any) {
      renderToastError(error?.data?.message || "Upload failed");
    }
  };

  const handleImportFromHubspot = async () => {
    try {
      const response = await LazyImportContactFromHub({}).unwrap();
      renderToastSuccess(response?.message || "Card Import successful");
    } catch (error: any) {
      renderToastError(error?.data?.message || "Import failed");
    }
  };
  const handleUploadToSalesforce = async () => {
    try {
      const response = await UploadAllContactsToSalesforce({}).unwrap();
      renderToastSuccess(
        response?.message || "Contacts exported to Salesforce successfully"
      );
    } catch (error: any) {
      renderToastError(error?.data?.message || "Salesforce export failed");
    }
  };

  const handleImportFromSalesforce = async () => {
    try {
      const response = await LazyImportContactsFromSalesforce({}).unwrap();
      renderToastSuccess(
        response?.message || "Contacts imported from Salesforce successfully"
      );
    } catch (error: any) {
      renderToastError(error?.data?.message || "Salesforce import failed");
    }
  };

  const hubSpot = [
    {
      id: "upload",
      label: "Click to Export",
      icon: require("@/assets/settings/thunder-icon.png"),
      icon2: require("@/assets/settings/forward-arrow-icon.png"),
      onPress: () => handleUploadToHubspot(),
    },

    {
      id: "import",
      label: "Click for Import",
      icon: require("@/assets/settings/thunder-icon.png"),
      icon2: require("@/assets/settings/forward-arrow-icon.png"),
      onPress: () => handleImportFromHubspot(),
    },
  ];

  const salesForce = [
    {
      id: "salesforce-upload",
      label: "Export to Salesforce",
      icon: require("@/assets/settings/export-icon.png"),
      icon2: require("@/assets/settings/forward-arrow-icon.png"),
      onPress: () => handleUploadToSalesforce(),
    },
    {
      id: "salesforce-import",
      label: "Import from Salesforce",
      icon: require("@/assets/settings/import-icon.png"),
      icon2: require("@/assets/settings/forward-arrow-icon.png"),
      onPress: () => handleImportFromSalesforce(),
    },
  ];

  const connectOptions = [
    {
      id: "connect-salesforce",
      label: "Connect to Salesforce",
      icon: require("@/assets/settings/salesforce-icon.png"),
      icon2: require("@/assets/settings/forward-arrow-icon.png"),
      onPress: () => setSalesforceModalVisible(true),
    },
    {
      id: "connect-hubspot",
      label: "Connect to Hubspot",
      icon: require("@/assets/settings/hubspot-icon.png"),
      icon2: require("@/assets/settings/forward-arrow-icon.png"),
      onPress: () => setHubspotModalVisible(true),
    },
  ];

  const handleLogout = () => {
    setLogoutModalVisible(false);
    dispatch(logout());
    dispatch(clearSubscription());
    dispatch(cardMainApi.util.resetApiState());
    dispatch(cardAuthApi.util.resetApiState());
    router.replace("/(auth)/login");
  };

  const [saveSalesforceCredentials, { isLoading: salesforceLoading }] =
    useSaveSalesforceCredentialsMutation();
  const [saveHubspotCredentials, { isLoading: hubspotLoading }] =
    useSaveHubspotCredentialsMutation();
  const handleSalesforceConnect = async (credentials: {
    userName: string;
    securityToken: string;
    password: string;
  }) => {
    try {
      const payload = {
        userName: credentials.userName,
        securityToken: credentials.securityToken,
        password: credentials.password,
      };
       await saveSalesforceCredentials(payload).unwrap();
      renderToastSuccess("Salesforce connected successfully!");
      setSalesforceModalVisible(false);
    } catch (error: any) {
      console.log("error", error);
      renderToastError(error?.data?.message || "Salesforce connection failed");
    }
  };

  const handleHubspotConnect = async (token: string) => {
    try {
      const payload = { accessToken: token };
      await saveHubspotCredentials(payload).unwrap();
      renderToastSuccess("HubSpot connected successfully!");
      setHubspotModalVisible(false);
    } catch (error: any) {
      renderToastError(error?.data?.message || "HubSpot connection failed");
    }
  };

  return (
    <Animated.View
      style={[
        styles.container,
        {
          opacity: fadeAnim,
          transform: [{ translateX: slideAnim }],
        },
      ]}
    >
      <GlobalLoader loading={uploadLoadng || importLoading || salesforceUploadLoading || salesforceImportLoading} />
      <View style={styles.content}>
        <ScrollView
          contentContainerStyle={styles.scrollContent}
          showsVerticalScrollIndicator={false}
        >
          <TouchableOpacity
            onPress={() => router.push("/(main)/home")}
            style={styles.backHeader}
          >
            <Image
              source={require("@/assets/settings/backward-arrow-icon.png")}
              style={styles.backIcon}
            />
            <Text style={styles.name}>Settings</Text>
          </TouchableOpacity>

          <View style={styles.header}>
            <View>
              <Text style={styles.name}>{userData?.name}</Text>
              <Text style={styles.email}>{userData?.email}</Text>
            </View>
          </View>

          <View style={styles.optionsContainer}>
            <Text style={styles.optionHeader}>Contacts</Text>
            <SettingsTab options={settingContacts} />
          </View>
          <View style={styles.optionsContainer}>
            <Text style={styles.optionHeader}>Connections</Text>
            <SettingsTab options={connectOptions} />
          </View>

          <View style={styles.optionsContainer}>
            <Text style={styles.optionHeader}>Hubspot</Text>
            <SettingsTab options={hubSpot} />
          </View>
          <View style={styles.optionsContainer}>
            <Text style={styles.optionHeader}>Sales Force</Text>
            <SettingsTab options={salesForce} />
          </View>

          <View style={styles.optionsContainer}>
            <Text style={styles.optionHeader}>Subscription</Text>
            <SettingsTab options={settingsSubscription} />
          </View>

          <View style={styles.optionsContainer}>
            <Text style={styles.optionHeader}>Help</Text>
            <SettingsTab options={settingsHelp} />
          </View>
        </ScrollView>

        <View style={styles.logoutContainer}>
          <Text style={styles.optionHeader}>Account Log out</Text>
          <SettingsTab options={settingLogout} />
          <Text style={styles.copyright}>{getCopyright()}</Text>
        </View>
      </View>

      <ConfirmationModal
        visible={logoutModalVisible}
        title="Log Out"
        message="Are you sure you want to log out?"
        confirmText="Log Out"
        cancelText="Cancel"
        onConfirm={handleLogout}
        onCancel={() => setLogoutModalVisible(false)}
      />

      <SalesforceConnectModal
        visible={salesforceModalVisible}
        onClose={() => setSalesforceModalVisible(false)}
        onSubmit={handleSalesforceConnect}
        loading={salesforceLoading}
      />

      <HubspotConnectModal
        visible={hubspotModalVisible}
        onClose={() => setHubspotModalVisible(false)}
        onSubmit={handleHubspotConnect}
        loading={hubspotLoading}
      />
    </Animated.View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#0E0E0E",
  },
  content: {
    flex: 1,
  },
  scrollContent: {
    paddingHorizontal: 20,
    paddingBottom: 20,
  },
  logoutContainer: {
    paddingHorizontal: 16,
    paddingBottom: 16,
    paddingTop: 10,
    borderTopWidth: 1,
    borderTopColor: "#333",
  },
  optionsContainer: {
    marginTop: spacingY._10,
  },
  header: {
    flexDirection: "column",
    alignItems: "flex-start",
    paddingVertical: 20,
    borderBottomColor: "#333",
    borderBottomWidth: 1,
    borderStyle: "dashed",
  },
  backHeader: {
    flexDirection: "row",
    alignItems: "center",
    paddingVertical: 20,
    borderBottomColor: "#333",
    borderBottomWidth: 1,
  },
  backIcon: {
    width: 14,
    height: 14,
    borderRadius: 25,
    marginRight: 15,
  },
  name: {
    fontSize: 18,
    color: "#fff",
    fontWeight: "600",
  },
  optionHeader: {
    fontSize: 14,
    color: "#aaa",
    marginBottom: spacingY._10,
    fontWeight: "400",
  },
  email: {
    fontSize: 14,
    color: "#aaa",
  },
  copyright: {
    color: "#555",
    fontSize: 12,
    textAlign: "center",
    marginTop: 12,
  },
});

export default UserSettings;
