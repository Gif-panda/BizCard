import React, { useState } from "react";
import {
  Modal,
  View,
  Text,
  StyleSheet,
  TouchableWithoutFeedback,
  KeyboardAvoidingView,
  Platform,
  Keyboard,
} from "react-native";
import AntDesign from "@expo/vector-icons/AntDesign";
import Button from "@/components/Button";
import Input from "@/components/Input";

interface SalesforceConnectModalProps {
  visible: boolean;
  onClose: () => void;
  loading?: boolean;
  onSubmit: (credentials: {
    userName: string;
    securityToken: string;
    password: string;
  }) => void;
}

const SalesforceConnectModal: React.FC<SalesforceConnectModalProps> = ({
  visible,
  onClose,
  onSubmit,
  loading,
}) => {
  const [form, setForm] = useState({
    userName: "",
    securityToken: "",
    password: "",
  });

  const handleChange = (key: keyof typeof form, value: string) => {
    setForm((prev) => ({ ...prev, [key]: value }));
  };

  const handleSubmit = () => {
    if (!form.userName || !form.securityToken || !form.password) return;
    onSubmit(form);
  };

  return (
    <Modal
      transparent
      visible={visible}
      animationType="fade"
      onRequestClose={onClose}
    >
      <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
        <View style={styles.backdrop}>
          <KeyboardAvoidingView
            style={styles.centered}
            behavior={Platform.OS === "ios" ? "padding" : undefined}
          >
            <TouchableWithoutFeedback onPress={() => {}}>
              <View style={styles.content}>
                {/* Header */}
                <View style={styles.header}>
                  <Text style={styles.title}>Connect to Salesforce</Text>
                  <Button onPress={onClose} style={styles.closeBtn}>
                    <AntDesign name="close" size={16} color="#aaa" />
                  </Button>
                </View>

                {/* Inputs */}
                <View style={styles.inputs}>
                  <Input
                    placeholder="User Name"
                    value={form.userName}
                    onChangeText={(text) => handleChange("userName", text)}
                    style={styles.inputStyle}
                  />
                  <Input
                    placeholder="Security Token"
                    value={form.securityToken}
                    style={styles.inputStyle}
                    onChangeText={(text) => handleChange("securityToken", text)}
                  />
                  <Input
                    placeholder="Password"
                    secureTextEntry
                    value={form.password}
                    style={styles.inputStyle}
                    onChangeText={(text) => handleChange("password", text)}
                  />
                </View>

                {/* Action buttons */}
                <View style={styles.actions}>
                  <Button
                    loading={loading}
                    onPress={handleSubmit}
                    style={[styles.actionBtn, styles.connectBtn]}
                    disabled={
                      !form.userName || !form.securityToken || !form.password
                    }
                  >
                    <Text style={styles.connectText}>Connect</Text>
                  </Button>
                  <Button
                    onPress={onClose}
                    style={[styles.actionBtn, styles.cancelBtn]}
                  >
                    <Text style={styles.cancelText}>Cancel</Text>
                  </Button>
                </View>
              </View>
            </TouchableWithoutFeedback>
          </KeyboardAvoidingView>
        </View>
      </TouchableWithoutFeedback>
    </Modal>
  );
};

export default SalesforceConnectModal;

const styles = StyleSheet.create({
  backdrop: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.7)",
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 16,
  },
  centered: {
    width: "100%",
    maxWidth: 400,
  },
  content: {
    backgroundColor: "#1E1E1E",
    borderRadius: 16,
    padding: 20,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 20,
  },
  inputStyle: {
    color: "#fff",
    justifyContent: "flex-start",
    alignItems: "flex-start",
    textAlign: "left",
    width: "100%",
  },
  title: {
    fontSize: 18,
    fontWeight: "600",
    color: "#fff",
  },
  closeBtn: {
    backgroundColor: "#eee",
    height: 32,
    width: 32,
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
  },
  inputs: {
    gap: 12,
    marginBottom: 20,
  },
  actions: {
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 12,
  },
  actionBtn: {
    flex: 1,
  },
  connectBtn: {
    backgroundColor: "#1FFA9E",
  },
  cancelBtn: {
    backgroundColor: "#fff",
  },
  connectText: {
    color: "#fff",
    fontWeight: "600",
  },
  cancelText: {
    color: "#fff",
    fontWeight: "600",
  },
});
