import React, { useState } from "react";
import {
  Modal,
  View,
  Text,
  StyleSheet,
  TouchableWithoutFeedback,
  KeyboardAvoidingView,
  Platform,
  Keyboard,
} from "react-native";
import AntDesign from "@expo/vector-icons/AntDesign";
import Button from "@/components/Button";
import Input from "@/components/Input";

interface HubspotConnectModalProps {
  visible: boolean;
  loading?: boolean;
  onClose: () => void;
  onSubmit: (token: string) => void;
}

const HubspotConnectModal: React.FC<HubspotConnectModalProps> = ({
  visible,
  onClose,
  onSubmit,
  loading,
}) => {
  const [token, setToken] = useState("");

  const handleSubmit = () => {
    if (!token.trim()) return;
    onSubmit(token.trim());
  };

  return (
    <Modal
      transparent
      visible={visible}
      animationType="fade"
      onRequestClose={onClose}
    >
      <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
        <View style={styles.backdrop}>
          <KeyboardAvoidingView
            style={styles.centered}
            behavior={Platform.OS === "ios" ? "padding" : undefined}
          >
            <TouchableWithoutFeedback onPress={() => {}}>
              <View style={styles.content}>
                {/* Header */}
                <View style={styles.header}>
                  <Text style={styles.title}>Connect to Hubspot</Text>
                  <Button onPress={onClose} style={styles.closeBtn}>
                    <AntDesign name="close" size={16} color="#aaa" />
                  </Button>
                </View>

                {/* Input */}
                <View style={styles.inputs}>
                  <Input
                    placeholder="Access Token"
                    value={token}
                    onChangeText={setToken}
                    style={styles.inputStyle}
                  />
                </View>

                {/* Action buttons */}
                <View style={styles.actions}>
                  <Button
                    loading={loading}
                    onPress={handleSubmit}
                    style={[styles.actionBtn, styles.connectBtn]}
                    disabled={!token.trim()}
                  >
                    <Text style={styles.connectText}>Connect</Text>
                  </Button>
                  <Button
                    onPress={onClose}
                    style={[styles.actionBtn, styles.cancelBtn]}
                  >
                    <Text style={styles.cancelText}>Cancel</Text>
                  </Button>
                </View>
              </View>
            </TouchableWithoutFeedback>
          </KeyboardAvoidingView>
        </View>
      </TouchableWithoutFeedback>
    </Modal>
  );
};

export default HubspotConnectModal;

const styles = StyleSheet.create({
  backdrop: {
    flex: 1,
    backgroundColor: "rgba(0,0,0,0.7)",
    justifyContent: "center",
    alignItems: "center",
    paddingHorizontal: 16,
  },
  centered: {
    width: "100%",
    maxWidth: 400,
  },
  content: {
    backgroundColor: "#1E1E1E",
    borderRadius: 16,
    padding: 20,
  },
  header: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    marginBottom: 20,
  },
  inputStyle: {
    color: "#fff",
    justifyContent: "flex-start",
    alignItems: "flex-start",
    textAlign: "left",
    width: "100%",
  },
  title: {
    fontSize: 18,
    fontWeight: "600",
    color: "#fff",
  },
  closeBtn: {
    backgroundColor: "#eee",
    height: 32,
    width: 32,
    borderRadius: 16,
    alignItems: "center",
    justifyContent: "center",
  },
  inputs: {
    gap: 12,
    marginBottom: 20,
  },
  actions: {
    flexDirection: "row",
    justifyContent: "space-between",
    gap: 12,
  },
  actionBtn: {
    flex: 1,
  },
  connectBtn: {
    backgroundColor: "#1FFA9E",
  },
  cancelBtn: {
    backgroundColor: "#fff",
  },
  connectText: {
    color: "#fff",
    fontWeight: "600",
  },
  cancelText: {
    color: "#fff",
    fontWeight: "600",
  },
});
