import React from 'react';
import { View, Text, StyleSheet, TouchableOpacity } from 'react-native';
import { Ionicons } from '@expo/vector-icons'; // or your preferred icon library

interface SettingsItemProps {
    label: string;
    rightText?: string;
    onPress?: () => void;
}

const SettingsItem: React.FC<SettingsItemProps> = ({ label, rightText, onPress }) => {
    return (
        <TouchableOpacity onPress={onPress} style={styles.item}>
            <Text style={styles.label}>{label}</Text>
            <View style={styles.right}>
                {rightText && <Text style={styles.rightText}>{rightText}</Text>}
                <Ionicons name="chevron-forward" size={18} color="#888" />
            </View>
        </TouchableOpacity>
    );
};

export default SettingsItem;

const styles = StyleSheet.create({
    item: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingVertical: 14,
        borderBottomColor: '#333',
        borderBottomWidth: 1,
    },
    label: {
        color: '#fff',
        fontSize: 16,
    },
    right: {
        flexDirection: 'row',
        alignItems: 'center',
    },
    rightText: {
        color: '#888',
        fontSize: 14,
        marginRight: 8,
    },
});
