import React from 'react';
import { View, Text, StyleSheet } from 'react-native';

interface SettingsSectionProps {
    title: string;
    children: React.ReactNode;
}

const SettingsSection: React.FC<SettingsSectionProps> = ({ title, children }) => {
    return (
        <View style={styles.section}>
            <Text style={styles.sectionTitle}>{title}</Text>
            {children}
        </View>
    );
};

export default SettingsSection;

const styles = StyleSheet.create({
    section: {
        marginTop: 20,
    },
    sectionTitle: {
        color: '#888',
        fontSize: 12,
        marginBottom: 10,
    },
});
