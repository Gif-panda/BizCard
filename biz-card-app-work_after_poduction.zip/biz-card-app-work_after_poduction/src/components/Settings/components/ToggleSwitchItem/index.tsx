import React from 'react';
import { View, Text, Switch, StyleSheet } from 'react-native';

interface ToggleSwitchItemProps {
    label: string;
    value: boolean;
    onValueChange: (value: boolean) => void;
}

const ToggleSwitchItem: React.FC<ToggleSwitchItemProps> = ({ label, value, onValueChange }) => {
    return (
        <View style={styles.item}>
            <Text style={styles.label}>{label}</Text>
            <Switch
                value={value}
                onValueChange={onValueChange}
                trackColor={{ false: '#767577', true: '#81b0ff' }}
                thumbColor={value ? '#f5dd4b' : '#f4f3f4'}
            />
        </View>
    );
};

export default ToggleSwitchItem;

const styles = StyleSheet.create({
    item: {
        flexDirection: 'row',
        justifyContent: 'space-between',
        alignItems: 'center',
        paddingVertical: 14,
        borderBottomColor: '#333',
        borderBottomWidth: 1,
    },
    label: {
        color: '#fff',
        fontSize: 16,
        flex: 1,
        paddingRight: 10,
    },
});
