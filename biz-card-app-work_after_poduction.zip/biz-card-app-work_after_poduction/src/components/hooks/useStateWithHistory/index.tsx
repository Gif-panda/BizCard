import { useState, useRef, useCallback } from 'react';

function useStateWithHistory(initialState, capacity = 10) {
    const [state, setState] = useState(initialState);
    const history = useRef([initialState]);
    const pointer = useRef(0);

    const push = useCallback(
        (value) => {
            const newHistory = history.current.slice(0, pointer.current + 1);
            if (newHistory.length >= capacity) newHistory.shift();
            history.current = [...newHistory, value];
            pointer.current = history.current.length - 1;
            setState(value);
        },
        [capacity]
    );

    const undo = useCallback(() => {
        if (pointer.current > 0) {
            pointer.current--;
            setState(history.current[pointer.current]);
            return true;
        }
        return false;
    }, []);

    const redo = useCallback(() => {
        if (pointer.current < history.current.length - 1) {
            pointer.current++;
            setState(history.current[pointer.current]);
            return true;
        }
        return false;
    }, []);

    return [state, push, undo, redo];
}
