import { combineReducers } from '@reduxjs/toolkit';
import configSlice from './slices/config/configSlice';
import cardSlice from './slices/card/cardSlice';
import subscriptionSlice from "./slices/subscription/subscriptionSlice";
import { cardAuthApi } from './api/card/authApis';
import { cardMainApi } from './api/card/mainApis';

// eslint-disable-next-line import/prefer-default-export
export const rootReducer = combineReducers({
  // commong reducers
  // signInType: signInTypeSlice,

  // user recuders
  card: cardSlice,
  config: configSlice,
  subscription: subscriptionSlice,

  [cardAuthApi.reducerPath]: cardAuthApi.reducer,
  [cardMainApi.reducerPath]: cardMainApi.reducer,

});
