/* eslint-disable no-param-reassign */
import { createSlice } from '@reduxjs/toolkit';


const configSlice = createSlice({
  name: 'config',
  initialState: {

  },
  reducers: {
  
  },

  extraReducers() {
    // builder.addMatcher(
    //   configApi.endpoints.getCurrency.matchFulfilled,
    //   (state, { payload }) => {
    //     (state as any).currencyData = payload;
    //   },
    // );
  },
});

export const {
 
} = configSlice.actions;

export default configSlice.reducer;
