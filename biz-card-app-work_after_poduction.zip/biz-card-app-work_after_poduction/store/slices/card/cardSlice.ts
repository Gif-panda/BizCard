/* eslint-disable import/order */
/* eslint-disable no-param-reassign */
import { cardAuthApi } from "@/store/api/card/authApis";
import { cardMainApi } from "@/store/api/card/mainApis";
import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  jwt: "",
  userData: {
    name: "",
    email: "",
    couponVerfied: false,
  },
  onBoardingComplete: false,
};

const cardSlice = createSlice({
  name: "card",
  initialState,
  reducers: {
    logout: (state) => {
      state.jwt = "";
      state.userData = {
        name: "",
        email: "",
        couponVerfied: false,
      };
    },
     onBoardingComplete: (state) => {
      state.onBoardingComplete = true;
    },
  },
  extraReducers(builder) {
    builder.addMatcher(
      cardAuthApi.endpoints.bizSignup.matchFulfilled,
      (state, { payload }) => {
        state.jwt = payload.token;
        state.userData = payload.user;
      }
    );

    builder.addMatcher(
      cardAuthApi.endpoints.bizSignin.matchFulfilled,
      (state, { payload }) => {
        state.jwt = payload.token;
        state.userData = payload.user;
      }
    );
    builder.addMatcher(
      cardAuthApi.endpoints.bizGoogleSignin.matchFulfilled,
      (state, { payload }) => {
        state.jwt = payload.token;
        state.userData = payload.user;
      }
    );
    builder.addMatcher(
      cardMainApi.endpoints.verifyCoupon.matchFulfilled,
      (state, { payload }) => {
        state.userData = {
          ...state.userData,
          ...payload?.user,
        };
      }
    );
  },
});

export const { logout, onBoardingComplete } = cardSlice.actions;
export default cardSlice.reducer;
