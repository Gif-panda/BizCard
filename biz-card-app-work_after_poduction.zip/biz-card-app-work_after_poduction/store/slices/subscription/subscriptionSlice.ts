/* eslint-disable no-param-reassign */
import { createSlice, PayloadAction } from "@reduxjs/toolkit";
import { CustomerInfo, PurchasesEntitlementInfo } from "react-native-purchases";

type Nullable<T> = T | null;

export interface SubscriptionProductStatus {
  productId: string;
  displayName: Nullable<string>;
  isBought: boolean;
  expiresDate: Nullable<string>;
  timeRemainingMs: number;
  timeRemainingLabel: Nullable<string>;
  willRenew: Nullable<boolean>;
}

export interface SubscriptionState {
  isInitialized: boolean;
  lastSyncedAt: Nullable<string>;
  isBought: boolean;
  activeProductId: Nullable<string>;
  activeSubscriptionName: Nullable<string>;
  activeExpiresDate: Nullable<string>;
  activeTimeRemainingMs: number;
  activeTimeRemainingLabel: Nullable<string>;
  managementURL: Nullable<string>;
  products: Record<string, SubscriptionProductStatus>;
}

const initialState: SubscriptionState = {
  isInitialized: false,
  lastSyncedAt: null,
  isBought: false,
  activeProductId: null,
  activeSubscriptionName: null,
  activeExpiresDate: null,
  activeTimeRemainingMs: 0,
  activeTimeRemainingLabel: null,
  managementURL: null,
  products: {},
};

const getTimeRemainingMs = (expiresDate: Nullable<string>) => {
  if (!expiresDate) {
    return 0;
  }

  const expiresAt = Date.parse(expiresDate);
  if (Number.isNaN(expiresAt)) {
    return 0;
  }

  return Math.max(expiresAt - Date.now(), 0);
};

const formatRemainingTime = (remainingMs: number, expiresDate: Nullable<string>) => {
  if (!expiresDate) {
    return "Lifetime";
  }

  if (remainingMs <= 0) {
    return "Expired";
  }

  const totalHours = Math.floor(remainingMs / (1000 * 60 * 60));
  const days = Math.floor(totalHours / 24);
  const hours = totalHours % 24;

  if (days > 0) {
    return `${days}d ${hours}h`;
  }

  const minutes = Math.floor((remainingMs % (1000 * 60 * 60)) / (1000 * 60));
  return `${hours}h ${minutes}m`;
};

const buildProductStatus = (
  productId: string,
  displayName: Nullable<string>,
  isBought: boolean,
  expiresDate: Nullable<string>,
  willRenew: Nullable<boolean>
): SubscriptionProductStatus => {
  const timeRemainingMs = getTimeRemainingMs(expiresDate);

  return {
    productId,
    displayName,
    isBought,
    expiresDate,
    timeRemainingMs,
    timeRemainingLabel: formatRemainingTime(timeRemainingMs, expiresDate),
    willRenew,
  };
};

const getProductNameFromEntitlement = (
  entitlementMap: Record<string, PurchasesEntitlementInfo>,
  productIdentifier: string
) => {
  const entitlement = Object.values(entitlementMap).find(
    item => item.productIdentifier === productIdentifier
  );

  return entitlement?.identifier ?? null;
};

const getPrimaryActiveEntitlement = (customerInfo: CustomerInfo) => {
  const activeEntitlements = Object.values(customerInfo.entitlements.active ?? {});
  if (activeEntitlements.length === 0) {
    return null;
  }

  return activeEntitlements.reduce((current, candidate) => {
    const currentExpiration = current.expirationDate ? Date.parse(current.expirationDate) : Infinity;
    const candidateExpiration = candidate.expirationDate ? Date.parse(candidate.expirationDate) : Infinity;
    return candidateExpiration > currentExpiration ? candidate : current;
  });
};

const subscriptionSlice = createSlice({
  name: "subscription",
  initialState,
  reducers: {
    setCustomerInfo: (state, action: PayloadAction<CustomerInfo | null>) => {
      const customerInfo = action.payload;
      if (!customerInfo) {
        state.isInitialized = true;
        state.lastSyncedAt = new Date().toISOString();
        state.isBought = false;
        state.activeProductId = null;
        state.activeSubscriptionName = null;
        state.activeExpiresDate = null;
        state.activeTimeRemainingMs = 0;
        state.activeTimeRemainingLabel = null;
        state.managementURL = null;
        state.products = {};
        return;
      }

      const products: Record<string, SubscriptionProductStatus> = {};
      const activeIds = new Set<string>(customerInfo.activeSubscriptions ?? []);
      const entitlementAll = customerInfo.entitlements.all ?? {};

      Object.entries(customerInfo.subscriptionsByProductIdentifier ?? {}).forEach(
        ([productIdentifier, subscription]) => {
          const productName = getProductNameFromEntitlement(entitlementAll, productIdentifier);
          const composedProductId = subscription.productIdentifier;

          if (subscription.isActive) {
            activeIds.add(productIdentifier);
            activeIds.add(composedProductId);
          }

          products[productIdentifier] = buildProductStatus(
            productIdentifier,
            productName,
            subscription.isActive,
            subscription.expiresDate,
            subscription.willRenew
          );

          products[composedProductId] = buildProductStatus(
            composedProductId,
            productName,
            subscription.isActive,
            subscription.expiresDate,
            subscription.willRenew
          );
        }
      );

      Object.entries(customerInfo.allExpirationDates ?? {}).forEach(([productId, expiresDate]) => {
        const existing = products[productId];
        const isBought = activeIds.has(productId);
        const mergedDisplayName = existing?.displayName ?? null;
        const mergedWillRenew = existing?.willRenew ?? null;
        const mergedExpiresDate = existing?.expiresDate ?? expiresDate;

        products[productId] = buildProductStatus(
          productId,
          mergedDisplayName,
          isBought || existing?.isBought || false,
          mergedExpiresDate,
          mergedWillRenew
        );
      });

      const primaryEntitlement = getPrimaryActiveEntitlement(customerInfo);
      const primaryProductId = primaryEntitlement
        ? primaryEntitlement.productPlanIdentifier
          ? `${primaryEntitlement.productIdentifier}:${primaryEntitlement.productPlanIdentifier}`
          : primaryEntitlement.productIdentifier
        : customerInfo.activeSubscriptions[0] ?? null;
      const primarySubscriptionName = primaryEntitlement?.identifier ?? null;
      const primaryExpiresDate = primaryEntitlement?.expirationDate ?? null;
      const primaryTimeRemainingMs = getTimeRemainingMs(primaryExpiresDate);

      state.isInitialized = true;
      state.lastSyncedAt = customerInfo.requestDate ?? new Date().toISOString();
      state.isBought = activeIds.size > 0;
      state.activeProductId = primaryProductId;
      state.activeSubscriptionName = primarySubscriptionName;
      state.activeExpiresDate = primaryExpiresDate;
      state.activeTimeRemainingMs = primaryTimeRemainingMs;
      state.activeTimeRemainingLabel = formatRemainingTime(primaryTimeRemainingMs, primaryExpiresDate);
      state.managementURL = customerInfo.managementURL;
      state.products = products;
    },
    clearSubscription: state => {
      Object.assign(state, initialState);
    },
  },
});

export const { setCustomerInfo, clearSubscription } = subscriptionSlice.actions;
export default subscriptionSlice.reducer;
