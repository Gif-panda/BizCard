/* eslint-disable import/prefer-default-export */
import { RootState } from '@/store';

export const useCardDetails = (state: RootState) => state.card;
