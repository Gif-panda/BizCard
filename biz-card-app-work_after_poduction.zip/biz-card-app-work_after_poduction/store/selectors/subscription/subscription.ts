/* eslint-disable import/prefer-default-export */
import { RootState } from "@/store";

export const useSubscriptionDetails = (state: RootState) => state.subscription;
