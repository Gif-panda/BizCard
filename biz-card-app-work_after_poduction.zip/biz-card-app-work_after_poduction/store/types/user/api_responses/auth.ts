/* eslint-disable @typescript-eslint/no-explicit-any */
import { IAPIRespone } from '../..';

// sign in api response
interface SignIn {
  auth_token: string;
}

export interface UserPayee {
  _id?: string;
  benefId?: string;
  fullName: string;
  email: string;
  phone: string;
  postalCode: string;
  city: string;
  street: string;
  houseNumber: string;
  country: string;
  contact?: {
    address?: {
      city?: string;
      country?: string;
      postalCode?: string;
      street?: string;
    };
    email?: string;
    phone?: string;
  };
}
export interface Quotes {
  buyAmount: string;
  buyCurrency: string;
  creditAmount: string;
  cutOffDateTime: string;
  debitAmount: string;
  exchangeDate: string;
  expiryDateTime: string;
  feeAmount: string;
  feeCurrency: string;
  id: string;
  offline: boolean;
  rate: string;
  sellAmount: string;
  sellCurrency: string;
  settlementDate: string;
}
export interface LastSelectBenefDetails {
  isFirstTransfer?: boolean;
  accountNumber?: string;
  beneficiaryId?: string;
  country?: string;
  currency?: string;
  iban?: string;
  bankName?: string;
  id?: string;
  _id?: string;
  routingCodes: {
    bic?: string;
    'sort-code'?: string;
    aba?: string;
  };
}
export interface OutgoingTransfer {
  amount: string;
  description: string;
  transferReasonId: string;
  currency?: string;
}
// verify sign in api response
export interface VerifySignIn {
  cardStatus?: string | undefined;
  virtualCardStatus?: string | undefined;
  devices?: any[];
  alert?: boolean;
  activeCurrencyBalance?: any;
  clientId?: string;
  firstName: string;
  createdAt?: string;
  lastName: string;
  emailVerified: boolean;
  phoneNumber: string;
  isPassCodeSet?: boolean;
  activeCurrency?: string;
  email: string;
  isVerified: boolean;
  isVerifiedAt?: string;
  country: {
    name: string;
    countryCode: string;
  };
  dateOfBirth: string;
  phoneNumberVerified: boolean;
  kycStatus: number;
  role: string;
  isBlocked: boolean;
  packageId: string;
  flag: number;
  isDeleted: boolean;
  gender: string;
  accountDetails: any[];
  gbg?: Gbg;
  kyc?: {
    failedReason?: string;
    kycStatus: string;
  };
  auth_token: string;
  activeAccountDetails?: {
    accountId: string;
    accountNumber: string;
    active: boolean;
    currencyCode: string;
    iban: string;
    routingCodes: any[];
    status: string;
  };
  feePlan?: {
    payments: {
      multiCurrency: any[];
    };
  };
}

interface Gbg {
  steps: {
    isFinished: boolean;
    idfront: IUploadDetails;
    idback: Idback;
    poa: IUploadDetails;
    selfie: IUploadDetails;
  };
}

interface Idback {
  uploaded: boolean;
  isFailed: boolean;
  BackNotRequired: boolean;
  failedMessage: string;
  retriesScan: string;
}

interface IUploadDetails {
  uploaded: boolean;
  isFailed: boolean;
  failedMessage: string;
  retriesScan: string;
}

// sign up api response
interface Signup {
  email: string;
  firstName: string;
  lastName: string;
  dateOfBirth: string;
  phoneNumber: string;
  emailVerified: boolean;
  phoneNumberVerified: boolean;
  isVerified: boolean;
  kycStatus: number;
  role: string;
  isBlocked: boolean;
  packageId: string;
  address: {
    buildingName: string;
    streetAddress: string;
    town: string;
    postcode: string;
  };
  sourceOfFunds: string;
  country: {
    name: string;
    countryCode: string;
  };
  flag: number;
  isDeleted: boolean;
  gender: string;
  tokenVersion: number;
  accountDetails: any[];
  auth_token: string;
}

interface VerifySignupEmail {
  email: string;
  emailVerified: boolean;
}

interface VerifySignupPhoneNumber {
  phoneNumber: string;
  phoneNumberVerified: boolean;
}

export type ISignInResponse = IAPIRespone<SignIn>;
export type IVerifySignInResponse = IAPIRespone<VerifySignIn>;
export type ISignUpResponse = IAPIRespone<Signup>;
export type ICurrentResponse = IAPIRespone<VerifySignIn>;
export type IVerifySignUpEmailResponse = IAPIRespone<VerifySignupEmail>;
export type IVerifySignUpPhoneResponse = IAPIRespone<VerifySignupPhoneNumber>;
