import { configureStore } from '@reduxjs/toolkit';
import devToolsEnhancer from 'redux-devtools-expo-dev-plugin';
import {
  FLUSH,
  PAUSE,
  PERSIST,
  PURGE,
  REGISTER,
  REHYDRATE,
  persistReducer,
} from 'redux-persist';
import reduxStorage from './mmkv/mmkvStorage';
import { rootReducer } from './rootReducer';
import { cardAuthApi } from './api/card/authApis';
import { cardMainApi } from './api/card/mainApis';

const persistConfig = {
  key: 'root',
  storage: reduxStorage,
  whitelist: ['card', 'config', 'subscription'],
};

const persistedReducer = persistReducer(persistConfig, rootReducer);

const store = configureStore({
  reducer: persistedReducer,
  devTools: false,
  middleware: getDefaultMiddleware =>
    getDefaultMiddleware({
      serializableCheck: {
        ignoredActions: [FLUSH, REHYDRATE, PAUSE, PERSIST, PURGE, REGISTER],
      },
    }).concat([
      cardAuthApi.middleware,
      cardMainApi.middleware,

    ]),
  // enhancers: defaultEnhancers => [...defaultEnhancers, devToolsEnhancer()],
});

export default store;

export type RootState = ReturnType<typeof store.getState>;
export type AppDispatch = typeof store.dispatch;
