/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable camelcase */
/* eslint-disable import/prefer-default-export */
/* eslint-disable import/order */
/* eslint-disable @typescript-eslint/no-explicit-any */
import config from '@/src/constants/Config';
// import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/dist/query/react';
import { createApi, fetchBaseQuery } from '@reduxjs/toolkit/query/react';

export const cardAuthApi = createApi({
  reducerPath: 'cardAuthApi',
  refetchOnFocus: false,
  baseQuery: fetchBaseQuery({
    baseUrl: config.baseURL,
    prepareHeaders: (headers, { getState }) => {
      // const { tempToken, auth_token } = (
      //   getState() as { business: any }
      // ).business;
      // if (tempToken) {
      //   headers.set('Authorization', `Bearer ${tempToken}`);
      // } else if (auth_token) {
      //   headers.set('Authorization', `Bearer ${auth_token}`);
      // }
      return headers;
    },
  }),

  endpoints: (builder) => ({
    bizSignin: builder.mutation<any, any>({
      query: (body) => ({
        url: '/auth/signin',
        method: 'POST',
        body,
      }),
      async onQueryStarted(_, { dispatch, queryFulfilled }) {
        try {
          await queryFulfilled;
          // dispatch(
          //   businessCurrentApi.util.invalidateTags(['getBusinessCurrent']),
          // );
        } catch (error: any) {
          // handleLogout(data, { dispatch });
        }
      },
    }),
    bizGoogleSignin: builder.mutation<any, any>({
      query: (body) => ({
        url: '/auth/signinWithGoogle',
        method: 'POST',
        body,
      }),
      async onQueryStarted(_, { dispatch, queryFulfilled }) {
        try {
          await queryFulfilled;
        } catch (error: any) {
          console.log('🚀 err', error);
        }
      },
    }),

    bizSignup: builder.mutation<any, any>({
      query: (body) => ({
        url: '/auth/signUp',
        method: 'POST',
        body,
      }),

      async onQueryStarted(_, { dispatch, queryFulfilled }) {
        try {
          await queryFulfilled;
          // dispatch(
          //   businessCurrentApi.util.invalidateTags(['getBusinessCurrent']),
          // );
        } catch (error: any) {
          console.log('🚀 ~ onQueryStarted ~ error:', error);
        }
      },
    }),

    bizForgotPassword: builder.mutation<any, any>({
      query: (body) => ({
        url: '/auth/forgotPassword',
        method: 'POST',
        body,
      }),
    }),

    bizResetPassword: builder.mutation<any, any>({
      query: (body) => ({
        url: '/auth/resetPassword',
        method: 'POST',
        body,
      }),
    }),
  }),
});

export const {
  useBizSigninMutation,
  useBizGoogleSigninMutation,
  useBizSignupMutation,
  useBizForgotPasswordMutation,
  useBizResetPasswordMutation,
} = cardAuthApi;
