/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable camelcase */
/* eslint-disable import/order */
/* eslint-disable @typescript-eslint/no-explicit-any */
import config from "@/src/constants/Config";
import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";

export const cardMainApi = createApi({
  reducerPath: "cardMainApi",
  refetchOnFocus: false,
  baseQuery: fetchBaseQuery({
    baseUrl: config.baseURL,
    prepareHeaders: (headers, { getState }) => {
      const { jwt } = (getState() as { card: any }).card;
      if (jwt) {
        headers.set("Authorization", `Bearer ${jwt}`);
      }

      return headers;
    },
  }),

  tagTypes: ["getCards", "getTeams"],
  endpoints: (builder) => ({
    verifyOtp: builder.mutation<any, any>({
      query: (body) => ({
        url: "/auth/verifyEmailOtp",
        method: "POST",
        body,
      }),
    }),
    verifyCoupon: builder.mutation<any, { couponCode: string }>({
      query: (body) => ({
        url: "/auth/verifyCoupon",
        method: "POST",
        body,
      }),
    }),

    createCard: builder.mutation<any, any>({
      query: (body) => {
        const { myContact: _topLevelMyContact, ...restBody } = body ?? {};
        const myContactValue = Boolean(
          restBody?.ContactDetails?.myContact ?? body?.myContact,
        );
        return {
          url: "/auth/createCard",
          method: "POST",
          body: {
            ...restBody,
            ContactDetails: {
              ...restBody?.ContactDetails,
              myContact: myContactValue,
            },
          },
        };
      },
      invalidatesTags: ["getCards"],
    }),

    deleteCard: builder.mutation<any, string>({
      query: (cardId) => ({
        url: `/auth/deleteCard?cardId=${cardId}`,
        method: "DELETE",
      }),
      invalidatesTags: ["getCards"],
    }),

    createTeam: builder.mutation<any, any>({
      query: (body) => ({
        url: "/auth/createTeam",
        method: "POST",
        body,
      }),
      invalidatesTags: ["getTeams"],
    }),

    deleteTeam: builder.mutation<any, string>({
      query: (teamId) => ({
        url: `/auth/deleteTeam?teamId=${teamId}`,
        method: "DELETE",
      }),
      invalidatesTags: ["getTeams"],
    }),

    joinTeam: builder.mutation<any, any>({
      query: (body) => ({
        url: "/auth/joinTeam",
        method: "POST",
        body,
      }),
      // invalidatesTags: ['getTeams']
    }),

    getAllCards: builder.query<any, any>({
      query: ({ category, subCategory, industry, name, myContact }) => ({
        url: `/auth/getCards?category=${category}&subCategory=${subCategory}&name=${name}&industry=${industry}&myContact=${myContact ?? false}`,
        method: "GET",
      }),
      keepUnusedDataFor: 0,
      providesTags: ["getCards"],
      async onQueryStarted(_, { dispatch, queryFulfilled }) {
        try {
          await queryFulfilled;
        } catch (error: any) {
          console.log("🚀 ~ onQueryStarted ~ error:", error);
        }
      },
    }),

    getAllTeams: builder.query<any, any>({
      query: ({ category }) => ({
        url: `/auth/getTeams?category=${category}`,
        method: "GET",
      }),
      providesTags: ["getTeams"],
      keepUnusedDataFor: 0,
      async onQueryStarted(_, { dispatch, queryFulfilled }) {
        try {
          await queryFulfilled;
        } catch (error: any) {
          console.log("🚀 ~ onQueryStarted ~ error:", error);
        }
      },
    }),

    getTeamCards: builder.query<any, any>({
      query: ({ teamId }) => ({
        url: `/auth/getTeamCards?teamId=${teamId}`,
        method: "GET",
      }),
      keepUnusedDataFor: 0,
      async onQueryStarted(_, { dispatch, queryFulfilled }) {
        try {
          await queryFulfilled;
        } catch (error: any) {
          console.log("🚀 ~ onQueryStarted ~ error:", error);
        }
      },
    }),

    getAllUsers: builder.query<any, any>({
      query: () => ({
        url: "/auth/getAllUsers",
        method: "GET",
      }),
      keepUnusedDataFor: 0,
    }),

    addUserToTeam: builder.mutation<any, any>({
      query: (body) => ({
        url: "/auth/addUserToTeam",
        method: "POST",
        body,
      }),
      invalidatesTags: ["getTeams"],
    }),

    updateCard: builder.mutation<any, any>({
      query: (body) => ({
        url: `/auth/updateCard?cardId=${body?._id}`,
        method: "POST",
        body,
      }),
    }),

    getSingleCardDetails: builder.query<any, any>({
      query: ({ cardId }) => ({
        url: `/auth/getCardDetails?cardId=${cardId}`,
        method: "GET",
      }),
      keepUnusedDataFor: 0,
      providesTags: ["getCards"],
    }),

    uploadContactToHubspot: builder.mutation<any, any>({
      query: () => ({
        url: "/auth/uploadContactToHubspot",
        method: "POST",
      }),
    }),

    importContactFromHub: builder.query<any, any>({
      query: () => ({
        url: "/auth/importContactFromHub",
        method: "GET",
      }),
      keepUnusedDataFor: 0,
    }),
    getContactDetails: builder.query<any, void>({
      query: () => ({
        url: "/auth/getContactDetails",
        method: "GET",
      }),
      async onQueryStarted(_, { queryFulfilled }) {
        try {
          const { data } = await queryFulfilled;
          console.log("Contact Details:", data);
        } catch (error: any) {
          console.log("Error fetching contact details:", error);
        }
      },
    }),

    uploadAllContactsToSalesforce: builder.mutation<any, any>({
      query: () => ({
        url: "/auth/uploadAllContactsToSalesforce",
        method: "POST",
      }),
    }),

    importContactsFromSalesforce: builder.query<any, any>({
      query: () => ({
        url: "/auth/importContactsFromSalesforce",
        method: "GET",
      }),
      keepUnusedDataFor: 0,
    }),
    saveSalesforceCredentials: builder.mutation<any, any>({
      query: (body) => ({
        url: "/auth/saveCredentials",
        method: "POST",
        body,
      }),
    }),

    saveHubspotCredentials: builder.mutation<any, any>({
      query: (body) => ({
        url: "/auth/saveCredentials",
        method: "POST",
        body,
      }),
    }),
  }),
});

export const {
  useJoinTeamMutation,
  useGetAllCardsQuery,
  useGetAllTeamsQuery,
  useCreateCardMutation,
  useDeleteCardMutation,
  useCreateTeamMutation,
  useDeleteTeamMutation,
  useVerifyOtpMutation,
  useGetTeamCardsQuery,
  useGetAllUsersQuery,
  useAddUserToTeamMutation,
  useUpdateCardMutation,
  useGetSingleCardDetailsQuery,
  useLazyImportContactFromHubQuery,
  useUploadContactToHubspotMutation,
  useGetContactDetailsQuery,
  useUploadAllContactsToSalesforceMutation,
  useLazyImportContactsFromSalesforceQuery,
  useSaveSalesforceCredentialsMutation,
  useSaveHubspotCredentialsMutation,
  useVerifyCouponMutation,
} = cardMainApi;
