export const DATALIST = [
    { id: '1', name: 'Emily Carter', company: 'PixelCraft Studio', role: 'UX Designer', source: require('@/assets/main/card/card.png') },
    { id: '2', name: 'Michael Johnson', company: 'TechNest Corp', role: 'Software Engineer', source: require('@/assets/main/card/card.png') },
    { id: '3', name: 'Jason Lee', company: 'Global Agency', role: 'Manager', source: require('@/assets/main/card/card.png') },
    { id: '4', name: 'Ashley Thompson', company: 'BlueOak Industries', role: 'HR Specialist', source: require('@/assets/main/card/card.png') },
];
