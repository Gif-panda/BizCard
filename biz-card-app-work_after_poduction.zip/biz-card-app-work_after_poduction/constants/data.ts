import { CategoryType, ExpenseCategoriesType } from "@/types";
import { colors } from "./theme";

import * as Icons from "phosphor-react-native"; // Import all icons dynamically

export const expenseCategories: ExpenseCategoriesType = {
  groceries: {
    label: "Groceries",
    value: "groceries",
    icon: Icons.ShoppingCart,
    bgColor: "#4B5563", // Deep Teal Green
  },
  rent: {
    label: "Rent",
    value: "rent",
    icon: Icons.House,
    bgColor: "#075985", // Dark Blue
  },
  utilities: {
    label: "Utilities",
    value: "utilities",
    icon: Icons.Lightbulb,
    bgColor: "#ca8a04", // Dark Golden Brown
  },
  transportation: {
    label: "Transportation",
    value: "transportation",
    icon: Icons.Car,
    bgColor: "#b45309", // Dark Orange-Red
  },
  entertainment: {
    label: "Entertainment",
    value: "entertainment",
    icon: Icons.FilmStrip,
    bgColor: "#0f766e", // Darker Red-Brown
  },
  dining: {
    label: "Dining",
    value: "dining",
    icon: Icons.ForkKnife,
    bgColor: "#be185d", // Dark Red
  },
  health: {
    label: "Health",
    value: "health",
    icon: Icons.Heart,
    bgColor: "#e11d48", // Dark Purple
  },
  insurance: {
    label: "Insurance",
    value: "insurance",
    icon: Icons.ShieldCheck,
    bgColor: "#404040", // Dark Gray
  },
  savings: {
    label: "Savings",
    value: "savings",
    icon: Icons.PiggyBank,
    bgColor: "#065F46", // Deep Teal Green
  },
  clothing: {
    label: "Clothing",
    value: "clothing",
    icon: Icons.TShirt,
    bgColor: "#7c3aed", // Dark Indigo
  },
  personal: {
    label: "Personal",
    value: "personal",
    icon: Icons.User,
    bgColor: "#a21caf", // Deep Pink
  },
  others: {
    label: "Others",
    value: "others",
    icon: Icons.DotsThreeOutline,
    bgColor: "#525252", // Neutral Dark Gray
  },
};

export const incomeCategory: CategoryType = {
  label: "Income",
  value: "income",
  icon: Icons.CurrencyDollarSimple,
  bgColor: "#16a34a", // Dark
};

export const transactionTypes = [
  { label: "Expense", value: "expense" },
  { label: "Income", value: "income" },
];

export const faqData = [
    {
      id: "1",
      question: "How do I reset my password?",
      answer:
        "To reset your password, go to the login screen and click on 'Forgot Password'. Enter your email address and follow the instructions sent to your email.",
    },
    {
      id: "2",
      question: "Can I change my subscription plan?",
      answer:
        "Yes, you can upgrade or downgrade your subscription at any time from the Subscription section in your account settings.",
    },
    {
      id: "3",
      question: "How do I contact customer support?",
      answer:
        "You can reach our support team 24/7 by emailing support@example.com or using the in-app chat feature.",
    },
    {
      id: "4",
      question: "Is my payment information secure?",
      answer:
        "Yes, we use industry-standard encryption to protect your payment information. We never store your full credit card details on our servers.",
    },
    {
      id: "5",
      question: "How do I cancel my subscription?",
      answer:
        "You can cancel your subscription at any time from the Subscription section in your account settings. Your access will continue until the end of your current billing period.",
    },
    {
      id: "6",
      question: "Why am I not receiving notifications?",
      answer:
        "First, check your device settings to ensure notifications are enabled for our app. Then verify your notification preferences in the app's settings. If issues persist, try reinstalling the app.",
    },
  ];

  
export const privacyPolicyData = [
  {
    title: "1. Introduction",
    content:
      "Welcome to BizCard! These terms and conditions outline the rules and regulations for the use of HouseVenture Inc.'s App, BizCard. By accessing this app, we assume you accept these terms and conditions. Do not continue to use BizCard if you do not agree to all of the terms and conditions stated on this page.",
  },
  {
    title: "2. Interpretation and Definitions",
    content:
      "Capitalized words have defined meanings:\n- Content: any information, listings, photos, or other materials you upload to the app.\n- User: any individual or entity that accesses or uses the app.\n- Company (\"We\", \"Us\", \"Our\"): HouseVenture Inc.",
  },
  {
    title: "3. Acknowledgment",
    content:
      "These Terms govern the use of this app and the agreement between you and the Company. Your access and use of the app is conditioned on your acceptance and compliance with these Terms. By using the app, you agree to be bound by these Terms. If you disagree with any part, do not access the app.",
  },
  {
    title: "4. User Accounts",
    content:
      "When creating an account, you must provide accurate and complete information. You are responsible for safeguarding your password and for all activities under your account. Notify us immediately of any security breaches or unauthorized use.",
  },
  {
    title: "5. Content",
    content:
      "You retain ownership of your Content, but by uploading it to BizCard, you grant the Company a non-exclusive, transferable, sub-licensable, royalty-free, worldwide license to use it to operate, develop, and provide the app. You warrant that you own the Content or have the right to grant this license and that posting it does not violate others' rights. All Content is for informational purposes and should be independently verified.",
  },
  {
    title: "6. Copyright Policy",
    content:
      "We respect intellectual property rights. We respond to claims that Content posted on the app infringes copyrights or other rights of any person or entity.",
  },
  {
    title: "7. Intellectual Property",
    content:
      "The app and its original content, features, and functionality are the exclusive property of HouseVenture Inc. and its licensors, protected by copyright, trademark, and other laws.",
  },
  {
    title: "8. User Feedback",
    content:
      "You assign all rights, title, and interest in any feedback you provide to the Company. If the assignment is ineffective, you grant a non-exclusive, perpetual, irrevocable, royalty-free, worldwide license to use and exploit such feedback.",
  },
  {
    title: "9. Links to Other Websites",
    content:
      "The app may contain links to third-party websites or services not controlled by the Company. We assume no responsibility for their content, privacy policies, or practices.",
  },
  {
    title: "10. Termination",
    content:
      "We may terminate or suspend your account immediately, without prior notice or liability, for any reason, including if you breach these Terms.",
  },
  {
    title: "11. Limitation of Liability",
    content:
      "HouseVenture Inc., its directors, employees, partners, agents, suppliers, or affiliates shall not be liable for any indirect, incidental, special, consequential, or punitive damages resulting from your use of the app, content of third parties, or unauthorized access to your data.",
  },
  {
    title: "12. 'AS IS' and 'AS AVAILABLE' Disclaimer",
    content:
      "The app is provided 'AS IS' and 'AS AVAILABLE' with all faults, without warranty of any kind. To the maximum extent permitted by law, the Company disclaims all warranties, express or implied, including merchantability, fitness for a particular purpose, title, and non-infringement.",
  },
  {
    title: "13. Governing Law",
    content:
      "These Terms and your use of the app are governed by the laws of [insert state], excluding conflicts of law rules, and may also be subject to other applicable laws.",
  },
  {
    title: "14. Disputes Resolution",
    content:
      "If a dispute arises, you agree to try resolving it informally by contacting the Company. Unresolved disputes will be finally settled by binding arbitration administered by the American Arbitration Association under its consumer dispute rules.",
  },
  {
    title: "15. Severability and Waiver",
    content:
      "If any provision is held unenforceable or invalid, it will be interpreted to accomplish its objectives to the fullest extent possible. Remaining provisions remain in effect. Failure to exercise a right or waive a breach does not constitute a waiver of future rights or breaches.",
  },
  {
    title: "16. Changes to the Terms",
    content:
      "We may modify or replace these Terms at any time. Material changes will be notified at least 30 days in advance. Continuing to use the app after changes indicates acceptance of the revised Terms.",
  },
  {
    title: "17. Contact Information",
    content:
      "If you have any questions about these Terms, contact us at: support@bizcard.com",
  },
];
