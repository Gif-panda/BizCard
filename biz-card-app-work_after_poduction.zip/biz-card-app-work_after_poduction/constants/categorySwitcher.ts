 export const tabButtons: any[] = [
        {
            title: 'Personal',
            accessibilityLabel: 'Personal',
        },
        {
            title: 'Business',
            accessibilityLabel: 'Business',
        },
    ];


    export const teamsButtons: any[] = [
        {
            title: 'Create a team',
            accessibilityLabel: 'createTeam',
        },
        {
            title: 'Join a Team',
            accessibilityLabel: 'JoinTeam',
        },
    ];