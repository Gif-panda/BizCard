import * as React from "react";
import Svg, { Path, Defs, LinearGradient, Stop } from "react-native-svg";

interface WaveSvgProps {
    useGradient?: boolean;
    gradientColors?: [string, string]; // e.g., ['#0099ff', '#66ccff']
    solidColor?: string; // e.g., '#0099ff'
    height?: number;
    cardType?: 'classic' | 'modern' | 'flat' | 'sleek';
}

const pathDataMap: Record<string, string> = {
classic: "M0,160C120,140,260,150,400,165C560,185,720,210,880,225C1040,235,1200,225,1440,190L1440,0L0,0Z",
    modern: "M0,20L1440,220L1440,0L0,0Z",
    flat: "M0,220L1440,220L1440,0L0,0Z",
    sleek: "M0,200L720,80L1440,200L1440,0L720,0L0,0Z",
};

const cardTypeHeight = {
    classic: 170,
    modern: 170,
    flat: 130,
    sleek: 170,
}


const WaveSvg: React.FC<WaveSvgProps> = ({
    useGradient = false,
    gradientColors = ['#0099ff', '#66ccff'],
    solidColor = '#0099ff',
    cardType = 'classic',
    height = cardTypeHeight[cardType] || 170,
    ...props
}) => (
    <Svg
        viewBox="0 0 1440 320"
        width="100%"
        height={height}
        preserveAspectRatio="none"
        {...props}
    >
        {useGradient && (
            <Defs>
                <LinearGradient id="waveGradient" x1="0" y1="0" x2="1" y2="0">
                    <Stop offset="0%" stopColor={gradientColors[0]} />
                    <Stop offset="100%" stopColor={gradientColors[1]} />
                </LinearGradient>
            </Defs>
        )}
        <Path
            fill={useGradient ? 'url(#waveGradient)' : String(solidColor)}
            d={pathDataMap[cardType]}
        />







    </Svg>
);

export default WaveSvg;
